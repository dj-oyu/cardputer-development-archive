"""Verify saved editability, closed procedural skin, neutral loop and motion clearance."""
import bpy,bmesh,sys,os,math,json
from bpy_extras.object_utils import world_to_camera_view
from itertools import combinations
base=os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
f=os.path.join(base,'delivery','cloud-delivery.blend')
bpy.ops.wm.open_mainfile(filepath=f)
s=bpy.context.scene;r=bpy.data.objects['Cloud_Rig'];obs=[o for o in s.objects if o.parent==r]
assert len(r.data.bones)==6 and r.animation_data is not None and r.animation_data.action is not None
assert len([o for o in obs if o.name.startswith("Floating hand")])==2
assert len([o for o in obs if o.name.startswith("Halo vapor")])==5
def world_verts(obj,dg):
 o=obj.evaluated_get(dg);return [o.matrix_world @ v.co for v in o.data.vertices]
def bounds(v,idx):
 return min(k[idx] for k in v),max(k[idx] for k in v)
mesh_counts={};closures={}
for o in obs:
 if o.type=='MESH':
  m=o.data;m.calc_loop_triangles();mesh_counts[o.name]=len(m.loop_triangles)
  bm=bmesh.new();bm.from_mesh(m)
  closures[o.name]=[sum(not e.is_manifold for e in bm.edges),round(bm.calc_volume(signed=True),6)]
  bm.free()
assert all(k[0]==0 and k[1]>0 for k in closures.values()),closures
samples={}
loop=[];gap={}
for f in sorted(set(range(1,242,6))|{84,166,241}):
 s.frame_set(f);dg=bpy.context.evaluated_depsgraph_get()
 poses=[o.evaluated_get(dg).matrix_world.copy() for o in obs]
 if f in {1,241}:loop.append(poses)
 body=world_verts(bpy.data.objects['Cloud body'],dg)
 hl=world_verts(bpy.data.objects['Floating hand L'],dg)
 hr=world_verts(bpy.data.objects['Floating hand R'],dg)
 halo=[v for o in obs if o.name.startswith("Halo vapor") for v in world_verts(o,dg)]
 def img(v): return [world_to_camera_view(s,s.camera,k) for k in v]
 a,b,c,d=map(img,(body,hl,hr,halo))
 # main view bbox clearance; conservative because each hand shares only some vertical spans
 g=( (bounds(b,0)[0]-bounds(a,0)[1])*240,(bounds(a,0)[0]-bounds(c,0)[1])*240,(bounds(d,1)[0]-bounds(a,1)[1])*135)
 gap[str(f)]=g
 if f in {1,84,166,241}:
  samples[str(f)]={"main_view_bbox_gap_px":[round(x,3) for x in g],"body_position":list(r.pose.bones["Body"].location),"body_scale":list(r.pose.bones["Body"].scale),"halo_edge_lag":r.pose.bones["Halo.Tip"]["lag"]}
assert len(loop)==2
assert all(abs(e1-e2)<1.e-5 for m1,m2 in zip(*loop) for r1,r2 in zip(m1,m2) for e1,e2 in zip(r1,r2))
report={"fps":s.render.fps,"frame_start":s.frame_start,"frame_end":s.frame_end,"bones":list(r.data.bones.keys()),"action":r.animation_data.action.name,"editable_triangles_mesh_only":sum(mesh_counts.values()),"closed_meshes_positive_volume":len(closures),"sampled_frames":len(gap),"minimum_bbox_gap_px":[round(min(g[i] for g in gap.values()),3) for i in range(3)],"poses":samples,"note":"Geometric world/camera measurement, not native renderer evidence or device timing."}
with open(os.path.join(base,'delivery','blend-validation.json'),'w') as o: json.dump(report,o,ensure_ascii=False,indent=2)
print(report)
