"""Render 10 s proof at sampled 4 fps, independent of device/host exporter."""
import bpy, os
base=os.path.dirname(os.path.dirname(os.path.realpath(__file__)));d=os.path.join(base,'delivery','motion-frames');os.makedirs(d,exist_ok=True)
bpy.ops.wm.open_mainfile(filepath=os.path.join(base,'delivery','cloud-delivery.blend'))
s=bpy.context.scene;s.cycles.samples=72
s.render.resolution_x=240;s.render.resolution_y=135
for index,frame in enumerate(range(1,241,6)):
 s.frame_set(frame);s.render.filepath=os.path.join(d,'frame-%03d.png'%index);bpy.ops.render.render(write_still=True)
