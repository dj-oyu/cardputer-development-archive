"""Model and render one or more evaluated GLBs at fixed 240x135 framing."""
from pathlib import Path
import argparse,math,struct,os,subprocess,json,hashlib
from PIL import Image,ImageDraw,ImageFont
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('build',type=Path)
p.add_argument('output',type=Path)
p.add_argument('poses',nargs='+',type=Path)
p.add_argument('--yaws',default='0,35,-35,90')
p.add_argument('--elevation',type=float,default=5)
p.add_argument("--centre",help="Fixed native x,y,z target")
p.add_argument("--horizontal-width",type=float,help="Fixed scene width in model units")
a=p.parse_args()
a.output.mkdir()
assert len({x.stem for x in a.poses})==len(a.poses),'pose filenames must have unique stems'
root=Path(__file__).resolve().parent
pin=(a.build/'runtime-revision.txt').read_text().strip()
pose_data={}
probe_env=os.environ|{'ASAN_OPTIONS':'detect_leaks=0:abort_on_error=1','UBSAN_OPTIONS':'halt_on_error=1'}
for f in a.poses:
 inf = subprocess.check_output(['node',str(root/'pack_scene.cjs'),str(a.build/'runtime'),str(f),str(a.output/(f.stem+'.aynm'))],text=True,timeout=60)
 pose_data[f.stem]=json.loads(inf)
lo=[min(pose['bounds'][0][k] for pose in pose_data.values()) for k in range(3)]
hi=[max(pose['bounds'][1][k] for pose in pose_data.values()) for k in range(3)]
centre=[(lo[k]+hi[k])/2 for k in range(3)]
if a.centre: centre=[float(x) for x in a.centre.split(",")]; assert len(centre)==3
radius=math.dist(lo,hi)*.5
assert radius>0
# Use the same zoom for all frames and views. Fit conservative bound in X/Y.
scale=min(114/max(.001,abs(hi[1]-lo[1])+abs(hi[0]-lo[0])*abs(math.sin(math.radians(a.elevation)))+abs(hi[2]-lo[2])*abs(math.sin(math.radians(a.elevation)))),200/max(.001,math.hypot(hi[0]-lo[0],hi[2]-lo[2])))
if a.horizontal_width: assert a.horizontal_width>0; scale=240/a.horizontal_width
width=240;height=135
yaws=[float(x) for x in a.yaws.split(',')]
report={'pinnedFirmware':pin,'scope':'native host AYatsuri model evaluator and Kasane opaque shared-depth, not device or real transmission','pxPerUnit':scale,'centre':centre,'elevationDeg':a.elevation,'resolution':[width,height],'poses':pose_data,'frames':{}}
sheet=Image.new('RGB',(len(yaws)*width,len(a.poses)*(height+24)),(233,237,244))
dd=ImageDraw.Draw(sheet)
for col,yaw in enumerate(yaws):
 y=math.radians(yaw);e=math.radians(a.elevation)
 p=[centre[0]+400*math.sin(y)*math.cos(e),centre[1]-400*math.sin(e),centre[2]+400*math.cos(y)*math.cos(e)]
 camera=p+centre+[scale,120,67.5]
 for row,f in enumerate(a.poses):
  for light_name,light in [('left',[-.6,-.35,1]),('right',[.6,-.35,1])]:
   tag=f'{f.stem}.{yaw:g}.{light_name}'
   rawpath=a.output/(tag+'.rgb565')
   info = subprocess.check_output([str((a.build/'render_scene').resolve()),str(a.output/(f.stem+'.aynm')),str(rawpath),*map(str,camera+light)],env=probe_env,text=True,timeout=15)
   raw=rawpath.read_bytes(); keys=struct.unpack('<32400H',raw)
   frame=Image.new('RGB',(width,height));pix=[(((x>>11)&31)*255//31,((x>>5)&63)*255//63,(x&31)*255//31) if x else (72,90,111) for x in keys]
   frame.putdata(pix);frame.save(a.output/(tag+'.png'))
   report['frames'][tag]={**json.loads(info),'sha256':hashlib.sha256(raw).hexdigest(),'background':'only zero-valued host pixels recolored for legibility (not firmware output)'}
   if light_name=='left':
    sheet.paste(frame,(col*width,row*(height+24)))
    dd.text((col*width+8,row*(height+24)+height+4),f'{f.stem} / {yaw:g} deg',fill=(35,54,78))
sheet.save(a.output/'preview.png')
(a.output/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'frames':len(report['frames']),'output':str(a.output),'scope':report['scope']}))
