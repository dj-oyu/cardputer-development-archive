#!/bin/sh
set -eu
test "$#" -eq 2 || { echo "usage: $0 <firmware.git> <new-output-directory>" >&2; exit 2; }
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
mkdir "$2"
PIN=5a3dedcba86f46bf74567fc07c42a85e7bb3e25f
git -C "$1" archive "$PIN" main/ayatsuri main/ui/kasane tools/ayatsuri > "$2/runtime.tar"
mkdir "$2/runtime"; tar xf "$2/runtime.tar" -C "$2/runtime"
rm "$2/runtime.tar"
M="$2/runtime/main"
cc -std=c11 -O2 -g -Wall -Wextra -Werror -ffp-contract=off -fsanitize=address,undefined \
  -fno-omit-frame-pointer -fno-pie -no-pie -I"$M" "$ROOT/render_scene.c" \
  "$M/ayatsuri/ayatsuri_model.c" "$M/ayatsuri/ayatsuri_visibility.c" "$M/ayatsuri/compact_opaque.c" \
  "$M/ui/kasane/ksn_shiki_frame.c" "$M/ui/kasane/ksn_mesh_depth.c" -lm -o "$2/render_scene"
printf '%s\n' "$PIN" > "$2/runtime-revision.txt"
