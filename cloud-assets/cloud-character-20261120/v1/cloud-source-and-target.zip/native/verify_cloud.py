"""Check target-host Cloud silhouette spacing, loop closure and shading response."""
from pathlib import Path
import argparse, json, struct, sys
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('rendered',type=Path)
p.add_argument('--main-yaw',default='14.63')
p.add_argument('--min-background-pixels',type=int,default=2)
a=p.parse_args()
W,H=240,135
r=json.loads((a.rendered/'verification.json').read_text())
def raw(tag): return struct.unpack('<32400H',(a.rendered/(tag+'.rgb565')).read_bytes())
def components(px):
    remain={(p%W,p//W) for p,v in enumerate(px) if v}
    sets=[]
    while remain:
        start=remain.pop(); q=[start]; comp={start}
        while q:
            x,y=q.pop()
            for dx in (-1,0,1):
                for dy in (-1,0,1):
                    n=x+dx,y+dy
                    if n in remain: remain.remove(n); q.append(n); comp.add(n)
        sets.append(comp)
    return sorted(sets,key=len,reverse=True)
def bbox(comp):
    x,y=zip(*comp)
    return [min(x),min(y),max(x),max(y)]
def gap(one,two):
    def boundary(px):
        return [(x,y) for x,y in px if any((x+u,y+v) not in px for u,v in ((-1,0),(1,0),(0,-1),(0,1)))]
    return min(max(abs(x-u),abs(y-v))-1 for x,y in boundary(one) for u,v in boundary(two))
result={}
first_main=None
for pose in r['poses']:
    tag=f'{pose}.{a.main_yaw}'
    left,right=raw(tag+'.left'),raw(tag+'.right')
    if first_main is None: first_main=left
    groups=components(left)
    keep=[x for x in groups if len(x)>=50]
    body=keep[0]
    others=keep[1:]
    halo=[x for x in others if bbox(x)[3]<bbox(body)[1]]
    hands=[x for x in others if bbox(x)[3]>=bbox(body)[1]]
    hand_gaps=[gap(body,x) for x in hands]
    result[pose]={'components':[{ 'pixels':len(x),'bbox':bbox(x)} for x in keep],
                  'haloDisconnected':len(halo)==1,'handsDisconnected':len(hands)==2,
                  'handBackgroundPixelGaps':hand_gaps,'lightToggleChangedPixels':sum(x!=y for x,y in zip(left,right)),
                  'differentFromFirstPixels':sum(x!=y for x,y in zip(left,first_main)),
                  'handGapPass':len(hands)==2 and min(hand_gaps)>=a.min_background_pixels}
events={}
poses=list(r['poses'])
for tag in r['frames']:
    pfx=poses[0]+'.'
    if tag.startswith(pfx):
       following=poses[-1]+tag[len(poses[0]):]
       events[tag[len(pfx):]]=r['frames'][tag]['sha256']==r['frames'][following]['sha256']
peaks={k:max(f[k] for f in r['frames'].values()) for k in ['actorArenaBytes','snapshotBytes','packets','work']}
summary={'scope':r['scope'],'mainYaw':a.main_yaw,'coverageChecks':result,'loopFirstLastExact':events,'peaks':peaks}
(a.rendered/'cloud-checks.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary))
if not (all(v['handGapPass'] and v['haloDisconnected'] and v['lightToggleChangedPixels']>0 for v in result.values()) and all(events.values()) and all(result[p]['differentFromFirstPixels']>0 for p in poses[1:-1])): sys.exit(1)
