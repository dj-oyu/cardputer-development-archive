# 240×135 Cardputer opaque host preview

This test links the actual AYatsuri model evaluator and Kasane shared-depth renderer from firmware commit `5a3dedcba86f46bf74567fc07c42a85e7bb3e25f`. It proves the accepted opaque input can reach host RGB565 pixels with bounded framing and identical 1- and 8-row rasterization. It does not build firmware, measure device FPS or fit, support translucency, or prove animation playback. Each GLB supplies a separately evaluated pose.

For a host checkout containing the pinned firmware revision, install Node, Python 3 with Pillow and a C compiler with ASan/UBSan, then from the extracted archive root run:

```sh
sh native/prepare.sh /path/to/cardputer-adv-pocketjs /path/to/new-host-build
python3 native/preview.py /path/to/new-host-build /path/to/new-results delivery/cloud-opaque-001.glb delivery/cloud-opaque-084.glb delivery/cloud-opaque-166.glb delivery/cloud-opaque-241.glb --yaws=14.63,0,-35 --elevation=6.82 --centre=0,-2.11,0 --horizontal-width=8.1
python3 native/verify_cloud.py /path/to/new-results
```

Use one evaluated GLB per pose: character meshes only, triangles, position and normal attributes, opaque base-color materials. Preserve hierarchy or motion in the editable Blender original separately; textures, vertex colors, armatures, animation, shape keys and transmissive extensions are not accepted by this static GLB-to-AYNM path. The pack script quantizes supplied RGB numeric values directly to RGB565 and uses one fixed ambient/diffuse mapping for all materials, not Blender material equivalence.

Default ortho fit combines all given poses and fixes one scale/center for the run; freeze `--centre`, `--horizontal-width` and `--elevation` across runs for A/B comparisons. With Blender glTF YUp conversion, native coordinates are (Blender X, -Blender Z, -Blender Y). Replay regenerates the raw RGB565 files; the archive does not retain copies of rendered frames. PNG previews replace zero-valued pixels with a slate background for readability. Paired left/right light frames show directional lighting in the selected render path only, not transmission or scattering.

Compact opaque shared-depth uses a 65,536-byte harness snapshot and an 8,000,000-unit harness work cap; outputs include host allocation numbers as diagnostics, not MCU budgets. Never infer physical or visual acceptance solely from a nonempty raster.

The Cloud verifier evaluates the requested main camera for separated hands and halo at checkpoints in argument order, direct-light color changes, scene changes during the action, and exact first/last frame closure at each sampled view/lighting. It does not verify collision/space throughout unsampled frames.
