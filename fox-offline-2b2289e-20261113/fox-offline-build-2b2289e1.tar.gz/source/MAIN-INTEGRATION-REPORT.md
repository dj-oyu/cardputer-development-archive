# Private integration after PR131 and PR130
Latest incorporated public main: aec9ff8797d25bad269e18452223c26d9833bf2b (PR126 follow-up below).
Previous incorporated main:1ff2fe87ab9c8bbdc27874b3bcbb269775072901.
Initial PR131 main:48405047341bb73b93d73b405c4798b4900eafc1.
Private model source never published. Old private77149db remains unchanged.

Recovered public baseline828baa3 verified against official recursive tree:1820 present files match and6files contain private product hooks. Missing recovered files were not interpreted as deletions. Newmain source is authoritative except those6explicit merged overlays and private additions.

Initial candidate2234c75 incorrectly truncated main.c during conflict resolution. It was not accepted. Fix676ed70b regenerates all6merges with line-bounded conflict parsing;main.c now preserves full boot body, heap-origin,wifi/task initialization. No target build was claimed from host tests.

Actual new QuickJS5objects were freshly compiled from this candidate, not reused from old cache. Actual JS-owner O2ASan/UBSan passed3runtime sessions+native allocation rejection. Added JS Math.sin/cos/tan(.7) exact comparison to new table-trig functions passes. This tests the new engine but not real app_session or the two-core dispatcher. Private native rig retains its C libm arithmetic.

Private4cycle QEMU/full firmware/real SPI remain unexecuted. The retained diagnostic CMake and board/OS substitutions do not prove full production compatibility. Main integration manifest records the exact overlay and boundaries. Independent renderer/mixed checks are coordinated separately.

## PR126 follow-up
Incorporated public main aec9ff8797d25bad269e18452223c26d9833bf2b into a new private/head-main126-integration worktree, preserving the previous dedb6fb5 candidate. One CMake conflict was resolved by preserving both incoming Q7 configuration and private diagnostic sources. Prepared, edge4, Q7 certified and Q7 preflight remain default OFF. Source/main/CMake nonblank public-line order checks and all six overlay hash/EOF/marker checks pass.

All QuickJS .c/.h inputs are SHA-identical to the previously freshly compiled main131 objects. Those exact objects are reused with their hashes; all directly compiled product C and headers now resolve to this main126 candidate. Actual JS-owner three runtime sessions plus native-allocation rejection and explicit table-trig checks pass O2 ASan/UBSan. This does not test the real target firmware or newly enabled Q7 runtime paths; options were not enabled.
