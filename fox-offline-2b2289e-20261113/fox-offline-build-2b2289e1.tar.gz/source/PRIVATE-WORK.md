# Private head/eye snapshot integration

This directory contains private model-derived arrays and renderer code. No remote.
Never publish this repository or its patch to a public service.

Baseline recovered from the November 11 owner/SPI Library archive. Target:
connect the already-existing Head Turn/Head Tilt rig to the same accepted eye
snapshot, keeping both render_leased and render_cursor paths consistent.
Do not introduce new motion, rewrite source controls, or change eye precision.

Before modifying the admission ABI, validate the source control domain and mixed
head/eye dependency graph, then preserve the existing 9-control neutral behavior.
The existing rig says neutral facial controls: mixed states require evidence,
not merely deleting this restriction. Snapshot pins must include head inputs;
accepted state must not advance after failed/pending/closed admission. Existing
stop/restart/drain behavior and bounded scratch remain unchanged.

## Initial implemented candidate (not final product acceptance)

Nine existing eye inputs retain their order. Two source controls Head Turn/Tilt
append at indices 9/10 with [-1,1], default 0. The native bridge accepts old 9
or new 11 double values, validates before float conversion, copies into the
existing snapshot. Both rendering paths prepare continuous rig values from that
retained snapshot. Zero head inputs bypass rig as before to preserve neutral
pixels. No pose-index quantization, new motion, or new cleanup implementation.

Host O2 and ASan/UBSan (LSan disabled) each pass five inputs (neutral, head-only, three mixed): synchronous
versus 34-yield cursor rendering, mutation of original controls during yields,
no free snapshot writer, strip failure followed by retry of the same snapshot,
and final lease drain. Neutral hash 91e4dc4d matches an independently compiled
recovered baseline. Head-only hash630d3112 differs with unchanged eye controls. Invalid head values leave snapshot byte-identical. Retry pixels are cleared and all34 strips required. Other hashes c131e67e,439b37cd,eaa31b67. Snapshot grows
15976→15984 bytes (+8 each, two allocated); render_scratch stays86848 bytes.
This does not establish owner-level close/restart, actual JS native bridge,
QEMU/device behavior, allocation overhead, stack or timing yet.

Blender read-only mixed dependency checks (three sampled states) yield maximum
local difference4.768e-7, world matrices exact. This tests separability, not the
final rendered image against Blender. Independent DQ oracle has separate64-pose
record comparisons. Recomputed normals remain unused by the unlit fragment
shader; no lighting fidelity claim. Renderer remains private/exclusive, not AYNM.

## Independent reviews

Scene reviewer rebuilt a separate harness with8 inputs (mixed4+head-only4), O2
and ASan/UBSan PASS, no product blocker; complete retry output checks included.
FW reviewer measured five allocation requests122656→122672 (+16 bytes), stack
compiler estimates unchanged for render functions (304/128/144), prepare640 plus
new wrapper48 bounded, not hardware high-water marks. Real bridge.c+QuickJS
ASan/UBSan passed3 new runtimes:9/11 input, wrong lengths/domain rejection,
sequence stable, close rejection and reinstall. The composed backend was a stub.
Actual composed owner-level4cycle/SPI drain/QEMU product run was NOT executed.
Thus no new claim of full product scheduling, hardware memory headroom or20FPS.
