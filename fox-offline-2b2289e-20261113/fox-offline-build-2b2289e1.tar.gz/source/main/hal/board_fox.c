#include "board_fox.h"
#include "lease_spi.h"
#include "render_adapter.h"
#include "freertos/task.h"
#include <stddef.h>
#include <stdint.h>
/* Fixed storage, no framebuffer/copy allocation. Real LCD queue_size is one:
 * never queue a second unreaped descriptor even if the driver has dispatched
 * the first, since its return queue also has capacity one. The generic ledger
 * has two slots for independent ABI tests; the board uses at most one. */
static lease_spi transport;
static TaskHandle_t owner;
static bool acquired,closed;
static esp_err_t failure;
static int next_y=-1,setup_y;
static unsigned setup_phase;
static bool setup_active,setup_pending;
/* Pixel enqueue has a bounded wait. Command/result progress is nonblocking
 * through prepare/pump; an ambiguous queue error is never treated as abort. */
#define FOX_SPI_WAIT pdMS_TO_TICKS(25)
_Static_assert(offsetof(leased_strip,pixels)%4==0,"pixels must be word aligned");
_Static_assert(sizeof(((leased_strip*)0)->pixels)==1920,"bounded four-row strip");
static bool owned(void){return acquired&&owner==xTaskGetCurrentTaskHandle();}
static esp_err_t failed(esp_err_t e){if(e!=ESP_OK&&failure==ESP_OK)failure=e;next_y=-1;return e;}
bool board_fox_active(void){return acquired;}
bool board_fox_idle(void){return lease_spi_idle(&transport);}
esp_err_t board_fox_error(void){return failure;}
esp_err_t board_fox_begin(void){
 if(acquired){
  if(!owned()||closed||!board_fox_idle())return ESP_ERR_INVALID_STATE;
  /* Repeated begin cannot rewind a partially prepared/current window. A new
   * full frame naturally ends at row135; failed attempts reset after drain. */
  if(failure==ESP_OK&&(setup_active||next_y>=0))return ESP_OK;
 }else{
  spi_device_handle_t device=NULL;bool le=false;
  esp_err_t e=board_fox_port_acquire(&device,&le);if(e!=ESP_OK)return e;
  if(!device||!le){board_fox_port_release();return ESP_ERR_INVALID_STATE;}
  e=lease_spi_open(&transport,device);if(e!=ESP_OK){board_fox_port_release();return e;}
  owner=xTaskGetCurrentTaskHandle();acquired=true;closed=false;
 }
 failure=ESP_OK;next_y=-1;setup_active=setup_pending=false;setup_phase=0;return ESP_OK;
}
esp_err_t board_fox_pump(TickType_t wait){
 if(!owned())return ESP_ERR_INVALID_STATE;
 unsigned before=lease_spi_pending(&transport);
 esp_err_t e=lease_spi_reap(&transport,wait);
 if(setup_pending&&before&&!lease_spi_pending(&transport)){
  setup_pending=false;
  if(e==ESP_OK){
   setup_phase++;
   if(setup_phase==5){setup_active=false;next_y=setup_y;}
  }
 }
 /* A nonblocking poll not ready is normal. The caller deciding that a frame
  * could not finish records that attempt's timeout independently. */
 if(e!=ESP_OK&&(e!=ESP_ERR_TIMEOUT||lease_spi_pending(&transport)<before))failed(e);
 return e;
}
esp_err_t board_fox_drain(TickType_t wait){
 if(!owned())return ESP_ERR_INVALID_STATE;
 while(!board_fox_idle()){
  unsigned before=lease_spi_pending(&transport);
  esp_err_t e=board_fox_pump(wait);
  if(lease_spi_pending(&transport)==before)return e;
  /* Exact descriptor + error is retired; finish other known descriptors. */
 }
 return failure;
}
esp_err_t board_fox_close(void){
 if(!owned())return ESP_ERR_INVALID_STATE;
 closed=true;next_y=-1;setup_active=false;lease_spi_close(&transport);return ESP_OK;
}
esp_err_t board_fox_end(void){
 if(!owned()||!closed||!board_fox_idle())return ESP_ERR_INVALID_STATE;
 /* Sole owner has stopped producing/reaping, and there are no lease callbacks
  * in ISR. Under IDF's exactly-once result contract this is source quiescence. */
 board_fox_port_release();acquired=false;owner=NULL;return ESP_OK;
}
esp_err_t board_fox_prepare(int y){
 if(!owned()||closed)return ESP_ERR_INVALID_STATE;
 if(y<0||y>=135)return failed(ESP_ERR_INVALID_ARG);
 if(failure!=ESP_OK)return failure;
 /* Never overwrite a window request while its command sequence is pending. */
 if(setup_active&&y!=setup_y)return ESP_ERR_INVALID_STATE;
 for(unsigned work=0;work<6;work++){
  if(!board_fox_idle()){
   esp_err_t e=board_fox_pump(0);
   if(e!=ESP_OK)return e;
  }
  if(failure!=ESP_OK)return failure;
  if(next_y==y&&!setup_active)return ESP_OK;
  if(!setup_active){setup_active=true;setup_y=y;setup_phase=0;}
  const uint16_t y0=(uint16_t)(53+setup_y);
  const uint8_t xs[]={0,40,1,23};
  const uint8_t ys[]={(uint8_t)(y0>>8),(uint8_t)y0,0,187};
  const uint8_t commands[]={0x2a,0x2b,0x2c};
  bool data=setup_phase==1||setup_phase==3;
  const void *bytes=data?(setup_phase==1?(const void*)xs:(const void*)ys):&commands[setup_phase/2];
  board_fox_port_dc(data);
  /* Completion may be observed inline by a test ABI callback. Publish command
   * state first, just as the generic layer publishes its descriptor record. */
  setup_pending=true;
  esp_err_t e=lease_spi_command(&transport,bytes,data?4u:1u,0);
  if(e!=ESP_OK)return failed(e);
 }
 return ESP_ERR_TIMEOUT;
}
static esp_err_t reject(lease_pool *p,lease_ticket t,esp_err_t e){
 if(!p||!lease_complete(p,t))return failed(ESP_ERR_INVALID_STATE);
 return failed(e);
}
esp_err_t board_fox_submit(lease_pool *p,lease_ticket t,const uint16_t *pixels,
                           int x,int y,int width,int height){
 /* Reusing a transferred ticket cannot release the original in-flight pin. */
 if(lease_spi_owns_ticket(&transport,p,t))return failed(ESP_ERR_INVALID_STATE);
 const void *payload=NULL;
 if(!lease_spi_ticket_payload(p,t,&payload))return failed(ESP_ERR_INVALID_STATE);
 if(!owned()||closed)return reject(p,t,ESP_ERR_INVALID_STATE);
 if(x!=0||width!=240||y<0||height<1||height>4||y>135-height||
    pixels!=((const leased_strip*)payload)->pixels)
  return reject(p,t,ESP_ERR_INVALID_ARG);
 if(failure!=ESP_OK)return reject(p,t,failure);
 /* The resumable cursor must prepare first. Do not take over a pending
  * command or wait/replay window setup inside the pixel submission. */
 if(!board_fox_idle()||setup_active||next_y!=y)
  return reject(p,t,ESP_ERR_INVALID_STATE);
 esp_err_t e;
 board_fox_port_dc(true);
 e=lease_spi_submit_ticket(&transport,p,t,sizeof(leased_strip),offsetof(leased_strip,pixels),
                            (size_t)width*height*2u,FOX_SPI_WAIT);
 if(e!=ESP_OK)return failed(e);
 next_y=y+height<135?y+height:-1;return ESP_OK;
}
