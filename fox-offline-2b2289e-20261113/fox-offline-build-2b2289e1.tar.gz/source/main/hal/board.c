#include "derby_detail.h"
#include "board.h"
#include "board_fox.h"
#include "keyboard_probe.h"
#include "motion.h"
#include "sound.h"
#include "ui/kasane/ksn_p0_probe.h"
#include "lcd_spi.h"
#include "driver/gpio.h"
#include "driver/spi_master.h"
#include "driver/i2c_master.h"
#include "esp_adc/adc_oneshot.h"
#include "esp_adc/adc_cali.h"
#include "esp_adc/adc_cali_scheme.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"
#include "esp_timer.h"
#include "esp_log.h"
#include <string.h>
#include <stdio.h>
#ifdef KASANE_P0_BUS_PROBE
#include <stdatomic.h>
#include "esp_attr.h"
#endif

static spi_device_handle_t lcd;
static i2c_master_dev_handle_t keyboard;
// One strip for the whole firmware. The home screen, both editors and a running
// app all draw from ui_task's single loop, so no two of them ever hold pixels at
// the same time. Five private copies of this used to cost 15 KB of the 512 KB
// budget. The transfer below is a queue and it does NOT split this buffer in two:
// it copies each strip into the panel's own tx_buf before queueing, so the caller
// can go straight on reusing this one for the next strip.
// 16, not 4: the PIE 128-bit accesses below force the low four address bits to
// zero rather than faulting, so a misaligned buffer would silently read and
// write somewhere else. A row is 480 bytes, itself a multiple of 16, so every
// row start lands correctly once the base does.
static uint16_t shared[LCD_W * STRIP_H] __attribute__((aligned(16)));
uint16_t *board_strip(void) { return shared; }
// The A/B switch for the asynchronous transfer below: 1 = queue the strip and
// come back for its result on the next call (the shipping path), 0 = the
// blocking polling transfer this file has always used. Both paths are in ONE
// binary because the same kernel moves 15% between builds from instruction-cache
// alignment alone (CLAUDE.md), and the queued-vs-blocking question was smaller
// than that.
//
// It is FIXED at 1 now. shell.c used to invert it once per 2-second PERF window
// so adjacent windows of the same run were the two paths; that measurement is
// done (docs/perf/pie-opt-plan.md (pie-consolidation section) 3b: FLOWER draw 38.73 -> 33.30 ms, fps
// 24.95 -> 28.80) and a shipped build must not spend every other window on the
// path it rejected. The setter stays for the next A/B -- nothing calls it in
// this build.
int g_board_async = 1;
// The same switch through a function, for the PERF report.
int board_async_get(void) { return g_board_async; }
void board_async_set(int on) { g_board_async = on ? 1 : 0; }
// TEMPORARY A/B switch inside the queued path: 1 = byte-swap straight into the
// panel buffer that is not in flight (one pass, `shared` left as drawn), 0 = swap
// `shared` in place and memcpy it across, as 7fd965f shipped. Same pixels on the
// wire either way; one binary for the same reason as g_board_async.
int g_board_swap_into = 1;
// The panel's own copies. `shared` stays the one buffer every screen draws into
// (17 call sites hold that pointer for a whole frame), so the asynchronous path
// COPIES a strip here instead of handing the caller a second buffer: 3,840 bytes
// of memcpy is ~10 us against the ~440 us of SPI the copy lets the CPU skip.
// One TX payload; every write waits for the exact previous descriptor.
// Native UI loses copy/DMA overlap; the stable shared drawing strip remains.
#if !(defined(BOARD_STRIP_HALF)&&BOARD_STRIP_HALF)
static uint16_t tx_buf[LCD_W * STRIP_H] __attribute__((aligned(16)));
#else
// Design 0 (board.h, docs/platform/lcd-dma-driver.md 9.5): no tx_buf. The
// strip's two 4-row halves take turns: one is sent from where it was drawn
// while the other is drawn. half_lent is the half board_strip_next handed out
// last (a present of it goes out asynchronously); half_from the one in
// flight. Any other buffer -- a screen's own whole strip -- is sent and
// finished before board_present returns, since its caller draws into it
// again at once.
static uint16_t *half_lent, *half_from;
#if (defined(BOARD_BUF_AB)&&BOARD_BUF_AB)||(defined(BOARD_LCD_DEPTH2)&&BOARD_LCD_DEPTH2)
#error "BOARD_STRIP_HALF has no tx_buf: the measurement builds need it off"
#endif
#endif
// The panel's byte order (RAMCTRL 0xB0, second parameter, ENDIAN = bit 3).
// false: the ST7789's reset order, MSB first, so every strip is byte-swapped
// on its way out. true: LSB first, the order the CPU draws in, so the strip
// goes as drawn. Whether a 4-line SPI ST7789 honours ENDIAN is not in any
// document we have (ESP-IDF's driver sets it; reports are from 8080 buses),
// and MISO is unwired, so the only test is the glass: BOARD_ENDIAN_PROBE
// alternates the two every 2 s and the owner looks for a change.
static bool lcd_le;
#ifdef CONFIG_POCKET_FRAME_BREAKDOWN
// FRAME_BD: strips queued to the SPI driver, one completion ISR each.
static _Atomic uint32_t lcd_tx_n;
uint32_t board_lcd_tx_take(void) { return atomic_exchange(&lcd_tx_n, 0u); }
#define LCD_TX_COUNT(e) do { if ((e) == ESP_OK) atomic_fetch_add(&lcd_tx_n, 1u); } while (0)
#else
#define LCD_TX_COUNT(e) ((void)0)
#endif
#define BOARD_ENDIAN_PROBE 0   /* issue #118: the eye test passed 2026-11-04 (docs/platform/lcd-dma-driver.md 9.2) */
static void put_strip(uint16_t *out,uint16_t *in,int count);
static bool tx_inflight;
// The descriptor must outlive the queued transaction: spi_device_queue_trans
// keeps the pointer until the result is reaped.
static spi_transaction_t tx_pending;
// Zero-copy (board.h): the slot (shared or tx_buf) the strip in flight is
// sent from, NULL when the strip went out of a copy.
#if defined(BOARD_BUF_AB)&&BOARD_BUF_AB
int g_board_zero_copy = 0;
// Design 2 (board.h): strips go into lcd_spi.c's row ring, built from
// tx_buf's 8 rows and these 4 (+1,920 B).
static int g_board_ring = 0;
// Design 0 (board.h): the strip's two 4-row halves take turns (Kasane draws
// 4-row pieces), so one 8-row buffer both draws and sends.
static int g_board_half = 0;
static bool ring_ready;
static uint16_t ring_extra[4 * LCD_W] __attribute__((aligned(16)));
static uint16_t *tx_from;
// A strip that can be sent where it lies: one of the two slots, pixels LSB
// first. Anything else (another screen's buffer) takes the copy.
static bool zero_copy_strip(const uint16_t *pixels) {
    return g_board_zero_copy && lcd_le &&
           (pixels == shared || pixels == tx_buf || pixels == shared + 4 * LCD_W);
}
#endif
int board_strip_rows(void) {
#if defined(BOARD_STRIP_HALF)&&BOARD_STRIP_HALF
    return 4;
#elif defined(BOARD_BUF_AB)&&BOARD_BUF_AB
    return g_board_half ? 4 : STRIP_H;
#else
    return STRIP_H;
#endif
}
uint16_t *board_strip_next(void) {
#if defined(BOARD_STRIP_HALF)&&BOARD_STRIP_HALF
    // At most one strip is in flight (queue_size 1), so the other half is free.
    half_lent = (tx_inflight && half_from == shared) ? shared + 4 * LCD_W : shared;
    return half_lent;
#endif
#if defined(BOARD_BUF_AB)&&BOARD_BUF_AB
    // At most one strip is in flight (queue_size 1), so the other is free.
    if (g_board_half) return (tx_inflight && tx_from == shared) ? shared + 4 * LCD_W : shared;
    if (g_board_zero_copy) return (tx_inflight && tx_from == shared) ? tx_buf : shared;
#endif
    return shared;
}
#if defined(BOARD_LCD_DIRECT)&&BOARD_LCD_DIRECT
// Direct sends (board.h). tx_direct: the strip in flight went out through
// lcd_spi.c, so its completion is the SPI's done bit, not a queue result.
static int g_board_direct = 1;
static bool tx_direct;
#endif
#if defined(BOARD_LCD_DEPTH2)&&BOARD_LCD_DEPTH2
// Depth 2 (board.h): the second panel buffer and its descriptor. Strips go to
// the two slots in turn; tx_queued of them (0..2) are owned by the driver,
// the oldest at slot (tx_next - tx_queued). spi_master returns results in
// queue order, so reaping one always frees the oldest slot.
int g_board_depth = 2;
static uint16_t tx_buf_b[LCD_W * STRIP_H] __attribute__((aligned(16)));
static spi_transaction_t tx_pending_b;
static unsigned tx_queued, tx_next;
static uint16_t *const tx_slot_buf[2] = {tx_buf, tx_buf_b};
static spi_transaction_t *const tx_slot_desc[2] = {&tx_pending, &tx_pending_b};
#endif
#ifdef KASANE_P0_BUS_PROBE
/* Diagnostic only. SPI post_cb runs in the SPI2 ISR just before the driver
 * places the result on ret_queue. This is an ISR-service timestamp, not the
 * exact hardware DMA completion edge. Both tasks use the same esp_timer clock. */
static atomic_uint lcd_data_isr_us;
static atomic_int lcd_data_isr_core=ATOMIC_VAR_INIT(-1);
static bool lcd_isr_reported;
int board_lcd_isr_core(void){
    return atomic_load_explicit(&lcd_data_isr_core,memory_order_relaxed);
}
static void IRAM_ATTR lcd_post_cb(spi_transaction_t *trans){
    if(trans->user==&lcd_data_isr_us){
        atomic_store_explicit(&lcd_data_isr_core,xPortGetCoreID(),memory_order_relaxed);
        atomic_store_explicit(&lcd_data_isr_us,(uint32_t)esp_timer_get_time(),
                              memory_order_relaxed);
    }
}
#endif
// Reap the strip queued last time. One transaction is in flight at a time
// (the LCD device is configured with queue_size=1), so this is also the barrier
// every command goes through before it ends the RAMWR session. Returns the
// transfer's own error, or ESP_OK when there was nothing in flight.
#if defined(BOARD_LCD_DEPTH2)&&BOARD_LCD_DEPTH2
// Reaps the oldest queued strip. A result that is not the expected descriptor
// is a failure and leaves the slot owned, as tx_reap below does.
static esp_err_t tx_reap_one_wait(TickType_t wait) {
    if(board_fox_active())return ESP_ERR_INVALID_STATE;
    spi_transaction_t *want = tx_slot_desc[(tx_next + 2 - tx_queued) & 1], *done = NULL;
    DD_SCOPE(DD_TX_REAP);
    DD_ADD(DD_TX_REAPS,1);
    esp_err_t e = spi_device_get_trans_result(lcd, &done, wait);
    if (e == ESP_OK && done != want) e = ESP_ERR_INVALID_STATE;
    DD_ADD(DD_TX_FAILURES,e!=ESP_OK);
    if (done == want) tx_queued--;
    tx_inflight = tx_queued != 0;
    return e;
}
#endif
static esp_err_t tx_reap_wait(TickType_t wait) {
    if(board_fox_active())return ESP_ERR_INVALID_STATE;
#if defined(BOARD_LCD_DEPTH2)&&BOARD_LCD_DEPTH2
    // Every queued strip: the barrier for commands, sync and finish.
    while (tx_queued) {
        esp_err_t e = tx_reap_one_wait(wait);
        if (e != ESP_OK) return e;
    }
    return ESP_OK;
#endif
    if (!tx_inflight) return ESP_OK;
#if defined(BOARD_BUF_AB)&&BOARD_BUF_AB
    if (g_board_ring) {
        DD_SCOPE(DD_TX_REAP);
        DD_ADD(DD_TX_REAPS,1);
        esp_err_t e = lcd_spi_ring_drain();
        DD_ADD(DD_TX_FAILURES,e!=ESP_OK);
        tx_inflight = false;
        return e;
    }
#endif
#if defined(BOARD_LCD_DIRECT)&&BOARD_LCD_DIRECT
    if (tx_direct) {
        DD_SCOPE(DD_TX_REAP);
        DD_ADD(DD_TX_REAPS,1);
        esp_err_t e = lcd_spi_direct_wait();
        DD_ADD(DD_TX_FAILURES,e!=ESP_OK);
        tx_direct = false;
        tx_inflight = false;
        return e;
    }
#endif
    DD_SCOPE(DD_TX_REAP);
    DD_ADD(DD_TX_REAPS,1);
#ifdef KASANE_P0_BUS_PROBE
    bool sd_before=ksn_p0_bus_sd_active();
    uint32_t sd_epoch_before=ksn_p0_bus_sd_epoch();
    int64_t began=esp_timer_get_time();
#endif
    spi_transaction_t *done = NULL;
    esp_err_t e = spi_device_get_trans_result(lcd, &done, wait);
    /* A successful driver status without our descriptor is still a failed
     * reap. Normalize before counting, while retaining the driver's borrow. */
    if(e==ESP_OK&&done!=&tx_pending)e=ESP_ERR_INVALID_STATE;
    DD_ADD(DD_TX_FAILURES,e!=ESP_OK);
#ifdef KASANE_P0_BUS_PROBE
    uint32_t finished=(uint32_t)esp_timer_get_time();
    uint32_t elapsed=finished-(uint32_t)began;
    ksn_p0_bus_phase_sample(KSN_P0_BUS_REAP,
        elapsed,
        sd_before||ksn_p0_bus_sd_active()||
        sd_epoch_before!=ksn_p0_bus_sd_epoch());
    uint32_t isr=atomic_load_explicit(&lcd_data_isr_us,memory_order_relaxed);
    if(isr){
        /* The ISR may already have run before the UI entered get_result. */
        uint32_t pre=(int32_t)(isr-(uint32_t)began)>0?isr-(uint32_t)began:0u;
        if(pre>elapsed)pre=elapsed;
        ksn_p0_bus_phase_sample(KSN_P0_BUS_PRE_ISR,pre,false);
        ksn_p0_bus_phase_sample(KSN_P0_BUS_POST_ISR,elapsed-pre,false);
    }else ksn_p0_bus_missing_isr();
    if(!lcd_isr_reported){
        int core=atomic_load_explicit(&lcd_data_isr_core,memory_order_relaxed);
        if(core>=0){
            lcd_isr_reported=true;
            ESP_LOGI("board","P1 LCD ISR observed core %d, UI reap core %d",
                     core,xPortGetCoreID());
        }
    }
#endif
    /* Every entry point, including native UI and DMA OFF, must retain the
     * payload and descriptor until the driver returns this exact descriptor. */
    tx_inflight = done != &tx_pending;
    return e;
}
static esp_err_t tx_reap(void){return tx_reap_wait(portMAX_DELAY);}
#if defined(BOARD_LCD_DEPTH2)&&BOARD_LCD_DEPTH2
// Before copying a strip: depth 1 waits for everything (today), depth 2 only
// for the slot the copy is about to overwrite.
static esp_err_t tx_reap_slot(void) {
    if (g_board_depth < 2) return tx_reap();
    return tx_queued >= 2 ? tx_reap_one_wait(portMAX_DELAY) : ESP_OK;
}
#endif
// Open RAMWR position and horizontal bounds. A -1 row means no reusable window.
static uint16_t window_x,window_cols;
static bool capture,capture_turn_taken;
static int next_row = -1;
void board_capture(bool enabled) {
    next_row=-1;
    capture=enabled;capture_turn_taken=false;
    printf(enabled?"CAPTURE_BEGIN 240 135\n":"CAPTURE_END\n");
}
bool board_capture_active(void) { return capture; }
// Called after the renderer's completion barrier, including failed frames.
// Invalidating addressing never releases a descriptor or acknowledges DMA.
void board_present_frame_end(void) { next_row=-1; }
bool board_capture_take_turn(void) {
    if(!capture||capture_turn_taken)return false;
    capture_turn_taken=true;
    return true;
}

static esp_err_t tx(bool data, const void *bytes, size_t n) {
    gpio_set_level(34, data);
    spi_transaction_t t = {.length = n * 8, .tx_buffer = bytes};
    return spi_device_polling_transmit(lcd, &t);
}
static esp_err_t command(uint8_t c, const void *data, size_t n) {
    // Any command at all ends the RAMWR session, so nothing may be in flight
    // when one starts: reap first (the queued strip is still ordered before it).
    // next_row is -1 either way, because a command ends the session.
    esp_err_t prior=tx_reap();
    next_row=-1;
    if(prior!=ESP_OK)return prior;
    esp_err_t e = tx(false, &c, 1);
    return e == ESP_OK && n ? tx(true, data, n) : e;
}
static esp_err_t set_endian(bool le){
    const uint8_t ramctrl[]={0x00,(uint8_t)(0xF0|(le?0x08:0x00))};
    esp_err_t e=command(0xb0,ramctrl,2);
    if(e==ESP_OK)lcd_le=le;
    return e;
}
#if defined(BOARD_ENDIAN_AB)&&BOARD_ENDIAN_AB
// Measurement build (board.h): flips between LSB first with no swap and MSB
// first with the swap, at a frame boundary. Returns the new LSB-first state.
int board_endian_ab_flip(void){
    if(set_endian(!lcd_le)!=ESP_OK)return -1;
    return lcd_le?1:0;
}
#endif
#if defined(BOARD_LCD_DIRECT)&&BOARD_LCD_DIRECT
int board_lcd_direct_set(int on) {
    // Both paths must be idle before the bus changes hands.
    if (tx_reap() != ESP_OK) return g_board_direct;
    if (on && !g_board_direct) lcd_spi_direct_enter();
    if (!on && g_board_direct) lcd_spi_direct_leave();
    g_board_direct = on ? 1 : 0;
    return g_board_direct;
}
uint32_t board_lcd_direct_underruns(void) { return lcd_spi_direct_underruns(); }
#endif
#if defined(BOARD_BUF_AB)&&BOARD_BUF_AB
int board_buf_mode(void) { return g_board_ring ? 3 : g_board_half ? 2 : g_board_zero_copy ? 1 : 0; }

uint32_t board_buf_underruns(void) { return lcd_spi_direct_underruns(); }
int board_buf_mode_set(int mode) {
    if (tx_reap() != ESP_OK) return -1;
    if (g_board_ring && mode != 3) lcd_spi_ring_leave();
    if (mode == 3 && !g_board_ring) {
        if (!ring_ready) {
            uint16_t *rows[LCD_SPI_RING_ROWS];
            for (int k = 0; k < 8; k++) rows[k] = tx_buf + k * LCD_W;
            for (int k = 0; k < 4; k++) rows[8 + k] = ring_extra + k * LCD_W;
            // From the UI task, so the GDMA interrupt lands on its core.
            if (lcd_spi_ring_init(rows) != ESP_OK) return -1;
            ring_ready = true;
        }
        lcd_spi_ring_enter();
    }
    g_board_ring = mode == 3;
    g_board_half = mode == 2;
    g_board_zero_copy = mode == 1 || mode == 2;
    return mode;
}
#endif
#if BOARD_ENDIAN_PROBE
static int64_t endian_flip_us;
/* At a window change (no strip in flight, RAMWR about to reopen). */
static void endian_probe(void){
    const int64_t now=esp_timer_get_time();
    if(now-endian_flip_us<2000000)return;
    endian_flip_us=now;
    if(set_endian(!lcd_le)==ESP_OK)ESP_LOGI("board","LCD_ENDIAN le=%d",lcd_le?1:0);
}
#endif
static esp_err_t kwrite(uint8_t reg, uint8_t value) {
    uint8_t data[] = {reg, value};
    return i2c_master_transmit(keyboard, data, 2, 30);
}
static esp_err_t kread(uint8_t reg, uint8_t *value) {
    return i2c_master_transmit_receive(keyboard, &reg, 1, value, 1, 30);
}
static bool key_decode(uint8_t event, board_keyevent_t *out);
#ifdef CONFIG_POCKET_KEY_INT_PROBE
#define KEY_INT_PROBE 1
#else
#define KEY_INT_PROBE 0
#endif

// ---------------------------------------------------------------------------
// The panel wants each RGB565 pixel's two bytes the other way round.
//
// The S3's PIE unit does sixteen pixels a pass: two 128-bit loads, a
// de-interleave that gathers the even bytes into one register and the odd into
// the other, then a re-interleave with the two registers exchanged (TRM
// 1.8.209 and 1.8.212). There are no intrinsics for any of it, so this is
// assembly, and it is kept out of line because loopgtz drives the hardware loop
// registers and must not sit inside a loop the compiler is also driving.
//
// PIE is coprocessor 3, saved and restored on a task switch like the FPU, so
// this is safe in a task and not in an interrupt.
//
// Nothing here is trusted on faith: board_init runs both versions over the same
// bytes and only enables this one if they agree exactly.
// The display path was suspected of racing commands against a strip transfer. It
// does not: tx_reap() waits with portMAX_DELAY, command() calls it before every
// command, and tx()'s first argument is the DC line rather than a byte swap. The
// instruments that were going to prove otherwise measured nothing (they were taken
// while the UI task was blocked, see the note in shell.c) and are not kept.
static bool pie_swap;

// `in` and `out` may be the same buffer (the blocking path swaps in place) or
// two different aligned buffers (the queued path swaps straight into the panel's
// own copy): each block is loaded whole before either half is stored.
static void __attribute__((noinline)) swap_pie(uint16_t *in, uint16_t *out, unsigned blocks) {
    __asm__ volatile(
        "loopgtz %2, 1f\n"
        "  ee.vld.128.ip q0, %0, 16\n"
        "  ee.vld.128.ip q1, %0, 16\n"
        "  ee.vunzip.8   q0, q1\n"
        "  ee.vzip.8     q1, q0\n"
        "  ee.vst.128.ip q1, %1, 16\n"
        "  ee.vst.128.ip q0, %1, 16\n"
        "1:\n"
        : "+a"(in), "+a"(out)
        : "a"(blocks)
        : "memory");
}

static void swap_scalar(uint16_t *out, const uint16_t *in, int count) {
    for(int i=0;i<count;i++) out[i]=(uint16_t)((in[i]<<8)|(in[i]>>8));
}
/* A strip on its way to the panel: swapped for an MSB-first panel, as drawn
 * for an LSB-first one. in==out swaps in place (no copy when LSB first). */
static void put_strip(uint16_t *out,uint16_t *in,int count){
    if(lcd_le){if(out!=in)memcpy(out,in,(size_t)count*2u);return;}
    if(pie_swap&&((uintptr_t)in&15u)==0&&((uintptr_t)out&15u)==0&&(count*2)%32==0)
        swap_pie(in,out,(unsigned)(count*2/32));
    else swap_scalar(out,in,count);
}

// 32 pixels is 64 bytes, two of the 32-byte blocks the vector loop consumes.
// Both spellings the transfer uses are checked: in place, and into another buffer.
static bool swap_agrees(void) {
    static uint16_t reference[32] __attribute__((aligned(16)));
    static uint16_t vectored[32]  __attribute__((aligned(16)));
    static uint16_t copied[32]    __attribute__((aligned(16)));
    for(int i=0;i<32;i++) reference[i]=vectored[i]=(uint16_t)(i*2477u+0x1234u);
    swap_pie(vectored,copied,sizeof(vectored)/32);
    swap_scalar(reference,reference,32);
    swap_pie(vectored,vectored,sizeof(vectored)/32);
    return memcmp(reference,vectored,sizeof(reference))==0 &&
           memcmp(reference,copied,sizeof(reference))==0;
}
uint16_t board_rgb(unsigned r, unsigned g, unsigned b) {
    return ((r >> 3) << 11) | ((g >> 2) << 5) | (b >> 3);
}

// ---------------------------------------------------------------------------
// Battery voltage.
//
// The pack reaches GPIO10 -- ADC1 channel 9 on the S3 -- through a 100k/100k
// divider, so the reading is half the cell voltage. Three sources agree:
// M5Unified's Power_Class.cpp gives board_M5CardputerADV _batAdcPin 10,
// _batAdcUnit 1 and _adc_ratio 2.0f; the official ADV pinout lists Battery_ADC
// on G10; and schematic v1.0 shows R8 and R12 as the two 100k legs.
//
// What the board does not have is anything to ask about charging. The charger
// is a TP4057 whose CHRG and STDBY pins drive only the indicator LED, there is
// no PMIC and no fuel gauge on the I2C bus, and M5Stack's own documentation
// says so in as many words. So this reports millivolts and nothing else: no
// percentage, since nobody here has characterised the cell, and no charging
// flag, since there is no wire to read one from. With USB plugged in the
// reading sits near a full pack whatever its real state, and with the side
// switch off the pack is disconnected entirely.
//
// None of the above has been checked against a meter on this unit yet.
static adc_oneshot_unit_handle_t battery_adc;
static adc_cali_handle_t battery_cali;
static SemaphoreHandle_t battery_lock;
static int64_t battery_time;
static int battery_mv;

static void battery_init(void) {
    adc_oneshot_unit_init_cfg_t unit = {.unit_id = ADC_UNIT_1};
    if (adc_oneshot_new_unit(&unit, &battery_adc) != ESP_OK) { battery_adc=NULL; goto absent; }
    adc_oneshot_chan_cfg_t chan = {.atten = ADC_ATTEN_DB_12, .bitwidth = ADC_BITWIDTH_12};
    if (adc_oneshot_config_channel(battery_adc, ADC_CHANNEL_9, &chan) != ESP_OK) goto absent;
    // Without the calibration curve the converter gives counts, not volts, and
    // the linear guess that would turn one into the other is exactly the kind
    // of number this file refuses to invent. No curve, no reading.
    adc_cali_curve_fitting_config_t cali = {.unit_id = ADC_UNIT_1, .chan = ADC_CHANNEL_9,
        .atten = ADC_ATTEN_DB_12, .bitwidth = ADC_BITWIDTH_12};
    if (adc_cali_create_scheme_curve_fitting(&cali, &battery_cali) != ESP_OK) battery_cali=NULL;
    battery_lock = xSemaphoreCreateMutex();
    if (!battery_lock) goto absent;
    ESP_LOGI("board", "Battery ADC on GPIO10 (ADC1 ch9, x2 divider), calibration: %s",
             battery_cali ? "curve fitting" : "absent, readings disabled");
    return;
absent:
    ESP_LOGW("board", "Battery ADC unavailable");
    battery_cali = NULL;
}

bool board_battery_read(board_battery_t *out) {
    if (!battery_adc || !battery_cali || !battery_lock) return false;
    xSemaphoreTake(battery_lock, portMAX_DELAY);
    int64_t now = esp_timer_get_time();
    // A pack cannot move quickly and power status is a synchronous call an app
    // may make every frame, so one burst of conversions every half second is
    // more than the value can justify. Eight of them because a single 12-bit
    // read on this part is visibly noisy.
    if (!battery_time || now-battery_time > 500000) {
        int total=0, taken=0;
        for (int i=0;i<8;i++) {
            int raw=0, mv=0;
            if (adc_oneshot_read(battery_adc, ADC_CHANNEL_9, &raw) != ESP_OK) continue;
            if (adc_cali_raw_to_voltage(battery_cali, raw, &mv) != ESP_OK) continue;
            total += mv; taken++;
        }
        if (taken) { battery_mv = total*2/taken; battery_time = now; }
    }
    bool have = battery_time != 0;
    if (have) { out->millivolts = battery_mv; out->time_us = battery_time; }
    xSemaphoreGive(battery_lock);
    return have;
}
// ------------------------------------------------------------------ SPI3 bus
//
// The microSD slot (CS=12) and the EXT connector (CS=5) share MOSI=14, CLK=40
// and MISO=39 (docs/platform/hardware-constraints.md:45). The LCD uses SPI2,
// so card traffic cannot occupy its SPI device queue. Both hosts may still
// contend for shared DMA/memory bandwidth; see the P1 LCD/SD diagnostic.
//
// The bus lives here, beside the LCD's, rather than inside whichever driver
// happens to come up first. Exactly one caller may spi_bus_initialize a host;
// two owners is a real failure and putting this next to the other bus owner is
// what stops it being possible. Drivers add their own DEVICES and interleave at
// transaction granularity, which the SPI master driver already serialises -- so
// a mounted card does not exclude io.spi when that arrives, and neither has to
// know about the other.
//
// Lazy: a board that never mounts a card should not pay for a DMA channel. And
// never torn down, because by then a second device may be sharing it.
static bool spi3_up;

esp_err_t board_spi3_acquire(void) {
    if (spi3_up) return ESP_OK;
    spi_bus_config_t bus = {.mosi_io_num=14, .miso_io_num=39, .sclk_io_num=40,
        .quadwp_io_num=-1, .quadhd_io_num=-1, .max_transfer_sz=4096};
    esp_err_t e = spi_bus_initialize(SPI3_HOST, &bus, SPI_DMA_CH_AUTO);
    if (e != ESP_OK) return e;
    spi3_up = true;
    ESP_LOGI("board","SPI3 up: SD CS=12, EXT CS=5 share MOSI=14 CLK=40 MISO=39");
    return ESP_OK;
}

esp_err_t board_init(void) {
    gpio_config_t g = {.pin_bit_mask = (1ULL<<33)|(1ULL<<34)|(1ULL<<38), .mode = GPIO_MODE_OUTPUT};
    ESP_ERROR_CHECK(gpio_config(&g));
    gpio_set_level(38, 0); gpio_set_level(33, 0); vTaskDelay(pdMS_TO_TICKS(20));
    gpio_set_level(33, 1); vTaskDelay(pdMS_TO_TICKS(120));
    spi_bus_config_t bus = {.mosi_io_num=35, .miso_io_num=-1, .sclk_io_num=36,
        .quadwp_io_num=-1, .quadhd_io_num=-1, .max_transfer_sz=sizeof(shared)
#ifdef KASANE_P1_LCD_ISR_CORE1
        ,.isr_cpu_id=ESP_INTR_CPU_AFFINITY_1
#elif CONFIG_POCKET_LCD_ISR_CORE >= 0
        // Every strip completes in this ISR, which then wakes whoever reaps it
        // (~30 a frame): its core pays for that (POCKET_LCD_ISR_CORE help).
        ,.isr_cpu_id=CONFIG_POCKET_LCD_ISR_CORE ? ESP_INTR_CPU_AFFINITY_1 : ESP_INTR_CPU_AFFINITY_0
#endif
    };
    ESP_ERROR_CHECK(spi_bus_initialize(SPI2_HOST, &bus, SPI_DMA_CH_AUTO));
#ifdef KASANE_P1_LCD_ISR_CORE1
    ESP_LOGI("board","P1 LCD ISR affinity requested core 1, UI core %d",
             CONFIG_POCKET_UI_TASK_CORE);
#endif
    // 80MHz, not the 40MHz M5Stack ships. The panel's flex is short and the
    // ST7789 tolerates it: send went from 15.5ms to 9.1ms measured, and the
    // owner confirmed on the physical panel that nothing is corrupted. That
    // confirmation had to be by eye -- board_capture dumps the buffer before
    // the byte swap and the transfer, and MISO is unwired, so no software
    // check here can see what actually reaches the glass. Revert to 40000000
    // if any tearing or colour damage ever shows up.
    spi_device_interface_config_t dev = {.clock_speed_hz=80000000, .mode=0, .spics_io_num=37,
#if defined(BOARD_LCD_DEPTH2)&&BOARD_LCD_DEPTH2
        .queue_size=2
#else
        .queue_size=1
#endif
#ifdef KASANE_P0_BUS_PROBE
        ,.post_cb=lcd_post_cb
#endif
    };
    ESP_ERROR_CHECK(spi_bus_add_device(SPI2_HOST, &dev, &lcd));
#if defined(BOARD_BUF_AB)&&BOARD_BUF_AB
    ESP_ERROR_CHECK(lcd_spi_direct_init());
#endif
#if defined(BOARD_LCD_DIRECT)&&BOARD_LCD_DIRECT
    ESP_ERROR_CHECK(lcd_spi_direct_init());
    if (g_board_direct) lcd_spi_direct_enter();
#endif
    pie_swap=swap_agrees();
    // Says which clock is in the binary. Several sessions share this tree, and
    // a measurement once moved 6ms because a clock change nobody remembered
    // making was sitting in the working copy.
    ESP_LOGI("board","LCD SPI %d Hz, byte swap: %s",
             dev.clock_speed_hz, pie_swap?"PIE":"scalar (PIE disagreed)");
    ESP_ERROR_CHECK(command(0x01, NULL, 0)); vTaskDelay(pdMS_TO_TICKS(150));
    ESP_ERROR_CHECK(command(0x11, NULL, 0)); vTaskDelay(pdMS_TO_TICKS(120));
    uint8_t format=0x55, orientation=0x60;
    ESP_ERROR_CHECK(command(0x3a, &format, 1));
    ESP_ERROR_CHECK(command(0x36, &orientation, 1));
    // LSB-first pixels (RAMCTRL ENDIAN): strips go out as drawn, and put_strip
    // copies instead of byte-swapping. This 4-wire ST7789 honours it -- the
    // owner's eye test of 2026-11-04 (docs/platform/lcd-dma-driver.md 9.2),
    // with a deliberate-mismatch phase to show the test could see a wrong one.
    ESP_ERROR_CHECK(set_endian(true));
    ESP_LOGI("board","LCD byte order: LSB first (no swap)");
    ESP_ERROR_CHECK(command(0x21, NULL, 0));
    ESP_ERROR_CHECK(command(0x29, NULL, 0));
    gpio_set_level(38, 1);
    i2c_master_bus_config_t ib = {.i2c_port=I2C_NUM_0, .sda_io_num=8, .scl_io_num=9,
        .clk_source=I2C_CLK_SRC_DEFAULT, .glitch_ignore_cnt=7, .flags.enable_internal_pullup=true};
    i2c_master_bus_handle_t ih;
    ESP_ERROR_CHECK(i2c_new_master_bus(&ib, &ih));
    i2c_device_config_t kd = {.dev_addr_length=I2C_ADDR_BIT_LEN_7, .device_address=0x34, .scl_speed_hz=400000};
    ESP_ERROR_CHECK(i2c_master_bus_add_device(ih, &kd, &keyboard));
    esp_err_t keyboard_error = keyboard_probe_startup(ih);
    if (keyboard_error != ESP_OK) return keyboard_error;
    // TCA8418: 7 electrical rows x 8 columns, internal debouncing enabled.
    ESP_ERROR_CHECK(kwrite(0x1d, 0x7f)); ESP_ERROR_CHECK(kwrite(0x1e, 0xff));
    ESP_ERROR_CHECK(kwrite(0x1f, 0));
    for (uint8_t r=0x29;r<=0x2b;r++) ESP_ERROR_CHECK(kwrite(r, 0));
    ESP_ERROR_CHECK(kwrite(0x01, 0x01));
    for (int i=0;i<10;i++) { uint8_t value; kread(0x04, &value); }
    ESP_ERROR_CHECK(kwrite(0x02, 0x1f));
#if CONFIG_POCKET_KEY_INT_GPIO >= 0
    // Open-drain, active low: the pull-up is what makes "no event" read 1.
    gpio_config_t key_int = {.pin_bit_mask=1ULL<<CONFIG_POCKET_KEY_INT_GPIO,
        .mode=GPIO_MODE_INPUT, .pull_up_en=GPIO_PULLUP_ENABLE};
    ESP_ERROR_CHECK(gpio_config(&key_int));
    ESP_LOGI("board", "KEY_INT gpio=%d level=%d%s", CONFIG_POCKET_KEY_INT_GPIO,
             gpio_get_level(CONFIG_POCKET_KEY_INT_GPIO), KEY_INT_PROBE ? " probe" : "");
#endif
    ESP_LOGI("board", "ADV keyboard detected; LCD 240x135 RGB565; no PSRAM");
    battery_init();
    motion_init(ih);
    sound_init(ih);
    return ESP_OK;
}
// The TCA8418 FIFO reports both edges: bit 7 set is a press, clear a release.
// Text input needs the releases to track which modifiers are still held, so
// this returns every event and leaves the interpretation to keymap.c.
//
// Overflow: the FIFO holds 10 events and CFG leaves OVR_FLOW_M at 0, so once it
// is full the controller drops NEW events and latches OVR_FLOW_INT (INT_STAT
// bit 3). The 0x1f written below clears that latch with the others, so it is
// read here first -- and only when the count says the FIFO is full, the one
// state in which anything can have been lost, so the ordinary path costs no
// extra I2C transfer. Whether the latch sets with OVR_FLOW_IEN off (CFG is
// 0x01) is a datasheet reading not yet confirmed on this board
// (docs/platform/keystate.md). If it stays silent, a lost release leaves that
// key reading as down until it is next pressed and released (keystate.h), and
// an app started meanwhile does not see it (pocket_input.c) -- not forever.
#if CONFIG_POCKET_KEY_INT_GPIO < 0
bool board_key_event(board_keyevent_t *out) {
    uint8_t count=0, event=0, status=0;
    if (kread(0x03, &count) != ESP_OK || !(count & 15)) return false;
    out->overflow=(count & 15) >= 10 && kread(0x02, &status) == ESP_OK && (status & 0x08);
    if (kread(0x04, &event) != ESP_OK) return false;
    kwrite(0x02, 0x1f);
    return key_decode(event, out);
}
#else
// With INT wired (CONFIG_POCKET_KEY_INT_GPIO), a poll that finds the pin high
// and nothing left over from the last count does no I2C at all: that empty
// read was ~0.3 ms of CPU 0 every 5 ms (frame-breakdown.md sec.11).
//
// Two things keep an event from hiding behind a high pin. key_left: the count
// said more events were queued behind the one just read, so the next polls read
// them whatever the pin says (whether INT stays low while the FIFO is not
// empty is not relied on). And the order: on a low pin the latch is cleared
// BEFORE the count is read, so an event that lands after the clear sets K_INT
// again and pulls the pin low, and one that landed before it is in the count.
// Clearing after the count (as the polling path does) could wipe the latch of
// an event the count had not seen. Only bits that were read are cleared.
//
// Safety net: every KEY_INT_RESCAN-th quiet poll reads the count anyway, so an
// event the pin did not report (the probe's 3 of 122 on the board were not told apart from a
// sample-then-read race)
// waits at most that many polls instead of until the next key.
#ifndef KEY_INT_RESCAN
#define KEY_INT_RESCAN 20u
#endif
static uint8_t key_left;
static unsigned key_quiet;
#if KEY_INT_PROBE
static uint32_t probe_polls, probe_skipped, probe_low, probe_events, probe_miss, probe_late;
static int64_t probe_last;
#endif
bool board_key_event(board_keyevent_t *out) {
    uint8_t count=0, event=0, status=0;
    const bool low = gpio_get_level(CONFIG_POCKET_KEY_INT_GPIO) == 0;
#if KEY_INT_PROBE
    probe_polls++; probe_low += low;
    const int64_t now = esp_timer_get_time();
    if (now - probe_last >= 2000000) {
        probe_last = now;
        ESP_LOGI("board", "KEY_INT_STAT polls=%u skipped=%u low=%u events=%u miss=%u late=%u",
                 (unsigned)probe_polls, (unsigned)probe_skipped, (unsigned)probe_low,
                 (unsigned)probe_events, (unsigned)probe_miss, (unsigned)probe_late);
    }
#endif
    if (!low && !key_left) {
#if KEY_INT_PROBE
        // What the gate would have skipped, read anyway, and handled as usual
        // so the probe drops none. An event that landed after the pin was
        // sampled pulls it low by now: the next poll would have read it
        // (late). Only one with the pin still high would have been lost (miss).
        probe_skipped++;
        if (kread(0x03, &count) != ESP_OK || !(count & 15)) return false;
        const bool late = gpio_get_level(CONFIG_POCKET_KEY_INT_GPIO) == 0;
        if (late) probe_late++; else probe_miss++;
        ESP_LOGW("board", "KEY_INT_%s count=%u", late ? "LATE" : "MISS", (unsigned)(count & 15));
#else
        if (++key_quiet < KEY_INT_RESCAN) return false;
        key_quiet = 0;
        if (kread(0x03, &count) != ESP_OK || !(count & 15)) return false;
#endif
    }
    key_quiet = 0;
    if (low) {
        if (kread(0x02, &status) != ESP_OK) return false;
        if (status) kwrite(0x02, status);
    }
    if (!count && (kread(0x03, &count) != ESP_OK || !(count & 15))) { key_left=0; return false; }
    if ((count & 15) >= 10 && !low) {
        // Overflow latched during a burst read with the pin high: clear that
        // bit alone, never K_INT, whose event the count may not include.
        uint8_t late=0;
        if (kread(0x02, &late) == ESP_OK && (late & 0x08)) { status |= 0x08; kwrite(0x02, 0x08); }
    }
    out->overflow=(status & 0x08) != 0;
    if (kread(0x04, &event) != ESP_OK) return false;
    key_left=(count & 15) - 1;
#if KEY_INT_PROBE
    probe_events++;
#endif
    return key_decode(event, out);
}
#endif
static bool key_decode(uint8_t event, board_keyevent_t *out) {
    int code=(event & 0x7f)-1;
    if (code < 0 || code/10 >= 7 || code%10 >= 8) return false;
    out->row=(code%10)%4;
    out->col=(code/10)*2+(code%10 >= 4);
    out->pressed=(event & 0x80)!=0;
    return true;
}
// Byte-swaps `pixels` in place and sends it. The caller repaints the strip
// before every present, so consuming the buffer costs nothing and saves a
// second one.
#include "pet_hub.h"
#include "pocket_capture.h"
// board.h: the host's overlays on every strip, unless a present on the
// display task (which may not read their state) turned them off.
bool board_host_overlays = true;
esp_err_t board_present(int y, int rows, uint16_t *pixels) {
    if(board_fox_active())return ESP_ERR_INVALID_STATE;
    if (y<0 || rows<1 || rows>STRIP_H || y+rows>LCD_H) return ESP_ERR_INVALID_ARG;
    if (board_host_overlays) pet_hub_overlay(pixels,y,rows);
    // docs/api/common-api.md 9 makes showing that the microphone is live the
    // host's obligation, so it is drawn here, at the one transfer to the
    // panel, rather than by whichever screen happens to be up: an app can
    // paint the corner it occupies, but not after this.
    if (board_host_overlays) pocket_capture_overlay(pixels,y,rows);
    if(capture) {
        static char line[LCD_W*4+1];
        const char *hex="0123456789abcdef";
        for(int r=0;r<rows;r++) {
            for(int x=0;x<LCD_W;x++) {
                uint16_t p=pixels[r*LCD_W+x];
                for(int n=0;n<4;n++)line[x*4+n]=hex[(p>>(12-4*n))&15];
            }
            line[LCD_W*4]=0;printf("PIX %d %s\n",y+r,line);
            fflush(stdout);
            // Diagnostic capture only: let USB drain before the next full row.
            vTaskDelay(pdMS_TO_TICKS(5));
        }
    }
    // ST7789's 240x135 visible window in landscape (MADCTL=0x60). Most callers
    // walk the whole panel top to bottom without skipping a row (their
    // `for(strip_y=0; strip_y<LCD_H; strip_y+=STRIP_H)` loops), and for those
    // the window is set once per frame and the rest is streamed: RAMWR stays
    // open -- the write pointer keeps auto-incrementing -- across CS toggles
    // until another command is sent, and nothing else here sends the panel a
    // command mid-frame. That cuts 17 strips' worth of CASET/RASET (32
    // transactions) down to one.
    //
    // The condition is where the pointer is, not `y==0`. It used to be the
    // latter, which was the same test while every caller sent every strip.
    // main/ui/codeedit.c now sends only the strips it changed, and under the
    // old test a frame that skipped strip 0 set no window at all: its rows
    // went wherever the pointer happened to be, and a frame that skipped a
    // middle strip pulled everything below it up by 8 rows. Neither is
    // visible from software -- board_capture samples `pixels` above, before
    // this point, and MISO is unwired -- so it would have shown only on the
    // glass. Tracking the pointer costs a re-window per discontinuity and
    // nothing at all for a caller that sends every strip.
    if(y!=next_row||window_x!=0||window_cols!=LCD_W) {
        uint16_t x0=40, x1=279, y0=53+(uint16_t)y, y1=53+LCD_H-1;
        uint8_t xs[]={x0>>8,x0,x1>>8,x1}, ys[]={y0>>8,y0,y1>>8,y1};
#if BOARD_ENDIAN_PROBE
        if(y==0)endian_probe();
#endif
        esp_err_t e=command(0x2a,xs,4); if(e) return e;
        e=command(0x2b,ys,4); if(e) return e;
        e=command(0x2c,NULL,0); if(e) return e;   // RAMWR: opens the write session
    }
    // The byte swap goes after the capture block above, which wants the pixels
    // as drawn.
    //
    // A 32-bit C version of this was measured and was worse: this file builds
    // at -Os, where the four-byte memcpy that expresses an aligned wide access
    // stayed a call and the transfer went from 16.5 ms to 24.2 ms.
    int count=LCD_W*rows;
    size_t bytes = (size_t)LCD_W * rows * 2;
    // Commands may have drained already. A continued window has not: the
    // same TX payload/descriptor cannot be touched while the driver owns it.
#if defined(BOARD_BUF_AB)&&BOARD_BUF_AB
    if (g_board_ring && g_board_async) {
        // The ring waits only for the rows it reuses; DC stays high for every
        // band the interrupt starts.
        gpio_set_level(34, 1);
        esp_err_t e;
        { DD_SCOPE(DD_TX_SUBMIT);
          DD_ADD(DD_TX_SUBMITS,1);
          e = lcd_spi_ring_submit(pixels, 0, LCD_W, rows);
          DD_ADD(DD_TX_FAILURES,e!=ESP_OK);
          DD_ADD(DD_TX_PAYLOAD_BYTES,e==ESP_OK?bytes:0); }
        if (e == ESP_OK) tx_inflight = true;
        next_row = (e==ESP_OK && y+rows<LCD_H) ? y+rows : -1;
        window_x=0;window_cols=LCD_W;
        return e;
    }
#endif
#if defined(BOARD_LCD_DEPTH2)&&BOARD_LCD_DEPTH2
    esp_err_t e=tx_reap_slot();
#else
    esp_err_t e=tx_reap();
#endif
    if(e!=ESP_OK){next_row=-1;return e;}
    if (g_board_async) {
#ifdef KASANE_P0_BUS_PROBE
        int64_t swap_began=esp_timer_get_time();
#endif
        // Drawing/overlays may overlap DMA; the single TX copy starts only
        // after ownership is returned by the reap above.
        DD_OPEN(copy,DD_TX_COPY);
#if defined(BOARD_STRIP_HALF)&&BOARD_STRIP_HALF
        // Sent from where it was drawn; put_strip in place is nothing for
        // LSB-first pixels and the swap otherwise.
        uint16_t *panel = pixels;
        put_strip(pixels,pixels,count);
#else
#if defined(BOARD_LCD_DEPTH2)&&BOARD_LCD_DEPTH2
        uint16_t *panel = tx_slot_buf[tx_next];
#else
        uint16_t *panel = tx_buf;
#endif
#if defined(BOARD_BUF_AB)&&BOARD_BUF_AB
        if (zero_copy_strip(pixels)) {
            panel = pixels;              // sent from where it was drawn
        } else
#endif
        if (g_board_swap_into) {
            DD_ADD(DD_TX_COPY_BYTES,bytes);
            put_strip(panel,pixels,count);
        } else {
            DD_ADD(DD_TX_COPY_BYTES,bytes);
            // The A/B arm: swap in place, then copy, the way 7fd965f shipped it.
            put_strip(pixels,pixels,count);
            memcpy(panel, pixels, bytes);
        }
#endif
#ifdef KASANE_P0_BUS_PROBE
        ksn_p0_bus_phase_sample(KSN_P0_BUS_SWAP,
            (uint32_t)(esp_timer_get_time()-swap_began),false);
#endif
        DD_CLOSE(copy);
        if (e == ESP_OK) {
            // DC high: these bytes are pixel data and not a command. tx() is the
            // only other place that touches the line and it cannot be used here,
            // because it would block on the transfer this path exists to overlap.
            gpio_set_level(34, 1);
#if defined(BOARD_LCD_DEPTH2)&&BOARD_LCD_DEPTH2
            spi_transaction_t *desc = tx_slot_desc[tx_next];
#else
            spi_transaction_t *desc = &tx_pending;
#endif
            *desc = (spi_transaction_t){.length = bytes * 8, .tx_buffer = panel};
#ifdef KASANE_P0_BUS_PROBE
            atomic_store_explicit(&lcd_data_isr_us,0u,memory_order_relaxed);
            desc->user=&lcd_data_isr_us;
            int64_t queue_began=esp_timer_get_time();
#endif
            /* Pin descriptor/payload before queue: IDF can return an error
             * after accepting it. Only exact reap returns this ownership. */
#if defined(BOARD_LCD_DEPTH2)&&BOARD_LCD_DEPTH2
            tx_queued++; tx_next ^= 1;
#endif
            tx_inflight = true;
#if defined(BOARD_BUF_AB)&&BOARD_BUF_AB
            tx_from = panel;
#endif
#if defined(BOARD_STRIP_HALF)&&BOARD_STRIP_HALF
            half_from = panel;
#endif
            { DD_SCOPE(DD_TX_SUBMIT);
              DD_ADD(DD_TX_SUBMITS,1);
#if defined(BOARD_LCD_DIRECT)&&BOARD_LCD_DIRECT
              if (g_board_direct) {
                  lcd_spi_direct_start(panel, bytes);
                  e = ESP_OK;
                  tx_direct = true;
              } else
#endif
              e = spi_device_queue_trans(lcd, desc, portMAX_DELAY);
              LCD_TX_COUNT(e);
              DD_ADD(DD_TX_FAILURES,e!=ESP_OK);
              DD_ADD(DD_TX_PAYLOAD_BYTES,e==ESP_OK?bytes:0); }
#ifdef KASANE_P0_BUS_PROBE
            ksn_p0_bus_phase_sample(KSN_P0_BUS_QUEUE,
                (uint32_t)(esp_timer_get_time()-queue_began),false);
#endif

        }
    } else {
        DD_OPEN(copy,DD_TX_COPY);
        put_strip(pixels,pixels,count);
        DD_CLOSE(copy);
        if (e == ESP_OK) {
            DD_SCOPE(DD_TX_SUBMIT);DD_ADD(DD_TX_SUBMITS,1);
            e = tx(true, pixels, bytes);
            DD_ADD(DD_TX_FAILURES,e!=ESP_OK);
            DD_ADD(DD_TX_PAYLOAD_BYTES,e==ESP_OK?bytes:0);
        }
    }
#if defined(BOARD_STRIP_HALF)&&BOARD_STRIP_HALF
    // A screen's own strip (not a lent half): finished before it is drawn
    // into again.
    if (pixels != half_lent && e == ESP_OK) e = tx_reap();
    half_lent = NULL;
#endif
    // Where the pointer lands once these rows are in. At the bottom of the
    // window it wraps to the window's own top, which is only row 0 when this
    // frame started there, so the end of the panel always re-windows. A failed
    // transfer leaves the pointer unknown, which is what -1 means.
    next_row = (e==ESP_OK && y+rows<LCD_H) ? y+rows : -1;
    window_x=0;window_cols=LCD_W;
    return e;
}

// Narrow bands with the same horizontal bounds can stream into the same
// window, just as full-width bands do. Its bottom is the panel bottom; the
// horizontal wrap therefore places the next contiguous band at its own row.
// Width/x changes, gaps, commands, frame end, capture and failures invalidate it.
//
// The overlays still paint their whole rectangles into the strip and only the
// window goes out. That is correct rather than lucky: everything they draw
// outside the window is identical to what is already on the glass, because the
// frame that put it there was full width (an overlay's own change comes through
// app_force_redraw(), which asks for whole bands).
esp_err_t board_present_rect(int x, int y, int cols, int rows, uint16_t *pixels) {
    if(board_fox_active())return ESP_ERR_INVALID_STATE;
    if (x<0 || cols<1 || x+cols>LCD_W ||
        y<0 || rows<1 || rows>STRIP_H || y+rows>LCD_H) {
        next_row=-1;return ESP_ERR_INVALID_ARG;
    }
    if (cols==LCD_W) return board_present(y,rows,pixels);
    if (board_host_overlays) {
        pet_hub_overlay(pixels,y,rows);
        pocket_capture_overlay(pixels,y,rows);
    }
    // No capture arm: board_capture dumps whole rows and the columns outside
    // the window hold the previous band, so a caller that is capturing must not
    // narrow. board_capture_active() is how it finds that out.
    uint16_t px0=40+(uint16_t)x, px1=40+(uint16_t)(x+cols)-1;
    uint16_t py0=53+(uint16_t)y, py1=53+LCD_H-1;
    uint8_t xs[]={px0>>8,px0,px1>>8,px1}, ys[]={py0>>8,py0,py1>>8,py1};
    esp_err_t e=ESP_OK;
    if(y!=next_row||x!=window_x||cols!=window_cols){
        e=command(0x2a,xs,4); if(e) return e;
        e=command(0x2b,ys,4); if(e) return e;
        e=command(0x2c,NULL,0); if(e) return e;
    }
    size_t bytes=(size_t)cols*rows*2;
    // Rows are packed as they are swapped, so the window leaves the strip in one
    // pass exactly as the full-width path does. Both arms pack into a panel
    // buffer rather than in place: the strip's rows are 240 apart and the
    // window's are `cols` apart. Reap before writing the one TX payload.
    //
    // The kernel arm is the reason ksn_render rounds its window out to 16
    // pixels: 16 pixels is 32 bytes, so an aligned x and a multiple-of-16 cols
    // make every packed row a whole number of the kernel's blocks at an aligned
    // address. Anything else falls to the scalar swap, which is the arm that
    // made the first narrow measurement slower than the full-width path.
#if defined(BOARD_BUF_AB)&&BOARD_BUF_AB
    if (g_board_ring && g_board_async) {
        gpio_set_level(34, 1);
        { DD_SCOPE(DD_TX_SUBMIT);
          DD_ADD(DD_TX_SUBMITS,1);
          e = lcd_spi_ring_submit(pixels, x, cols, rows);
          DD_ADD(DD_TX_FAILURES,e!=ESP_OK);
          DD_ADD(DD_TX_PAYLOAD_BYTES,e==ESP_OK?bytes:0); }
        if (e == ESP_OK) tx_inflight = true;
        next_row = (e==ESP_OK && y+rows<LCD_H) ? y+rows : -1;
        window_x=x;window_cols=cols;
        return e;
    }
#endif
#if defined(BOARD_LCD_DEPTH2)&&BOARD_LCD_DEPTH2
    e=tx_reap_slot();
#else
    e=tx_reap();
#endif
    if(e!=ESP_OK){next_row=-1;return e;}
#if defined(BOARD_STRIP_HALF)&&BOARD_STRIP_HALF
    const bool lent = pixels == half_lent;
    half_lent = NULL;
    if (!lent) {
        // A screen's own strip: its rows outside the window are still the
        // caller's, so nothing is packed in place. Row by row, finished here.
        for (int r = 0; r < rows && e == ESP_OK; r++) {
            DD_SCOPE(DD_TX_SUBMIT);DD_ADD(DD_TX_SUBMITS,1);
            e = tx(true, pixels + r * LCD_W + x, (size_t)cols * 2u);
            DD_ADD(DD_TX_FAILURES,e!=ESP_OK);
        }
        next_row = (e==ESP_OK && y+rows<LCD_H) ? y+rows : -1;
        window_x=x;window_cols=cols;
        return e;
    }
#endif
    DD_OPEN(copy,DD_TX_COPY);
    DD_ADD(DD_TX_COPY_BYTES,bytes);
#if defined(BOARD_STRIP_HALF)&&BOARD_STRIP_HALF
    // A lent half, packed in place: row r moves from r*240+x down to r*cols,
    // never past a row still to be read.
    uint16_t *panel = pixels;
    for (int r=0;r<rows;r++) memmove(panel+r*cols,pixels+r*LCD_W+x,(size_t)cols*2u);
    if (0)
#elif defined(BOARD_LCD_DEPTH2)&&BOARD_LCD_DEPTH2
    uint16_t *panel = tx_slot_buf[tx_next];
#else
    uint16_t *panel = tx_buf;
#endif
#if defined(BOARD_BUF_AB)&&BOARD_BUF_AB
    if (zero_copy_strip(pixels)) {
        // Packed in place: row r moves from r*240+x down to r*cols, never past
        // a row still to be read, and the strip is not used again this band.
        panel = pixels;
        for (int r=0;r<rows;r++) memmove(panel+r*cols,pixels+r*LCD_W+x,(size_t)cols*2u);
    } else
#endif
    for (int r=0;r<rows;r++) put_strip(panel+r*cols,pixels+r*LCD_W+x,cols);
    DD_CLOSE(copy);
    if (g_board_async) {
        if (e == ESP_OK) {
            gpio_set_level(34, 1);
#if defined(BOARD_LCD_DEPTH2)&&BOARD_LCD_DEPTH2
            spi_transaction_t *desc = tx_slot_desc[tx_next];
#else
            spi_transaction_t *desc = &tx_pending;
#endif
            *desc = (spi_transaction_t){.length = bytes * 8, .tx_buffer = panel};
#ifdef KASANE_P0_BUS_PROBE
            atomic_store_explicit(&lcd_data_isr_us,0u,memory_order_relaxed);
            desc->user=&lcd_data_isr_us;
#endif
            /* Pin descriptor/payload before queue: IDF can return an error
             * after accepting it. Only exact reap returns this ownership. */
#if defined(BOARD_LCD_DEPTH2)&&BOARD_LCD_DEPTH2
            tx_queued++; tx_next ^= 1;
#endif
            tx_inflight = true;
#if defined(BOARD_BUF_AB)&&BOARD_BUF_AB
            tx_from = panel;
#endif
#if defined(BOARD_STRIP_HALF)&&BOARD_STRIP_HALF
            half_from = panel;
#endif
            { DD_SCOPE(DD_TX_SUBMIT);
              DD_ADD(DD_TX_SUBMITS,1);
#if defined(BOARD_LCD_DIRECT)&&BOARD_LCD_DIRECT
              if (g_board_direct) {
                  lcd_spi_direct_start(panel, bytes);
                  e = ESP_OK;
                  tx_direct = true;
              } else
#endif
              e = spi_device_queue_trans(lcd, desc, portMAX_DELAY);
              LCD_TX_COUNT(e);
              DD_ADD(DD_TX_FAILURES,e!=ESP_OK);
              DD_ADD(DD_TX_PAYLOAD_BYTES,e==ESP_OK?bytes:0); }

        }
    } else {
        if (e == ESP_OK) {
            DD_SCOPE(DD_TX_SUBMIT);DD_ADD(DD_TX_SUBMITS,1);
            e = tx(true, panel, bytes);
            DD_ADD(DD_TX_FAILURES,e!=ESP_OK);
            DD_ADD(DD_TX_PAYLOAD_BYTES,e==ESP_OK?bytes:0);
        }
    }
    next_row = (e==ESP_OK && y+rows<LCD_H) ? y+rows : -1;
    window_x=x;window_cols=cols;
    return e;
}

esp_err_t board_present_rect_sync(int x, int y, int cols, int rows, uint16_t *pixels) {
    esp_err_t e=tx_reap();
    if(e==ESP_OK) e=board_present_rect(x,y,cols,rows,pixels);
    if(e==ESP_OK) e=tx_reap();
    if(e!=ESP_OK) next_row=-1;
    return e;
}

esp_err_t board_present_sync(int y, int rows, uint16_t *pixels) {
    esp_err_t e=tx_reap();
    if(e==ESP_OK) e=board_present(y,rows,pixels);
    if(e==ESP_OK) e=tx_reap();
    if(e!=ESP_OK) next_row=-1;
    return e;
}

#ifdef KASANE_DMA_OVERLAP
esp_err_t board_present_finish(void) {
    esp_err_t e;
    /* portMAX_DELAY normally cannot time out. If it does, the driver still
     * owns the descriptor, so keep draining rather than releasing a borrow. */
    do { e=tx_reap(); } while(e==ESP_ERR_TIMEOUT);
    if(e!=ESP_OK)next_row=-1;
    return e;
}
esp_err_t board_present_submit(int x,int y,int cols,int rows,uint16_t *pixels) {
#if defined(BOARD_LCD_DEPTH2)&&BOARD_LCD_DEPTH2
    // Depth 2 waits for a free slot inside board_present_rect instead.
    esp_err_t e=g_board_depth<2?board_present_finish():ESP_OK;
#elif defined(BOARD_BUF_AB)&&BOARD_BUF_AB
    // The ring waits for the rows it reuses inside board_present_rect.
    esp_err_t e=g_board_ring?ESP_OK:board_present_finish();
#else
    esp_err_t e=board_present_finish();
#endif
    if(e==ESP_OK)e=board_present_rect(x,y,cols,rows,pixels);
    if(e!=ESP_OK)next_row=-1;
    return e;
}
#endif

/* Private character output hands this same LCD device between mutually
 * exclusive UI-owner paths; it never registers an ISR lease callback. */
esp_err_t board_fox_port_acquire(spi_device_handle_t *device,bool *le){
    if(board_fox_active()||!device||!le||!lcd)return ESP_ERR_INVALID_STATE;
#if BOARD_LCD_DIRECT || BOARD_BUF_AB || BOARD_LCD_DEPTH2
    /* Experimental raw/ring/depth modes have a different ownership contract. */
    return ESP_ERR_NOT_SUPPORTED;
#else
    esp_err_t e=tx_reap_wait(0);
    next_row=-1;
    if(e!=ESP_OK)return e;
    *device=lcd;*le=lcd_le;return ESP_OK;
#endif
}
void board_fox_port_release(void){next_row=-1;}
void board_fox_port_dc(bool data){gpio_set_level(34,data);}
#ifdef FOX_PRODUCT_QEMU_TEST
esp_err_t board_fox_qemu_init(spi_device_handle_t mock_device){
    if(!mock_device||board_fox_active()||tx_inflight)return ESP_ERR_INVALID_STATE;
    lcd=mock_device;lcd_le=true;next_row=-1;
    return ESP_OK;
}
#endif
