#ifndef BOARD_FOX_H
#define BOARD_FOX_H
#include "lease.h"
#include "esp_err.h"
#include "freertos/FreeRTOS.h"
#include "driver/spi_master.h"
/* Private character output, sole UI task only. No ISR pool calls. The device's
 * return-result queue is an exactly-once source; no other consumer is allowed.
 * begin is also the new-attempt reset, permitted only when idle and not closed.
 * submit consumes a valid, already pinned ticket on EVERY return. Before queue
 * it completes rejected tickets locally; after dispatch every status retains
 * the borrow until the exact descriptor returns. Native RGB565, full-width
 * packed 1..4 rows, DMA-capable 4-byte aligned; no mutation/copy/overlay.
 * Timeout is never permission to free. close prevents new submit, drain still
 * works. end requires close+idle and owner-task quiescence, not merely success.
 * No callback retains pool addresses: SPI post_cb may only record diagnostics.
 */
esp_err_t board_fox_begin(void);
/* Resume persistent address-window setup. ESP_ERR_TIMEOUT means pending,
 * NOT a failed frame. Keep the staged strip and revisit next UI turn. Only
 * call submit after ESP_OK for this y; prepare never takes a pixel ticket. */
esp_err_t board_fox_prepare(int y);
esp_err_t board_fox_submit(lease_pool *,lease_ticket,const uint16_t *pixels,
                           int x,int y,int width,int height);
esp_err_t board_fox_pump(TickType_t wait);
esp_err_t board_fox_drain(TickType_t wait);
esp_err_t board_fox_close(void);
esp_err_t board_fox_end(void);
bool board_fox_idle(void);
bool board_fox_active(void);
esp_err_t board_fox_error(void);
/* Board-owned hooks. The presenter must not call these. */
esp_err_t board_fox_port_acquire(spi_device_handle_t *,bool *little_endian);
void board_fox_port_release(void);
void board_fox_port_dc(bool data);
#ifdef FOX_PRODUCT_QEMU_TEST
/* Only initializes the skipped physical board's test device/endian state.
 * Actual private begin/commands/submit/reap are NOT wrapped in QEMU. */
esp_err_t board_fox_qemu_init(spi_device_handle_t mock_device);
#endif
#endif
