#ifndef PRIVATE_RENDER_ADAPTER_H
#define PRIVATE_RENDER_ADAPTER_H
#include "lease.h"
#include "eye_runtime.h"
#include "composite.h"
typedef struct { unsigned y, height; uint16_t pixels[960]; } leased_strip;
typedef struct { scene_frame frame; scene_workspace workspace; fox_composite_workspace composite; } render_scratch;
/* Caller owns exclusive scratch for entire call. Snapshot is already published.
 * submit receives immutable strip and ticket, may complete inline or later.
 * It MUST eventually complete even after failure/cancel, only after all readers
 * stop. false means render failure, NOT permission to reclaim the borrow.
 * pump may retire transport work to provide bounded backpressure. false stops
 * rendering; outstanding strips remain pinned. No callbacks run under locks. */
bool render_leased(lease_pool *snapshots,lease_key snapshot,lease_pool *strips,
 render_scratch*,bool(*submit)(void*,const leased_strip*,lease_ticket),
 bool(*pump)(void*),void*);

/* Resumable single-owner form. At most one staged strip plus the transport's
 * one strip; scratch and snapshot pin survive yields. ready must not transfer
 * ownership. submit consumes the ticket on every return, including rejection. */
typedef struct {
 lease_pool *snapshots,*strips; render_scratch *scratch;
 lease_ticket snapshot_ticket,staged_ticket;
 const fox_eye_snapshot *snapshot; const leased_strip *staged;
 unsigned y; bool active,submitted_all;
} render_cursor;
bool render_cursor_begin(render_cursor*,lease_pool*,lease_key,lease_pool*,render_scratch*);
/* -1: failed, 0: bounded yield, 1: all strips submitted (not yet drained). */
int render_cursor_step(render_cursor*,bool(*ready)(void*,const leased_strip*),bool(*submit)(void*,const leased_strip*,lease_ticket),void*);
void render_cursor_abort(render_cursor*);

#endif
