#include "bridge.h"
#include "probe.h"
#include "render_adapter.h"
#include "lease_freertos.h"
#include "board_fox.h"
#include "esp_heap_caps.h"
#include "freertos/task.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

/* A UI-owner presenter, with one accepted (pending) and one presented snapshot.
 * No framebuffer, callback task, or second scratch user exists. */
static lease_mutex sm,bm;
static fox_eye_snapshot *snapshots[2];
static leased_strip *strips[2];
static render_scratch *scratch;
static lease_pool sp,bp;
static lease_slot ss[2],bs[2];
static lease_reader sr[4],br[4];
static lease_key latest,pending;
static bool initialized,has_latest,has_pending,closed,owns_panel,rendering,dirty;
static TaskHandle_t owner;
static render_cursor cursor;
static bool logged_two;
static unsigned allocation_attempts,accepted_sequence,presented_sequence;
static uint32_t presented_hash,frame_hash;
static unsigned submits,attempts,failures;
static void owner_check(void){if(owner)assert(owner==xTaskGetCurrentTaskHandle());}
unsigned fox_composed_allocation_attempts(void){return allocation_attempts;}
static void lock(void*p){lease_mutex_lock(p);}static void unlock(void*p){lease_mutex_unlock(p);}
static void *alloc(const char*name,size_t n,uint32_t caps){
 allocation_attempts++;
 printf("QRAM_ALLOC name=%s request=%u caps=%u before_free=%u before_largest=%u\n",name,(unsigned)n,(unsigned)caps,(unsigned)heap_caps_get_free_size(caps),(unsigned)heap_caps_get_largest_free_block(caps));
 void*p=heap_caps_calloc(1,n,caps);
 printf("QRAM_ALLOC_RESULT name=%s success=%u\n",name,p!=NULL);return p;
}
static void release(void){free(scratch);scratch=NULL;for(unsigned i=0;i<2;i++){free(snapshots[i]);snapshots[i]=NULL;free(strips[i]);strips[i]=NULL;}}
static bool init(void){
 owner_check();if(initialized)return !closed;
 if(closed)return false;
 qram_mark("renderer_before_alloc");
 scratch=alloc("render_scratch",sizeof *scratch,MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT);if(!scratch)goto fail;
 for(unsigned i=0;i<2;i++){
  snapshots[i]=alloc("snapshot",sizeof *snapshots[i],MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT);if(!snapshots[i])goto fail;
  strips[i]=alloc("strip",sizeof *strips[i],MALLOC_CAP_INTERNAL|MALLOC_CAP_DMA|MALLOC_CAP_8BIT);if(!strips[i])goto fail;
 }
 lease_mutex_init(&sm);lease_mutex_init(&bm);
 for(unsigned i=0;i<2;i++){ss[i].payload=snapshots[i];bs[i].payload=strips[i];}
 lease_init(&sp,ss,2,sr,4,&sm,lock,unlock);lease_init(&bp,bs,2,br,4,&bm,lock,unlock);
 initialized=true;owner=xTaskGetCurrentTaskHandle();
 printf("QRAM_LAYOUT scratch=%u snapshot=%u strip=%u pool=%u mutex=%u\n",(unsigned)sizeof *scratch,(unsigned)sizeof *snapshots[0],(unsigned)sizeof *strips[0],(unsigned)(sizeof sp+sizeof bp+sizeof ss+sizeof bs+sizeof sr+sizeof br),(unsigned)(sizeof sm+sizeof bm));
 qram_mark("renderer_allocated");return true;
 fail:qram_mark("renderer_allocation_failed");release();qram_mark("renderer_failed_allocation_rollback");return false;
}
bool fox_composed_open(void){
 owner_check();if(initialized||owns_panel)return false;
 closed=has_latest=has_pending=rendering=dirty=false;owner=xTaskGetCurrentTaskHandle();
 accepted_sequence=presented_sequence=presented_hash=attempts=failures=0;return true;
}
bool fox_composed_commit(const FoxEyeControls*c,uint32_t*out){
 owner_check();if(closed||has_pending||rendering||accepted_sequence==UINT32_MAX||!init())return false;
 lease_key key;void*dst;if(!lease_acquire(&sp,&key,&dst))return false;
 if(!fox_eye_snapshot_build(dst,c)){assert(lease_abort(&sp,key));return false;}
 /* Claim before publication. A refused claim has no JS-visible state change. */
 if(!owns_panel&&board_fox_begin()!=ESP_OK){assert(lease_abort(&sp,key));return false;}
 owns_panel=true;assert(lease_publish(&sp,key));pending=key;has_pending=true;
 *out=++accepted_sequence;
 printf("QOWNER_ACCEPT sequence=%u presented=%u\n",accepted_sequence,presented_sequence);
 qram_mark(has_latest?"two_published_snapshots":"snapshot_accepted");return true;
}
static bool ready(void*unused,const leased_strip*staged){
 (void)unused;
 if(staged)return board_fox_prepare((int)staged->y)==ESP_OK;
 if(!board_fox_idle())(void)board_fox_pump(0);
 return board_fox_idle()&&board_fox_error()==ESP_OK;
}
static bool submit(void*unused,const leased_strip*p,lease_ticket ticket){
 (void)unused;submits++;
 for(unsigned i=0;i<p->height*240;i++)frame_hash=(frame_hash^p->pixels[i])*16777619u;
 dirty=true;
 return board_fox_submit(&bp,ticket,p->pixels,0,p->y,240,p->height)==ESP_OK;
}
bool fox_composed_present(void){
 owner_check();if(!has_pending||closed)return !has_pending;
 assert(!rendering);rendering=true;
 if(!cursor.active){
  if(!board_fox_idle())(void)board_fox_pump(0);
  if(!board_fox_idle()){rendering=false;return false;}
  if(board_fox_begin()!=ESP_OK){rendering=false;return false;}
  attempts++;submits=0;frame_hash=2166136261u;logged_two=false;
  if(!render_cursor_begin(&cursor,&sp,pending,&bp,scratch))goto fail;
 }
 int step=render_cursor_step(&cursor,ready,submit,NULL);
 if(bs[0].readers+bs[1].readers==2&&!logged_two){logged_two=true;qram_mark("two_strips_borrowed");}
 if(step<0||board_fox_error()!=ESP_OK)goto fail;
 if(step==0){rendering=false;return false;}
 /* Every row has been submitted. Keep its hash and wait without rerendering. */
 if(!ready(NULL,NULL)){
  if(board_fox_error()!=ESP_OK)goto fail;
  rendering=false;return false;
 }
 render_cursor_abort(&cursor);
 if(has_latest)assert(lease_retire(&sp,latest));
 latest=pending;has_latest=true;has_pending=false;
 presented_sequence=accepted_sequence;presented_hash=frame_hash;dirty=false;
 printf("QOWNER_PRESENT sequence=%u hash=%08x strips=%u attempts=%u failures=%u\n",presented_sequence,(unsigned)frame_hash,submits,attempts,failures);
 qram_mark("render_complete");rendering=false;return true;
 fail:
 render_cursor_abort(&cursor);failures++;
 printf("QOWNER_RETAIN sequence=%u presented=%u strips=%u idle=%u panel_may_be_partial=%u\n",accepted_sequence,presented_sequence,submits,board_fox_idle(),dirty);
 qram_mark("pending_render_retained");rendering=false;return false;
}
bool fox_composed_owned(void){return owns_panel;}
bool fox_composed_pending(void){return has_pending;}
bool fox_composed_shutdown_pending(void){return closed&&(initialized||owns_panel);}
uint32_t fox_composed_hash(void){return presented_hash;}
unsigned fox_composed_accepted(void){return accepted_sequence;}
unsigned fox_composed_presented(void){return presented_sequence;}
unsigned fox_composed_hidden(void){if(!has_latest)return 0;unsigned n=0;for(unsigned i=0;i<74;i++)n+=snapshots[latest.slot]->hidden[i]!=0;return n;}
void fox_composed_close(void){owner_check();closed=true;assert(!rendering);render_cursor_abort(&cursor);if(initialized){lease_close(&sp);lease_close(&bp);}if(owns_panel)board_fox_close();}
bool fox_composed_finish(void){
 owner_check();fox_composed_close();assert(!rendering);
 if(owns_panel){(void)board_fox_pump(0);if(!board_fox_idle())return false;if(board_fox_end()!=ESP_OK)return false;owns_panel=false;}
 if(initialized){assert(lease_drained(&sp)&&lease_drained(&bp));vSemaphoreDelete(sm.handle);vSemaphoreDelete(bm.handle);release();initialized=false;qram_mark("renderer_destroyed");}
 has_latest=has_pending=false;owner=NULL;return true;
}
unsigned fox_composed_mode(int mode){owner_check();if(mode==90)return init();return 0;}
