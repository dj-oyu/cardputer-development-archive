#pragma once
#include <stdbool.h>
#include <stdint.h>
enum { QSPI_NORMAL, QSPI_DELAY, QSPI_HOLD, QSPI_ERROR_AFTER_ACCEPT, QSPI_DMA_RETURN_ERROR, QSPI_UNKNOWN_RETURN, QSPI_NEVER_ACCEPTED, QSPI_COMMAND_DELAY };
void qspi_mode(unsigned mode);
unsigned qspi_pending(void);
void qspi_init(void);
