#include "render_adapter.h"
#include <string.h>
static bool surface(void*u,const fox_fragment*f,float rgb[3],float*a){const fox_eye_snapshot*s=u;if(s->hidden[f->object]){*a=0;rgb[0]=rgb[1]=rgb[2]=0;return true;}return fox_eye_snapshot_surface(s,f->material,f->local[0],f->local[1],f->local[2],rgb,a);}
bool render_leased(lease_pool*snapshots,lease_key key,lease_pool*strips,render_scratch*w,bool(*submit)(void*,const leased_strip*,lease_ticket),bool(*pump)(void*),void*ctx){
 lease_ticket read;const void*borrow;if(!lease_pin(snapshots,key,&read,&borrow))return false;
 const fox_eye_snapshot*s=borrow;scene_times times;bool ok=false;
 if(!fox_scene_prepare_controls(NULL,&w->frame,&w->workspace,3,-1,&times,s->local,s->controls.head_turn,s->controls.head_tilt)||!fox_scene_composite_preflight(&w->frame,&w->workspace,s->local,surface,(void*)s,16,&w->composite))goto done;
 for(unsigned y=0;y<135;y+=4){lease_key k;void*p;
  if(!lease_acquire(strips,&k,&p)){if(!pump||!pump(ctx)||!lease_acquire(strips,&k,&p))goto done;}
  leased_strip*b=p;b->y=y;b->height=135-y<4?135-y:4;memset(b->pixels,0,sizeof b->pixels);
  if(!fox_scene_composite(&w->frame,b->pixels,y,b->height,30,&w->workspace,s->local,surface,(void*)s,16,&w->composite)){lease_abort(strips,k);goto done;}
  if(!lease_publish(strips,k)){lease_abort(strips,k);goto done;}
  lease_ticket t;const void*immutable;if(!lease_pin(strips,k,&t,&immutable)){lease_retire(strips,k);goto done;}
  lease_retire(strips,k); /* stop new pins; transport already owns its ticket */
  if(!submit(ctx,immutable,t))goto done;
 }
 ok=true;
 done: lease_complete(snapshots,read);return ok;
}

void render_cursor_abort(render_cursor*c){
 if(!c->active)return;
 if(c->staged){lease_complete(c->strips,c->staged_ticket);c->staged=NULL;}
 lease_complete(c->snapshots,c->snapshot_ticket);c->active=false;
}
bool render_cursor_begin(render_cursor*c,lease_pool*snapshots,lease_key key,lease_pool*strips,render_scratch*w){
 if(c->active)return false;
 memset(c,0,sizeof *c);const void*borrow;
 if(!lease_pin(snapshots,key,&c->snapshot_ticket,&borrow))return false;
 c->snapshots=snapshots;c->strips=strips;c->scratch=w;c->snapshot=borrow;c->active=true;
 scene_times times;
 if(!fox_scene_prepare_controls(NULL,&w->frame,&w->workspace,3,-1,&times,c->snapshot->local,c->snapshot->controls.head_turn,c->snapshot->controls.head_tilt)||
    !fox_scene_composite_preflight(&w->frame,&w->workspace,c->snapshot->local,surface,(void*)c->snapshot,16,&w->composite)){
  render_cursor_abort(c);return false;
 }
 return true;
}
int render_cursor_step(render_cursor*c,bool(*ready)(void*,const leased_strip*),bool(*submit)(void*,const leased_strip*,lease_ticket),void*ctx){
 if(!c->active)return -1;
 if(c->submitted_all)return 1;
 while(c->y<135){
  if(!c->staged){
   lease_key key;void*p;
   if(!lease_acquire(c->strips,&key,&p))return 0;
   leased_strip*b=p;b->y=c->y;b->height=135-c->y<4?135-c->y:4;memset(b->pixels,0,sizeof b->pixels);
   render_scratch*w=c->scratch;const fox_eye_snapshot*s=c->snapshot;
   if(!fox_scene_composite(&w->frame,b->pixels,b->y,b->height,30,&w->workspace,s->local,surface,(void*)s,16,&w->composite)){lease_abort(c->strips,key);return -1;}
   if(!lease_publish(c->strips,key)){lease_abort(c->strips,key);return -1;}
   const void*immutable;
   if(!lease_pin(c->strips,key,&c->staged_ticket,&immutable)){lease_retire(c->strips,key);return -1;}
   lease_retire(c->strips,key);c->staged=immutable;
  }
  if(!ready(ctx,c->staged))return 0;
  const leased_strip*p=c->staged;c->staged=NULL; /* submit ALWAYS consumes pin */
  unsigned rows=p->height;
  if(!submit(ctx,p,c->staged_ticket))return -1;
  c->y+=rows;
 }
 c->submitted_all=true;return 1;
}
