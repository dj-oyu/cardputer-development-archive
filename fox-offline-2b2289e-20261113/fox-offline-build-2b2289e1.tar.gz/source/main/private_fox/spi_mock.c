/* SDK-only QEMU adapter. The production-facing board_fox implementation and
 * persistent command/pixel descriptors are executed without wrappers. */
#include "spi_mock.h"
#include "board_fox.h"
#include "driver/gpio.h"
#include "freertos/task.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
extern volatile bool qram_real_hardware;
static spi_transaction_t *queued;
static spi_transaction_t unknown;
static unsigned mode,pixel_ordinal,polls;
static uint32_t saved_hash,wire_hash,native_hash,stream_bytes;
static bool pixel,fired;
static const spi_device_handle_t device=(spi_device_handle_t)(uintptr_t)0x100;
static const unsigned char *bytes(const spi_transaction_t*t){return t->flags&SPI_TRANS_USE_TXDATA?t->tx_data:t->tx_buffer;}
static uint32_t digest(const spi_transaction_t*t){uint32_t h=2166136261u;for(size_t i=0;i<t->length/8;i++)h=(h^bytes(t)[i])*16777619u;return h;}
void qspi_init(void){assert(board_fox_qemu_init(device)==ESP_OK);}
void qspi_mode(unsigned m){mode=m;pixel_ordinal=0;fired=false;printf("QSPI_MODE value=%u pending=%u\n",m,queued!=NULL);}
unsigned qspi_pending(void){return queued!=NULL;}
extern esp_err_t __real_spi_device_queue_trans(spi_device_handle_t,spi_transaction_t*,TickType_t);
esp_err_t __wrap_spi_device_queue_trans(spi_device_handle_t d,spi_transaction_t*t,TickType_t wait){
 if(qram_real_hardware)return __real_spi_device_queue_trans(d,t,wait);
 assert(d==device&&!queued);pixel=!(t->flags&SPI_TRANS_USE_TXDATA);
 if(pixel){assert(t->tx_buffer&&t->length%32==0&&((uintptr_t)t->tx_buffer&3)==0);pixel_ordinal++;}
 if(pixel&&mode==QSPI_NEVER_ACCEPTED&&!fired){fired=true;puts("QSPI_UNKNOWN_NO_ACCEPT descriptor_retained_by_adapter=1");return ESP_FAIL;}
 queued=t;saved_hash=digest(t);polls=0;
 if(pixel&&mode==QSPI_ERROR_AFTER_ACCEPT&&pixel_ordinal==3&&!fired){fired=true;puts("QSPI_ERROR_AFTER_ACCEPT queued=1");return ESP_FAIL;}
 return ESP_OK;
}
extern esp_err_t __real_spi_device_get_trans_result(spi_device_handle_t,spi_transaction_t**,TickType_t);
esp_err_t __wrap_spi_device_get_trans_result(spi_device_handle_t d,spi_transaction_t**out,TickType_t wait){
 if(qram_real_hardware)return __real_spi_device_get_trans_result(d,out,wait);
 assert(d==device);*out=NULL;if(!queued)return ESP_ERR_TIMEOUT;
 assert(saved_hash==digest(queued));
 if(pixel&&mode==QSPI_HOLD)return ESP_ERR_TIMEOUT;
 if(pixel&&mode==QSPI_DELAY&&polls++<2)return ESP_ERR_TIMEOUT;
 if(!pixel&&mode==QSPI_COMMAND_DELAY&&polls++==0){puts("QSPI_COMMAND_FIRST_POLL_NOT_READY");return ESP_ERR_TIMEOUT;}
 if(pixel&&mode==QSPI_UNKNOWN_RETURN&&!fired){fired=true;*out=&unknown;puts("QSPI_UNKNOWN_DESCRIPTOR original_retained=1");return ESP_OK;}
 spi_transaction_t*t=queued;queued=NULL;*out=t;
 if(!pixel&&t->length==8&&bytes(t)[0]==0x2c){stream_bytes=0;wire_hash=native_hash=2166136261u;}
 if(pixel){
  const unsigned char*p=bytes(t);for(size_t i=0;i<t->length/8;i++)wire_hash=(wire_hash^p[i])*16777619u;
  for(size_t i=0;i<t->length/8;i+=2)native_hash=(native_hash^(uint16_t)(p[i]|((unsigned)p[i+1]<<8)))*16777619u;
  stream_bytes+=t->length/8;
  if(stream_bytes==240*135*2)printf("QSPI_FRAME bytes=%u native_hash=%08x wire_fnv=%08x\n",(unsigned)stream_bytes,(unsigned)native_hash,(unsigned)wire_hash);
  if(mode==QSPI_DMA_RETURN_ERROR&&pixel_ordinal==3&&!fired){fired=true;puts("QSPI_EXACT_RETURN_DMA_ERROR retired=1");return ESP_ERR_INVALID_STATE;}
 }
 return ESP_OK;
}
extern esp_err_t __real_gpio_set_level(gpio_num_t,uint32_t);
esp_err_t __wrap_gpio_set_level(gpio_num_t pin,uint32_t value){if(qram_real_hardware)return __real_gpio_set_level(pin,value);assert(pin==34);return ESP_OK;}
