#include "lease_spi.h"
#include "esp_memory_utils.h"
#include <stdint.h>
#include <string.h>
unsigned lease_spi_pending(const lease_spi *a){unsigned n=0;if(a)for(unsigned i=0;i<2;i++)n+=a->entries[i].active;return n;}
bool lease_spi_idle(const lease_spi *a){return a&&lease_spi_pending(a)==0;}
bool lease_spi_owns_ticket(const lease_spi *a,lease_pool *p,lease_ticket t){
 if(!a)return false;
 for(unsigned i=0;i<2;i++){const lease_spi_entry *e=&a->entries[i];
  if(e->active&&e->pool==p&&e->ticket.pool==t.pool&&e->ticket.serial==t.serial&&e->ticket.key.slot==t.key.slot&&e->ticket.key.generation==t.key.generation)return true;
 }return false;
}
esp_err_t lease_spi_open(lease_spi *a,spi_device_handle_t dev){
 if(!a||!dev)return ESP_ERR_INVALID_ARG;
 if(!lease_spi_idle(a))return ESP_ERR_INVALID_STATE;
 a->device=dev;a->closed=false;return ESP_OK;
}
void lease_spi_close(lease_spi *a){if(a)a->closed=true;}
static lease_spi_entry *available(lease_spi *a){
 if(!a||!a->device||a->closed)return NULL;
 for(unsigned i=0;i<2;i++)if(!a->entries[i].active)return &a->entries[i];
 return NULL;
}
bool lease_spi_ticket_payload(lease_pool *p,lease_ticket t,const void **out){
 if(!p||!out||t.pool!=p||!t.serial||!t.key.generation)return false;
 bool ok=false;p->lock(p->lock_ctx);
 if(t.key.slot<p->count&&p->slots[t.key.slot].generation==t.key.generation)
  for(size_t i=0;i<p->capacity;i++){lease_reader *r=p->readers+i;
   if(r->active&&r->ticket.pool==p&&r->ticket.serial==t.serial&&r->ticket.key.slot==t.key.slot&&r->ticket.key.generation==t.key.generation){*out=p->slots[t.key.slot].payload;ok=true;break;}}
 p->unlock(p->lock_ctx);return ok;
}
static esp_err_t reject(lease_pool *p,lease_ticket t,esp_err_t e){
 /* Invalid tickets cannot complete a different/newer reader. */
 if(p&&!lease_complete(p,t))return ESP_ERR_INVALID_STATE;
 return e;
}
esp_err_t lease_spi_submit_ticket(lease_spi *a,lease_pool *p,lease_ticket t,
                                  size_t size,size_t offset,size_t bytes,TickType_t wait){
 if(lease_spi_owns_ticket(a,p,t))return ESP_ERR_INVALID_STATE;
 const void *base=NULL;if(!lease_spi_ticket_payload(p,t,&base))return ESP_ERR_INVALID_STATE;
 if(offset>size||!bytes||bytes>size-offset||bytes>SIZE_MAX/8)return reject(p,t,ESP_ERR_INVALID_ARG);
 const unsigned char *data=(const unsigned char*)base+offset;
 /* This private S3 port deliberately forbids SDK bounce allocation. INTERNAL
  * DMA requires word alignment; native strips are 1920 or 1440 bytes. */
 if(((uintptr_t)data&3u)||!esp_ptr_dma_capable(data))return reject(p,t,ESP_ERR_INVALID_ARG);
 lease_spi_entry *e=available(a);if(!e)return reject(p,t,ESP_ERR_INVALID_STATE);
 memset(&e->descriptor,0,sizeof e->descriptor);e->descriptor.length=bytes*8;
 e->descriptor.tx_buffer=data;e->descriptor.flags=SPI_TRANS_DMA_BUFFER_ALIGN_MANUAL;
 e->pool=p;e->ticket=t;e->active=true; /* Publish ownership before dispatch. */
 /* v6.0.1 can fail after enqueue. Every nonzero result is ambiguous: retain.
  * Even a probable prequeue failure cannot be recovered by guessing. */
 return spi_device_queue_trans(a->device,&e->descriptor,wait);
}
esp_err_t lease_spi_submit(lease_spi *a,lease_pool *p,lease_key key,size_t size,size_t offset,size_t bytes,TickType_t wait){
 const void *payload;lease_ticket t;
 if(!p||!lease_pin(p,key,&t,&payload))return ESP_ERR_INVALID_STATE;
 return lease_spi_submit_ticket(a,p,t,size,offset,bytes,wait);
}
esp_err_t lease_spi_command(lease_spi *a,const void *bytes,size_t size,TickType_t wait){
 if(!bytes||!size||size>4)return ESP_ERR_INVALID_ARG;
 lease_spi_entry *e=available(a);if(!e)return ESP_ERR_INVALID_STATE;
 memset(&e->descriptor,0,sizeof e->descriptor);e->descriptor.length=size*8;
 e->descriptor.flags=SPI_TRANS_USE_TXDATA|SPI_TRANS_DMA_BUFFER_ALIGN_MANUAL;
 memcpy(e->descriptor.tx_data,bytes,size);e->pool=NULL;e->active=true;
 return spi_device_queue_trans(a->device,&e->descriptor,wait);
}
esp_err_t lease_spi_reap(lease_spi *a,TickType_t wait){
 if(!a||!a->device)return ESP_ERR_INVALID_ARG;
 if(lease_spi_idle(a))return ESP_OK;
 spi_transaction_t *done=NULL;esp_err_t result=spi_device_get_trans_result(a->device,&done,wait);
 if(done){for(unsigned i=0;i<2;i++){lease_spi_entry *e=a->entries+i;if(e->active&&done==&e->descriptor){
   /* IDF sets done after ret_queue receive and uninstall_priv_desc, even when
    * DMA failure flags yield a nonzero status. Retire only this descriptor. */
   if(e->pool&&!lease_complete(e->pool,e->ticket))return ESP_ERR_INVALID_STATE;
   e->active=false;e->pool=NULL;return result;
  }}return ESP_ERR_INVALID_STATE;}
 return result==ESP_OK?ESP_ERR_INVALID_STATE:result;
}
