#ifndef LEASE_SPI_H
#define LEASE_SPI_H
#include "lease.h"
#include "freertos/FreeRTOS.h"
#include "driver/spi_master.h"
/* Product extension of the previously tested isolated lease_spi primitive.
 * One owner task/exclusive result consumer. Zero-initialize once before use;
 * never copy/move/reinit active storage. Raw SDK returns must be exactly once.
 * Ticket generations reject stale tickets, NOT a stale raw descriptor pointer
 * after that descriptor has been reused. No ISR or task-mutex callbacks. */
typedef struct {spi_transaction_t descriptor;lease_pool *pool;lease_ticket ticket;bool active;} lease_spi_entry;
typedef struct {spi_device_handle_t device;lease_spi_entry entries[2];bool closed;} lease_spi;
bool lease_spi_idle(const lease_spi *);
bool lease_spi_owns_ticket(const lease_spi *,lease_pool *,lease_ticket);
unsigned lease_spi_pending(const lease_spi *);
esp_err_t lease_spi_open(lease_spi *,spi_device_handle_t);
void lease_spi_close(lease_spi *);
/* Read-only validation under the pool lock; no extra pin. */
bool lease_spi_ticket_payload(lease_pool *,lease_ticket,const void **);
/* Takes ownership of an already-pinned ticket, including local rejects. size
 * is the caller's actual slot payload size; offset/bytes are bounded to it. */
esp_err_t lease_spi_submit_ticket(lease_spi *,lease_pool *,lease_ticket,size_t size,
                                  size_t offset,size_t bytes,TickType_t wait);
esp_err_t lease_spi_submit(lease_spi *,lease_pool *,lease_key,size_t size,
                          size_t offset,size_t bytes,TickType_t wait);
/* Owns a copy in the persistent descriptor, never the caller's stack bytes. */
esp_err_t lease_spi_command(lease_spi *,const void *,size_t,TickType_t wait);
esp_err_t lease_spi_reap(lease_spi *,TickType_t wait);
#endif
