/* PRIVATE QEMU ONLY. Every wrapper references the real function through a volatile
 * false flag, keeping original reachable code/static storage in the linked image.
 * No physical transfer, GPIO, I2C, ADC, IMU, codec, audio task or DMA init happens. */
#include "freertos/FreeRTOS.h"
#include "hal/board.h"
#include "hal/usb_console.h"
#include "driver/usb_serial_jtag.h"
#include <stdio.h>
volatile bool qram_real_hardware=false;
#define WRAP0(name) extern esp_err_t __real_##name(void); esp_err_t __wrap_##name(void){if(qram_real_hardware)return __real_##name();return ESP_OK;}
WRAP0(board_init)
WRAP0(usb_console_init)
WRAP0(board_present_finish)
extern esp_err_t __real_usb_serial_jtag_driver_install(const usb_serial_jtag_driver_config_t *);
esp_err_t __wrap_usb_serial_jtag_driver_install(const usb_serial_jtag_driver_config_t*c){if(qram_real_hardware)return __real_usb_serial_jtag_driver_install(c);return ESP_OK;}
extern int __real_usb_serial_jtag_read_bytes(void *,uint32_t,TickType_t);
int __wrap_usb_serial_jtag_read_bytes(void*b,uint32_t n,TickType_t t){if(qram_real_hardware)return __real_usb_serial_jtag_read_bytes(b,n,t);return 0;}
extern bool __real_board_key_event(board_keyevent_t *);
bool __wrap_board_key_event(board_keyevent_t *p){if(qram_real_hardware)return __real_board_key_event(p);return false;}
extern bool __real_board_battery_read(board_battery_t *);
bool __wrap_board_battery_read(board_battery_t*p){if(qram_real_hardware)return __real_board_battery_read(p);return false;}
extern uint16_t *__real_board_strip_next(void);
uint16_t *__wrap_board_strip_next(void){if(qram_real_hardware)return __real_board_strip_next();return board_strip();}
#define WRAP3(name) extern esp_err_t __real_##name(int,int,uint16_t*);esp_err_t __wrap_##name(int y,int h,uint16_t*p){if(qram_real_hardware)return __real_##name(y,h,p);return ESP_OK;}
#define WRAP5(name) extern esp_err_t __real_##name(int,int,int,int,uint16_t*);esp_err_t __wrap_##name(int x,int y,int w,int h,uint16_t*p){if(qram_real_hardware)return __real_##name(x,y,w,h,p);return ESP_OK;}
WRAP3(board_present)
WRAP3(board_present_sync)
WRAP5(board_present_rect)
WRAP5(board_present_rect_sync)
WRAP5(board_present_submit)

/* adc_common.c has an automatic constructor even though board_init is wrapped.
 * QEMU cannot complete the ADC self-calibration status-bit wait. Retain real
 * code but do not run these eight calibrations in this peripheral-off variant. */
#include "hal/adc_types.h"
unsigned qram_adc_calibrations_skipped;
extern void __real_adc_calc_hw_calibration_code(adc_unit_t,adc_atten_t);
void __wrap_adc_calc_hw_calibration_code(adc_unit_t unit,adc_atten_t atten){if(qram_real_hardware){__real_adc_calc_hw_calibration_code(unit,atten);return;}qram_adc_calibrations_skipped++;}
