#include "probe.h"
#include "bridge.h"
#include "embedded.h"
#include "probe_app.h"
#include "spi_mock.h"
#include "board_fox.h"
#include "hal/board.h"
#include "app_session.h"
#include "pocket/app_registry.h"
#include "esp_heap_caps.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include <assert.h>
#include <stdatomic.h>
#include <stdio.h>
#include <string.h>
static JSContext *ctx;static bool diagnostic;
static _Atomic unsigned alloc_failures;static _Atomic size_t failed_size;static _Atomic uint32_t failed_caps;
static void failed_alloc(size_t n,uint32_t caps,const char*fn){(void)fn;atomic_store(&failed_size,n);atomic_store(&failed_caps,caps);atomic_fetch_add(&alloc_failures,1);}
void qram_mark(const char *phase){
 extern int g_ksn_blend_pie;
 static bool registered;if(!registered){g_ksn_blend_pie=0;assert(heap_caps_register_failed_alloc_callback(failed_alloc)==ESP_OK);registered=true;}
 printf("QRAM_FAILURES phase=%s count=%u last_request=%u last_caps=%u\n",phase,atomic_load(&alloc_failures),(unsigned)atomic_load(&failed_size),(unsigned)atomic_load(&failed_caps));
 const uint32_t caps[]={MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT,MALLOC_CAP_DMA,MALLOC_CAP_EXEC,MALLOC_CAP_RTCRAM,MALLOC_CAP_DEFAULT};
 const char*names[]={"internal8","dma","exec","rtc","default"};
 for(unsigned i=0;i<5;i++)printf("QRAM_PHASE phase=%s cap=%s free=%u min_regions_sum=%u largest=%u\n",phase,names[i],(unsigned)heap_caps_get_free_size(caps[i]),(unsigned)heap_caps_get_minimum_free_size(caps[i]),(unsigned)heap_caps_get_largest_free_block(caps[i]));
 printf("QRAM_STACK phase=%s task=%s hwm_bytes=%u stack_type_bytes=%u\n",phase,pcTaskGetName(NULL),(unsigned)uxTaskGetStackHighWaterMark(NULL),(unsigned)sizeof(StackType_t));
}
static void task_stacks(const char*phase){const char*names[]={"ui","input","wifi","timesync","esp_timer","IDLE0","IDLE1","Tmr Svc"};for(unsigned i=0;i<sizeof names/sizeof names[0];i++){TaskHandle_t h=xTaskGetHandle(names[i]);if(h)printf("QRAM_TASK_STACK phase=%s task=%s hwm_bytes=%u\n",phase,names[i],(unsigned)uxTaskGetStackHighWaterMark(h));}}
void qram_memory_js(void){if(!ctx)return;JSMemoryUsage m;JS_ComputeMemoryUsage(JS_GetRuntime(ctx),&m);printf("QRAM_JS malloc_size=%lld memory_used=%lld malloc_count=%lld\n",(long long)m.malloc_size,(long long)m.memory_used_size,(long long)m.malloc_count);}
void qram_guest(JSContext *c){if(!diagnostic)return;ctx=c;}

/* Test controller calls no JS_Eval. It observes properties and asks main.c to
 * use its ordinary begin_run/tick_run/end_run paths. Motion comes exclusively
 * from the installed real app.onFrame callback. */
static unsigned cycle,home_turns,stage,blocked_turns,closed_turns;
static _Atomic unsigned input_progress;
void qram_input_progress(unsigned polls){atomic_store(&input_progress,polls);}
static void legacy_guards(void){
 extern esp_err_t __real_board_present(int,int,uint16_t*);
 extern esp_err_t __real_board_present_rect(int,int,int,int,uint16_t*);
 extern esp_err_t __real_board_present_sync(int,int,uint16_t*);
 extern esp_err_t __real_board_present_finish(void);
 uint16_t*p=board_strip();p[0]=0x1234;
 assert(__real_board_present(0,1,p)==ESP_ERR_INVALID_STATE);
 assert(__real_board_present_rect(0,0,240,1,p)==ESP_ERR_INVALID_STATE);
 assert(__real_board_present_sync(0,1,p)==ESP_ERR_INVALID_STATE);
 assert(__real_board_present_finish()==ESP_ERR_INVALID_STATE);
 assert(p[0]==0x1234);puts("QOWNER_LEGACY_GUARDS blocked=4 pixels_unchanged=1");
}

static bool launched;
static unsigned js_number(const char*name){if(!ctx)return 0;JSValue g=JS_GetGlobalObject(ctx),v=JS_GetPropertyStr(ctx,g,name);uint32_t n=0;JS_ToUint32(ctx,&n,v);JS_FreeValue(ctx,v);JS_FreeValue(ctx,g);return n;}
const char *qram_start_prelude(void){return qram_prelude;}
const char *qram_start_source(void){
 if(cycle==2)return "globalThis.controls=FoxControls.create(privateModelBackend.commit);globalThis.frame=function(){controls.update({});throw Error('deliberate frame failure after admission');};";
 if(cycle==3)return "globalThis.controls=FoxControls.create(privateModelBackend.commit);controls.update({});throw Error('deliberate parse failure after admission');";
 return qowner_app;
}
void qram_closed_turn(void){
 static TickType_t began_tick;static int64_t began_us;static unsigned began_input;
 ++closed_turns;
 if(closed_turns==1){began_tick=xTaskGetTickCount();began_us=esp_timer_get_time();began_input=atomic_load(&input_progress);}
 assert(!app_guest_present()&&fox_composed_shutdown_pending()&&board_fox_active());
 unsigned allocations=fox_composed_allocation_attempts();
 assert(app_start_source(NULL,0,"",0)==ESP_ERR_INVALID_STATE);
 assert(allocations==fox_composed_allocation_attempts());
 if(closed_turns<=4||closed_turns%100==0)printf("QOWNER_CLOSED_TURN number=%u restart_rejected=1 pending=%u tick_delta=%u timer_delta_us=%lld input_delta=%u\n",closed_turns,qspi_pending(),(unsigned)(xTaskGetTickCount()-began_tick),(long long)(esp_timer_get_time()-began_us),atomic_load(&input_progress)-began_input);
#ifdef FOX_TEST_UNKNOWN_OUTCOME
 if(closed_turns==1000){
  assert(xTaskGetTickCount()-began_tick>=999&&atomic_load(&input_progress)-began_input>=100);
  qram_mark("unknown_outcome_storage_retained");
  assert(fox_composed_shutdown_pending()&&!board_fox_idle());
  printf("QRAM_INTEGRITY valid=%u\n",heap_caps_check_integrity_all(true));
  puts("FOX_PRODUCT_RAM_DONE");for(;;)vTaskDelay(pdMS_TO_TICKS(1000));
 }
#else
 if(closed_turns==3)qspi_mode(QSPI_NORMAL);
#endif
}
int qram_owner_turn(bool running){
 if(!diagnostic){if(++home_turns<2)return 0;diagnostic=true;qspi_init();qram_mark("home_two_completed_loops");task_stacks("home_two_completed_loops");}
 if(!launched){
  launched=true;stage=blocked_turns=closed_turns=0;
  printf("QOWNER_CYCLE number=%u ordinary_main_loop=1\n",cycle);
  qspi_mode(QSPI_NORMAL);return 1;
 }
 if(!running){
  assert(!app_guest_present()&&!fox_composed_shutdown_pending()&&!board_fox_active());
  qram_mark("session_stopped_idle_settled");task_stacks("session_stopped_idle_settled");
  printf("QOWNER_CYCLE_END number=%u accepted=%u presented=%u stop_attempts=%u\n",cycle,fox_composed_accepted(),fox_composed_presented(),fox_bridge_closed_attempts());
  if(cycle<2){assert(fox_bridge_closed_attempts()==2);}else{assert(fox_composed_accepted()==1&&fox_composed_presented()==0);}
  if(++cycle==4){printf("QRAM_INTEGRITY valid=%u\n",heap_caps_check_integrity_all(true));puts("FOX_PRODUCT_RAM_DONE");for(;;)vTaskDelay(pdMS_TO_TICKS(1000));}
  launched=false;return 0;
 }
 unsigned accepted=fox_composed_accepted(),presented=fox_composed_presented();
 if(cycle>=2)return 0;
 if(accepted){assert(js_number("qramStarted")==1);assert(js_number("qramAdmissionRejects")==accepted);if(accepted==1&&!fox_composed_pending())printf("QOWNER_LIFECYCLE start_hook=1 callbacks=%u\n",js_number("qramFrames"));}
 if(fox_composed_pending()){
  assert(js_number("qramFrames")==accepted);blocked_turns++;
  if(cycle==0&&stage==5){
   assert(accepted==6&&presented==5&&!board_fox_idle());
   qram_mark("stop_requested_with_transport_inflight");return 3;
  }
  return 0;
 }
 if(cycle==1&&presented>=3)return 2;
 if(cycle==1&&presented==1&&stage==0){stage=1;qspi_mode(QSPI_COMMAND_DELAY);}

 if(cycle==0&&presented>stage){
  assert(presented==stage+1);stage=presented;
  printf("QOWNER_STAGE completed=%u bounded_blocked_turns=%u\n",stage,blocked_turns);
  switch(stage){
   case 1:legacy_guards();qspi_mode(QSPI_DELAY);break;
   case 2:qspi_mode(QSPI_ERROR_AFTER_ACCEPT);break;
   case 3:qspi_mode(QSPI_DMA_RETURN_ERROR);break;
   case 4:qspi_mode(QSPI_UNKNOWN_RETURN);break;
   case 5:
#ifdef FOX_TEST_UNKNOWN_OUTCOME
    qspi_mode(QSPI_NEVER_ACCEPTED);
#else
    qspi_mode(QSPI_HOLD);
#endif
    break;
  }
 }
 return 0;
}
