#ifndef FOX_CONTROL_BRIDGE_H
#define FOX_CONTROL_BRIDGE_H
#include "quickjs.h"
#include "eye_runtime.h"
bool fox_composed_commit(const FoxEyeControls*,uint32_t*);
unsigned fox_composed_hidden(void);
unsigned fox_composed_mode(int);
bool fox_composed_finish(void);
void fox_composed_close(void);
bool fox_composed_open(void);
bool fox_composed_present(void);
bool fox_composed_owned(void);
bool fox_composed_pending(void);
bool fox_composed_shutdown_pending(void);
uint32_t fox_composed_hash(void);
unsigned fox_composed_accepted(void);
unsigned fox_composed_presented(void);
/* Owner-task lifetime gate: close before app stop hooks/context destruction.
 * Only the next explicit installation on a new session may re-arm it. */
void fox_bridge_close(void);
unsigned fox_bridge_closed_attempts(void);
unsigned fox_composed_allocation_attempts(void);
int fox_bridge_install(JSContext *);
int fox_bridge_eval(JSContext *,const char *source,size_t length,const char *name);
#endif
