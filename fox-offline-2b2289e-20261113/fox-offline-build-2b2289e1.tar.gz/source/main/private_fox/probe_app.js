globalThis.view=pocket.kasane.mount('hello');
view.set({counter:'PRIVATE OWNER'});
globalThis.controls=FoxControls.create(privateModelBackend.commit);
globalThis.motion=controls.motion([0,0,0,0,1000,1,1,-1],['time','Blink Both','Gaze X','Gaze Up'],{timeUnit:'ms',interpolation:'linear'});
globalThis.qramStarted=false;
globalThis.qramFrames=0;
globalThis.qramBack=0;
globalThis.qramAdmissionRejects=0;
pocket.app.start({
  start(){qramStarted=true;},
  stop(){
    let blocked=0;
    try{privateModelBackend.commit(new Float64Array([0,0,0,0,0,0,1,.5,0]));}catch(e){blocked++;}
    try{privateModelBackend.testmode(90);}catch(e){blocked++;}
    if(blocked!==2)throw Error('stop hook reopened bridge');
    print('QOWNER_JS_STOP frames='+qramFrames+' back='+qramBack+' rejections='+qramAdmissionRejects+' accepted='+privateModelBackend.accepted()+' presented='+privateModelBackend.presented());
  }
});
pocket.app.onFrame(()=>{
  qramFrames++;
  if(privateModelBackend.accepted()!==privateModelBackend.presented()) {
    qramBack++;
    return;
  }
  const times=[0,500,1000,625,125,750,250];
  const n=privateModelBackend.accepted();
  if(n===0)view.set({counter:'MUST NOT OVERWRITE FOX'});
  const seq=motion.evaluate(times[n%times.length]);
  if(seq!==n+1)throw Error('wrong accepted sequence');
  const saved=controls.state().join(',');
  let refused=false;
  try { motion.evaluate(875); } catch(e) {refused=true;}
  if(!refused||controls.state().join(',')!==saved||privateModelBackend.accepted()!==seq)
    throw Error('pending admission did not roll back');
  qramAdmissionRejects++;
});
