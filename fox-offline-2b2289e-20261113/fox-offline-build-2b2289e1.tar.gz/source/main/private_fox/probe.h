#pragma once
#include "quickjs.h"
#include <stdbool.h>
void qram_mark(const char *phase);
void qram_guest(JSContext *ctx);
void qram_memory_js(void);
const char *qram_start_prelude(void);
const char *qram_start_source(void);
int qram_owner_turn(bool running);
void qram_closed_turn(void);
void qram_input_progress(unsigned polls);
