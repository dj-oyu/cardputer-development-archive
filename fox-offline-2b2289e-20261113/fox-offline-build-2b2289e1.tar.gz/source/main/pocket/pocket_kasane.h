#pragma once
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include "esp_err.h"
#include "quickjs.h"
#include "ui/kasane/ksn_view_host.h"
#include "ui/kasane/ksn_source.h"
#include "system/sys_notify.h"

/* QuickJS-facing APP lease into the native Kasane runtime. Allocation is lazy
 * (first Kasane call, or pocket_kasane_prepare); reading features costs no arena. Reset detaches APP and releases its wrapper
 * bookkeeping; a native SYSTEM owner keeps the shared storage alive.
 * Owner task only, reset outside guest/render callbacks. */
esp_err_t pocket_kasane_install(JSContext *ctx, void *user_data);
/* Procedural adapter publishes a prepared candidate through the APP lease. */
ksn_result pocket_kasane_proc_publish(void);
ksn_result pocket_kasane_proc_publish_at(unsigned surface,ksn_rect source_damage);
/* Create an opaque Kasane image resource for the current procedural session. */
JSValue pocket_kasane_proc_resource(JSContext *ctx);
JSValue pocket_kasane_proc_resource_at(JSContext *ctx,unsigned surface);
JSValue pocket_kasane_grid_resource(JSContext *ctx, unsigned slot,
                                    const ksn_image_port *port);
JSValue pocket_kasane_video_resource(JSContext *ctx,const ksn_image_port *port);
JSValue pocket_kasane_pixel_resource(JSContext *ctx,const ksn_image_port *port);
void pocket_kasane_pixel_invalidate(void);
bool pocket_kasane_pixel_can_stage(void);
bool pocket_kasane_video_can_select(void);
void pocket_kasane_video_invalidate(void);
void pocket_kasane_grid_invalidate(unsigned slot);
bool pocket_kasane_grid_source_port(JSContext *,JSValueConst,ksn_image_port *,uint32_t *);
/* C service publishes a session-scoped, unforgeable source capability. The
 * registry and provider must outlive pocket_kasane_reset(); revoke by
 * unregistering the handle, which makes later binds/acquires stale. */
JSValue pocket_kasane_source_capability(JSContext *ctx,ksn_source_registry *registry,
                                         ksn_source_handle handle);
/* False only while APP detach is busy: external producers must remain alive. */
bool pocket_kasane_reset(void);
/* Takes the native arena now, as one block, instead of at the guest's first
 * Kasane call. The session calls it before evaluating a source that names
 * kasane, while the heap is still unbroken. Failure is silent: the first call
 * then retries and reports OUT_OF_MEMORY where the app can see it. */
void pocket_kasane_prepare(void);
/* Bind the JS coordinate space to a host-owned viewport. The ordinary app
 * viewport is the whole panel. Overlay coordinates are region-local: direct
 * destinations are translated immediately; cache templates remain local and
 * are translated/clipped at placement. Configure before source evaluation;
 * reset restores the whole panel and normal feature profile. */
void pocket_kasane_set_viewport(int16_t x,int16_t y,int16_t width,int16_t height);

bool pocket_kasane_active(void);
// Resident suspension: while on, the kept APP lease is invisible to the host
// screens; turning it off repaints the whole panel on the next present.
void pocket_kasane_set_dormant(bool on);
/* Acknowledge a finished presenter ticket without acquiring a new source or
 * submitting fresh display work. Used before an overlay guest turn. */
ksn_result pocket_kasane_presenter_settle(bool *blocked);
/* Advances the native presenter's acknowledged/queued plans in the owner turn.
 * blocked means it submitted a new APP bank, so guest frame must wait. */
ksn_result pocket_kasane_presenter_step(bool *blocked);
/* Host-owned transient status slot. It overrides the app message without
 * mutating it; expiry reveals the latest app/playback value on the next turn. */
ksn_result pocket_kasane_presenter_host_status(const char *text,size_t bytes,uint64_t until_us);
ksn_result pocket_kasane_update_notice(const sys_notice *,uint16_t variant);
bool pocket_kasane_notice_composited(void);
bool pocket_kasane_system_pending(void);
bool pocket_kasane_has_submission(void);
/* Bound the owner wait by the next native-source expiry. A due/failed source
 * is retried by the regular frame, so it cannot create a zero-tick spin. */
uint32_t pocket_kasane_source_wait_ticks(uint64_t now_us,uint32_t cap,uint32_t hz);
ksn_result pocket_kasane_advance(uint64_t now_us);
bool pocket_kasane_animation_pending(void);
/* The Kasane half of two-core-pipeline.md sec.1.3: nothing that a present in
 * flight would race with the next turn's host work -- a schema, a provider,
 * a pixel, video or grid resource, animation blocks, a modal, a notice. */
bool pocket_kasane_present_deferrable(void);
/* Why not, as bits (0: deferrable): 1 not active, 2 schema/provider,
 * 4 video/pixel/grid resource, 8 notice, 16 animation blocks, 32 modal (open, changing or pending). */
unsigned pocket_kasane_defer_block(void);
void pocket_kasane_animations_presented(uint64_t now_us);
void pocket_kasane_set_animation_time(uint64_t now_us);
bool pocket_kasane_needs_present(void);
void pocket_kasane_invalidate(void);
// The same, for an owner that knows which 8-row bands its overlay covers.
void pocket_kasane_invalidate_bands(uint32_t bands);
uint32_t pocket_kasane_opaque_system_bands(void);
ksn_result pocket_kasane_present_complete(const ksn_display_port *,
                                          const ksn_display_completion *,ksn_render_stats *);
#ifdef KASANE_DMA_OVERLAP
// pocket_kasane_present_complete in three parts, so the render can run on the
// display task (docs/perf/two-core-pipeline.md P1a): begin and end on the UI
// task, ksn_present_job_run(&job.present) on either in between. The caller
// fills job.present.render's display, completion and stats. end returns the
// present's result; between begin and end the Kasane state answers BUSY.
typedef struct {
    ksn_present_job present;
    bool after;           // the present ran: end owes the per-resource results
    bool proc_candidate;
    ksn_result result;
} pocket_kasane_present_job;
void pocket_kasane_present_begin(pocket_kasane_present_job *);
ksn_result pocket_kasane_present_end(pocket_kasane_present_job *);
#endif
ksn_result pocket_kasane_present(const ksn_display_port *display,
                                 ksn_render_stats *stats);
ksn_result pocket_kasane_present_backdrop(const ksn_display_port *,ksn_backdrop_loader,
                                          bool occlusion_safe,ksn_render_stats *);
// Ends the guest's logical turn: frame() and its drain have run to the end,
// normally or by an exception, so an unfinished procedural frame is dropped.
void pocket_kasane_end_turn(void);
// Ends a host turn whose logical turn is still open (the VM parked frame() or
// the drain was cut by the budget): the procedural frame under construction is
// kept for the continuation that resumes it.
void pocket_kasane_park_turn(void);
ksn_input_scope pocket_kasane_input_scope(bool host_priority);
