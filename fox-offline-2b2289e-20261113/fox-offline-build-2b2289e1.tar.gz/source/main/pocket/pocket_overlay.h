#pragma once
#include <stdbool.h>
#include <stdint.h>
#include "esp_err.h"
#include "quickjs.h"
#include "overlay_core.h"
#include "keymap.h"

// pocket.overlay — the region and input contract of docs/api/common-api.md 3.1.
// New overlay drawing uses the region-scoped pocket.kasane APP endpoint. The
// display-list calls below remain as a compatibility path for saved overlays.
//
// WHY THIS IS NOT ui.basic, which is what 3.1 names.
//
// When this was written, ui.basic was pocket_ui.c, built on globalThis.ui, the
// Rust UI core and the rgb565 renderer (all since removed from the firmware).
// Two properties of that path made it the wrong one for something that lives
// ON TOP of the home screen's background:
//
//   * render_strip fills its region with 0 before it draws anything
//     (engine/backends/rgb565/src/lib.rs, the fill_rgb565(.., 0) before
//     render_region). An overlay rendered through it would not sit over the
//     scene; it would punch an opaque black hole in it.
//   * the font atlas rebuild that ui.setText triggers is, by 3.1's own
//     account, the largest single allocation a small app makes -- and an
//     overlay wants it at the moment the scene's scratch is also held.
//
// The original overlay therefore drew through this host-owned display list:
// the guest appended boxes and strings, and ui/overlay.c composited them into
// the shell's strip. The Kasane overlay path now solves the same background
// requirement through ksn_render_rects_backdrop(): the shell fills each strip
// from the live native scene, then Kasane source-over blends the APP commands.
//
// The legacy list also makes 3.1's
// "はみ出しは切り取るのではなく拒否する" a property of the surface rather than
// an intention -- every call is checked against the region and throws when it
// does not fit, and the coordinates are region-local so the shell's own rows
// are not addressable at all.
//
// Everything here runs on the JS owner task.

esp_err_t pocket_overlay_install(JSContext *ctx, void *user_data);

// The box the session may draw in. Set before the guest's source runs; the
// limits an app reads are taken from it.
void pocket_overlay_set_region(const overlay_region_t *region);

// Composites the current display list into one strip of the shell's frame.
// Cheap and silent when nothing is published.
void pocket_overlay_paint(uint16_t *strip, int strip_y, int strip_h);

// True when the guest published anything this session.
bool pocket_overlay_drawn(void);

// Drops the display list, the region and the key listeners. Called from
// app_stop() before the guest dies, with every other surface.
void pocket_overlay_reset(void);

// One keystroke from the home screen's loop, queued for the next turn.
//
// QUEUED RATHER THAN DELIVERED, and the reason is the same one section 5 gives
// everywhere else on this host: a listener must not be called from inside the
// shell's key handling, where the guest could re-enter code that is halfway
// through a frame. pocket_overlay_pump() runs it at the top of the turn, next
// to every other pump.
//
// The ring is small on purpose. A person cannot outrun a 30 Hz turn by enough
// to matter, and dropping the oldest is better than growing a buffer for input
// that has stopped being current.
void pocket_overlay_key(const keystroke_t *k);

// Delivers what pocket_overlay_key() queued. Called from app_overlay_tick().
void pocket_overlay_pump(void);
