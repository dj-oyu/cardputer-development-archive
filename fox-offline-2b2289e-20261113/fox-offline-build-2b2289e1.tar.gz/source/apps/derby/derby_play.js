'use strict';
// ---- Demo: DEMO_IDLE_S of no key at the paddock (wall clock), then the
// game plays itself, its keys fed to P(). Player state is set aside; races
// 1e6+n are the demo's seeds; silent (A = null); no save.
// GK by split, not [...'adesr1,/', 'tab']: that spread ran the guest out of
// heap on the device while evaluating (README).
// The curtain (README): FX = ms to black before the demo, ms held black,
// ms back in (also after a key), alpha steps.
const DEMO_IDLE_S = 15, DEMO_RES = 150, GK = 'a d e s r 1 , / tab'.split(' '), FX = [500, 700, 300, 8];
let dm = 0, dk = 0, dn = 0, idle = 0, kp = '', bk, fe = -1000000000, fa = 0, nw = 0;
// A key ends the demo and is spent doing so (dk '' matches no key).
function attract(b) {
  const n = nw = pocket.time ? pocket.time.now() | 0 : 0;
  if (!dm && scene !== 'pad') { dk = 0; idle = n; return; }
  const k = K.down().join();
  let hit = b || k && k !== kp;
  for (const x of GK) hit = hit || K.pressed(x);
  kp = k;
  if (!dm) {
    dk = 0;
    if (!idle || hit || k || scene !== 'pad') idle = n;
    else if (n - idle >= DEMO_IDLE_S * 1000) {
      // Its code loads now, under the black curtain; short of heap, the
      // paddock comes back and the idle clock starts over (README).
      try { pocket.app.load('demo'); } catch (e) { log('DEMOFAIL ' + e); return idle = n; }
      demo(1, n), fe = n + FX[1];
    }
    return;
  }
  if (hit || scene === 'res' && t > DEMO_RES) return fe = n, demo(0, n);
  pilot();
}
// The curtain's alpha: Q8 (256 = black) in FX[3] steps of 255 / FX[3].
const curtain = () => (mx(0, mn(256, mx(dm ? 0 : (mn(nw - idle, 1000000) - DEMO_IDLE_S * 1000 + FX[0]) * 131 >> 8,
  nw - fe >= FX[2] ? -1 : 256 - ((nw - fe) * 218 >> 8)))) * FX[3] + 128 >> 8) * 255 >> 3;
globalThis.frame = function (b) {
  if (b & 0x2000) { if (dm) demo(0); save(); return log('SAVE points=' + pts + ' race=' + raceNo); }
  try {
    attract(b);
    // The frame inline, not a function: ~150 B less resident (README).
    fr: {
      const P = k => dk === 0 ? K.pressed(k) : k === dk;
      ++t;
      if (camT > 0) --camT;
      // The curtain: wall clock only (attract's nw, fe); the game never reads it.
      fa = curtain();
      if (P('tab')) { tier = (tier + 1) % 3; const l = ['stands', 'crowd'].filter(n => live[n] || queue.indexOf(n) >= 0); drop(l); want(l); log('TIER ' + tier); }
      load();
      let xs, c, l = pick, close = -1, gate = 0, extra = null, rank;
      if (scene === 'pad') {
        if (P('a') || P('d')) { pick = (pick + (P('d') ? 1 : 7)) % 8; if (A) A.cue('move'); }
        stake = mx(50, mn(stake + (P('e') ? 50 : P('s') ? -50 : 0), 500, pts));
        if (P('1')) { log('PICK ' + (pick + 1) + ' stake=' + stake + ' odds=' + ot(od[pick])); if (A) A.cue('accept'); { enter('gate'); break fr; } }
      } else if (scene === 'gate' || scene === 'race') {
        // A camera key overrides the director for 5 s.
        if (P(',') || P('/') || P('a') || P('d')) { cam = (cam + (P('/') || P('d') ? 1 : 2)) % 3; camT = 45; man = 150; }
        if (scene === 'gate' && (!queue.length && t > 40 || t > 300)) { log('GO' + (queue.length ? ' LOADSTALL' : '')); { enter('race'); break fr; } }
        if (scene === 'race') {
          const lead = mx.apply(null, rs.x);
          if (!slow && lead > 64225280) { slow = 1; camT = 60; log('SLOW'); }
          // Slow motion shows each sim step over 4 frames: the sim never
          // changes, so the camera cannot change the race.
          disp += slow ? 1 : 4;
          for (; disp >= 4 && rs.done < 3; disp -= 4) {
            const was = rs.done;
            step(F, rs);
            const w = (rank = order(rs))[0];
            if (w !== ld) { if (lead > 32768000) log('LEAD #' + (w + 1) + ' at ' + (lead + 32768 >> 16) + 'M'); if (lead > 26214400) dl = 60; ld = w; }
            // The photo: every runner where it was when the winner crossed.
            if (!was && rs.done) photoX = photo(rs.tc[w] - rs.t + 65536 >> 4);
          }
          // The band's plan takes the gate's slot (README "plan の登録").
          if (live.gate && lead > 120) { drop(['gate']); want(['band']); }
          if (rs.done >= 3) { settle(); { enter('photo'); break fr; } }
        }
        xs = at(slow ? disp << 10 : 4096);
        if (scene === 'gate' && !(live.run && live.legs)) xs = XS.fill(-65470464);
        if (hold > 0) --hold;
        if (dl > 0) --dl;
        if (man > 0) --man;
        // The director: a shot for each stretch of the race, a lead change
        // after 400 m cuts to the new leader, a cut is held 45 frames, HEAD ON
        // (a close finish) until the slow motion (README).
        // WIDE away from every panning unit is the nearest one (wide()).
        // L: the leader (Q16 m).
        const o = ro = rank || order(rs), L = XQ[o[0]];
        let m = slow ? 3 : man ? cam : scene !== 'race' ? 0 : hold > 0 || cm === 6 ? cm :
          L < 9830400 ? 0 : L < (F.o ? OB : 26214400) ? 2 : L < 45875200 ? (dl > 0 ? 1 : 0) : L < (VS[0] - 60) * QM ? 1 : L < (VS[0] + 60) * QM ? 5 :
          L > 60948480 && L - XQ[o[1]] < 98304 ? 6 : 0;
        if (!m && scene === 'race' && !live.gate) m = wide(L);
        if (m !== cm) { cl = man ? pick : o[0]; cm = m; hold = camT = 45; log('CAM ' + (NAMES[m] || m)); }
        c = shot(m === 6 ? 0 : m, xs, cl, scene === 'gate' || camT === 45);
        close = m === 1 ? cl : -1;
        gate = live.gate;
        extra = ['map', z8(0)];
        for (let i = 0; i < 8; ++i) extra[1][i] = 8 + ((mn(XQ[i], 65536000) >> 9) * 14680 >> 23);
      } else if (scene === 'photo') {
        xs = photo();
        c = shot(4, xs);
        extra = ['photo', [120]];
        if (t > 110 || t > 20 && P('1')) { enter('res'); break fr; }
      } else if (scene === 'res') {
        if (P('1')) { ++raceNo; save(); { enter('pad'); break fr; } }
        if (P('r')) { replay = 1; { enter('gate'); break fr; } }
        l = fin.o[0];
        extra = ['conf', [t, mn(96, t)]];
      }
      if (!xs) {
        // Paddock warm-up and the winner's canter: a lone horse, camera locked.
        xs = XS.fill(-65470464);
        xs[l] = 3932160 + t * 16384;
        c = shot(1, xs, l);
        close = l;
      }
      paint(c, xs, close, gate, extra);
      const up = tx => {
        hud(tx);
        R.dm.setVisible(tx, dm > 0 && !(t & 16));
        R.fd.setVisible(tx, fa > 0);
        R.fd.setColor(tx, fa);
        // The lettering follows the face (offsets LO from its left or right
        // edge and its top); its text is the HUD's metres and first three.
        const v = !!vr && von > 10 && vr[2] - vr[0] > 99;
        if (R.v && v !== R.vs) for (let i = 0; i < 3; ++i) R.v[i].setVisible(tx, R.vs = v);
        if (v) for (let i = 0; i < 3; ++i) R.v[i].setRect(tx, [vr[i && 2] + LO[i], vr[1] + LO[i + 3], vr[2] + LO[i + 6], vr[1] + LO[i + 9]]);
        if (v && !(t & 3)) { R.v[2].setColor(tx, t & 8 ? 0xff2020ff : 0x401010ff); R.v[0].setText(tx, R.t[1].s + ' ' + R.t[0].s.slice(0, 5)); }
        if (scene === 'photo') {
          // Magnify 2x about the line and the runners' feet.
          const z = mn(256, t * 2185 >> 8), e = (z * z >> 8) * (768 - 2 * z) >> 8;
          R[0].setRect(tx, [128 - 120 * e >> 8, 128 - 100 * e >> 8, 240 + (120 * e + 128 >> 8), 135 + (35 * e + 128 >> 8)]);
        }
      };
      if (need) { build(up); need = 0; } else V.patch(up);
    }
  } catch (e) { log('FRAMEFAIL ' + scene + ' ' + e); throw e; }
  sound();
};
enter('pad');
log('READY tones=' + !!A);
