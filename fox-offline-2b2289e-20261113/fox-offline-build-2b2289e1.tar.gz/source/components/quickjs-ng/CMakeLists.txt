# SPDX-FileCopyrightText: 2026 Espressif Systems (Shanghai) CO LTD
# SPDX-License-Identifier: Apache-2.0
#
# Applications include only quickjs.h / quickjs-libc.h from INCLUDE_DIRS; port/include is
# for compiling this component only (poll.h, esp_libc_compat, etc.).

idf_component_register(
    SRCS
        "quickjs-ng/dtoa.c"
        "quickjs-ng/libregexp.c"
        "quickjs-ng/libunicode.c"
        "quickjs-ng/quickjs.c"
        "quickjs-ng/quickjs-libc.c"
        "quickjs-ng/quickjs-vm.c"
        "port/stub.c"
    INCLUDE_DIRS
        "quickjs-ng"
    PRIV_INCLUDE_DIRS
        "port/include"
    PRIV_REQUIRES
        vfs
)

# QJS_DISABLE_DUMPS: no JS_DUMP_* hooks (JS_SetDumpFlags becomes a no-op)
# while assert() stays on. Without it, assertions-enabled builds (no NDEBUG)
# get ENABLE_DUMPS and a dump-flag test on every opcode dispatch
# (docs/vm/interpreter-stages.md sec.4.1).
target_compile_definitions(${COMPONENT_LIB} PRIVATE
    QUICKJS_NG_BUILD
    QJS_DISABLE_DUMPS
    _GNU_SOURCE
)

# Measurement build (main/Kconfig.projbuild POCKET_GC_STATS): the firmware
# supplies pocket_gc_clock and reads JS_PocketGCStats / JS_PocketGCTime.
if(CONFIG_POCKET_GC_STATS)
    target_compile_definitions(${COMPONENT_LIB} PRIVATE POCKET_GC_STATS=1)
endif()

# Third-party source files: suppress warnings that are noisy but harmless in upstream code.
# -Wincompatible-pointer-types stays on (an error in GCC 14+): an int * handed to
# an int32_t * parameter is a strict-aliasing miscompile on Xtensa, where
# int32_t is long (docs/vm/aliasing-types.md). Only quickjs-libc.c keeps it off:
# its 16 sites are in the std/os modules, which the firmware never registers
# (none of them is in the ELF).
set(_qjs_vendor_warnings
    -Wno-pointer-sign
    -Wno-cast-function-type
    -Wno-unused-parameter
    -Wno-unused-variable
    -Wno-unused-but-set-variable
    -Wno-sign-compare
    -Wno-missing-field-initializers
    -Wno-type-limits
    -Wno-implicit-fallthrough
    -Wno-format
    -Wno-strict-aliasing
    -Wno-empty-body
)

# Apply vendor warnings only to upstream QuickJS files (not port/stub.c)
set_source_files_properties(
    "${CMAKE_CURRENT_SOURCE_DIR}/quickjs-ng/dtoa.c"
    PROPERTIES COMPILE_OPTIONS "${_qjs_vendor_warnings};-Wno-uninitialized;-Wno-maybe-uninitialized"
)
set_source_files_properties(
    "${CMAKE_CURRENT_SOURCE_DIR}/quickjs-ng/libregexp.c"
    PROPERTIES COMPILE_OPTIONS "${_qjs_vendor_warnings}"
)
set_source_files_properties(
    "${CMAKE_CURRENT_SOURCE_DIR}/quickjs-ng/libunicode.c"
    PROPERTIES COMPILE_OPTIONS "${_qjs_vendor_warnings}"
)
set_source_files_properties(
    "${CMAKE_CURRENT_SOURCE_DIR}/quickjs-ng/quickjs.c"
    PROPERTIES COMPILE_OPTIONS "${_qjs_vendor_warnings};-Wno-maybe-uninitialized"
)

# quickjs-libc.c: ESP_PLATFORM feature gates for unsupported host APIs; esp_libc_compat.h for lstat and newlib.
set(_qjs_libc "${CMAKE_CURRENT_SOURCE_DIR}/quickjs-ng/quickjs-libc.c")
set(_qjs_libc_compat "${CMAKE_CURRENT_SOURCE_DIR}/port/include/esp_libc_compat.h")
set_source_files_properties(${_qjs_libc}
    PROPERTIES
        COMPILE_OPTIONS "-include;${_qjs_libc_compat};${_qjs_vendor_warnings};-Wno-incompatible-pointer-types"
)

# newlib: poll and related declarations (quickjs-libc.c includes <poll.h> via port/include/poll.h).
idf_build_get_property(_qjs_idf_path IDF_PATH)
target_include_directories(${COMPONENT_LIB} SYSTEM PRIVATE
    "${_qjs_idf_path}/components/newlib/platform_include"
)
