"""PRIVATE independent actual-target checks; no remote/device operation."""
from pathlib import Path
import json,shlex,subprocess,hashlib,datetime,tempfile
E=Path(__file__).resolve().parent
old=Path('/workspace/cardputer-adv-pocketjs');ref=old/'build_onboarding/compile_commands.json'
entries=json.loads(ref.read_text());lookup={str(Path(x['file']).relative_to(old)):x for x in entries if x['file'].startswith(str(old)+'/')}
roots={v:Path('/workspace/derby-detail-'+v) for v in ('recovery','native','batch')};files=['main/main.c','main/app_session.c','main/pocket/derby_fixed_workload.c'];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before={v:{f:sha(r/f) for f in files} for v,r in roots.items()};rows=[];commands=[];logs=[]
def invocation(v,f,mode,extra):
 root=roots[v];entry=lookup.get(f,lookup['main/app_session.c']);args=[];skip=False
 for arg in shlex.split(entry['command']):
  if skip:skip=False;continue
  if arg=='-o':skip=True;continue
  if arg in ('-c',entry['file']):continue
  if arg.startswith('-I'+str(old)+'/main') or arg.startswith('-I'+str(old)+'/components'):arg=arg.replace(str(old),str(root),1)
  args.append(arg)
 args+=['-DPOCKET_DERBY_MEASURE=1','-DPOCKET_DERBY_FIXED_WORKLOAD=1','-DPOCKET_DERBY_TELEMETRY=1','-DPOCKET_DERBY_COMPARE_FIXED_HW=1']
 if mode=='on':args+=['-DPOCKET_DERBY_DETAIL_MEASURE=1']
 if v=='batch':args+=['-DPOCKET_DERBY_RUNNER_BATCH=1']
 args+=extra;commands.append({'cwd':entry['directory'],'argv':args});return args,entry['directory']
for v,root in roots.items():
 for f in files:
  for mode in ('off','on'):
   args,cwd=invocation(v,f,mode,['-fsyntax-only',str(root/f)]);p=subprocess.run(args,cwd=cwd,capture_output=True,text=True)
   row={'variant':v,'file':f,'detail':mode,'exit_code':p.returncode};rows.append(row);logs.append(json.dumps(row)+'\n'+p.stdout+p.stderr);print(row,flush=True)
objdir=E/'objects';objdir.mkdir(exist_ok=True);objects=[]
for f in files:
 for mode in ('off','on'):
  obj=objdir/(Path(f).stem+'-'+mode+'.o');args,cwd=invocation('recovery',f,mode,['-fstack-usage','-c','-o',str(obj),str(roots['recovery']/f)]);p=subprocess.run(args,cwd=cwd,capture_output=True,text=True)
  (obj.with_suffix('.compile.log')).write_text(p.stdout+p.stderr)
  assert p.returncode==0,(f,mode,p.stderr)
  nm=subprocess.check_output([str(Path(args[0]).with_name('xtensa-esp32s3-elf-nm')),'-S','--defined-only',str(obj)],text=True);obj.with_suffix('.nm.txt').write_text(nm)
  stack={}
  for line in obj.with_suffix('.su').read_text().splitlines():
   name,size,kind=line.split('\t');stack[name.rsplit(':',1)[-1]]=int(size)
  objects.append({'file':f,'detail':mode,'object_sha256':sha(obj),'static_data_bytes':sum(int(l.split()[1],16) for l in nm.splitlines() if len(l.split())==4 and l.split()[2] in 'bBdD'),'stack':stack})
# Exclude only diagnostic __LINE__/__FILE__ constants so added source lines do
# not masquerade as instrumentation when checking the preprocessed OFF body.
preservation=[]
with tempfile.TemporaryDirectory() as d:
 for f in files:
  prior=Path(d)/Path(f).name;prior.write_bytes(subprocess.check_output(['git','show','90b9f686e7c6897bc53e26e3b82fbe5569b968fd:'+f],cwd=roots['recovery']))
  outputs=[]
  for source in (prior,roots['recovery']/f):
   args,cwd=invocation('recovery',f,'off',['-E','-P','-Wno-error','-D__LINE__=1','-D__FILE__="normalized-source.c"',str(source)]);p=subprocess.run(args,cwd=cwd,capture_output=True)
   assert p.returncode==0,p.stderr.decode();outputs.append(p.stdout)
  preservation.append({'file':f,'normalized_OFF_preprocessor_identical':outputs[0]==outputs[1],'sha256':[hashlib.sha256(x).hexdigest() for x in outputs],'scope':'Preprocessor equivalence with __LINE__/__FILE__ standardized, not object byte identity or runtime proof.'})
after={v:{f:sha(r/f) for f in files} for v,r in roots.items()}
report={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Actual Xtensa GCC15.2 / retained IDF6.0.1 config: 18 syntax and six object builds. Not exact diagnostic config/link or device proof.','source_sha256':before,'source_changed_during_check':before!=after,'syntax':rows,'objects':objects,'off_preservation':preservation,'pass':before==after and all(r['exit_code']==0 for r in rows) and all(r['normalized_OFF_preprocessor_identical'] for r in preservation),'reference_compile_commands_sha256':sha(ref),'heads':{v:subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip() for v,r in roots.items()}}
(E/'final-target-report.json').write_text(json.dumps(report,indent=2)+'\n');(E/'final-commands.json').write_text(json.dumps(commands,indent=2)+'\n');(E/'final-syntax.log').write_text('\n'.join(logs));print('target_pass',report['pass'])
