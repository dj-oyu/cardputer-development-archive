# PR19 通常ファームウェア: 自動受入結果

PR19 exact `c47084d087faf3376831b821e4c03de87a3495d5` の正式source/build/flashと登録済みderby_smokeが成功した。最適化PR14/15を含まない通常候補。物理LCD確認と数値性能・heap余裕は未確認で、通常版の統合完了や全ゲート合格とは主張しない。

| 自動ゲート | 結果と証拠 |
| --- | --- |
| source identity | tree `918d5e8284c2b8e4a1f6492857318baa3ffc7f09`、receipt `4c82a0e149ed4301203f559dd47e3816a9982b7616fb7855e88cff7e27503073` |
| build | ESP-IDF6.0.1/esp32s3、登録固定argv、成功manifest verified |
| 通常mode | exact sourceの4 flags OFF既定、新規configure、override無し、通常7chunk生成、telemetry/measure/fixed Cの実compile無しを照合。現MCPは4flags専用ELF native-symbol証明を返していないため、直接ELF mode probe済みとは呼ばない |
| flash | 全segment SHA256 readback verified、IDF6.0.1とELF prefix `3850c1d3a`一致、port closeを経て成功。boot文字列単独のcryptographic proofとはしない |
| app/demo/race | local.derby READY後、同race `1000001` / seed `D7150E2C` のpad→gate→race→photo→res、DEMO START/ENDを順序付き観測。full demo cycle observed=true、events_truncated=false |
| capture | photo状態で一回s、同phase/race/seedを維持。PNG240×135/2711B、SHA256 `200cea82d2e1db815084cd080159be1650385605f58c7debce0611010daf9887`。render bufferのみ、coherent_frame/LCD acknowledgementはunknown、pixel oracle未検証 |
| 終了 | explicit q後にfresh HOME_READY、exit_home_observed=true。操作全体84701ms、serial_close succeeded |

実BIN SHA256 `659b45b919c75588aceb7a8b0c5c4fa36122469e3b0b27cf0b3a7bbfb4c5bbb5`、ELF SHA256 `3850c1d3a249237a39e05d4baf68b68ab80cec6ae588a2ca07c018b48d93e05d`。成功後のretained LKG receipt `c1acd1f54f1e18b123217b5d0fd9a1d163d192d719ee4326e92c8de006259a6e`。旧recoveryの削除や自動restoreはしていない。

## job chain

- source: `derby-normal-pr19-source-c47084d0-20261019`
- build: `derby-normal-pr19-build-c47084d0-20261019`
- flash: `derby-normal-pr19-flash-c47084d0-20261019`
- smoke: `derby-normal-pr19-smoke-c47084d0-20261019`
- broker epoch: `20f5e80fb19643a3af090dffe3dd8f00`

smoke planのconfigured expected hashは既存登録値 `06b1c1c8…` のままで、firmware_verificationはconfigured_expected_hash_only。diagnosticsのreceipt associationもmissing/durable_receipt_chain_unavailable。ここを更新・偽装していない。今回のhead対応は、直前のowned source/build/全segment readback、同device fingerprint・同exclusive lease、間に別hardware job無しという明示した操作列に基づく。broker単独がsmokeのcryptographic receipt chainを認証したとは主張しない。

## 未確認項目

- camera8/9のWIDE選択はcamera eventsで観測したが、telemetry samples/measurements/evaluation checkpointsは0。WIDE >=2fps、guest heap/eval余裕は欠測で、数値PASS不可。
- moving sway/PAN・遮蔽や欠け/ちらつき・継続した動き、物理LCDの実表示は未確認。静止render-buffer画像を連続画像やLCD転送の証明にしない。
- diagnosticsはquality.missing=true、measurement_missing=true、partial_line_or_fault_possible=true、final_write_outcome_unknown=true、complete_error_count_verified=false。構造化eventsにfatal/LOADSTALLが無いことを、全エラー不在の証明とはしない。read_device_logs(smoke)はdevice_logs_not_availableを返し、一般serial生ログは当toolでは取得できなかった。
- 詳細fixtureの結果を通常受入へ転用していない。source cache13/16、比較の最終3headはまだ未取得。

## ユーザーに頼む最小確認

自動smoke中の画面を見ていなければ、通常版が残っている間にHOMEからDERBY WATCHを開き、15秒キーを触らずデモ1周を目視する。脚や首、首振り/WIDEの動き、手前の柵・馬・大型画面の前後関係、欠け/ちらつき/長い停止を確認し、最後にBack（バッククォートキー）で物理HOMEへ戻る。

必要な場合だけデモを任意キーで抜け、パドックで1を押してゲートへ進み、`,` または `/`（A/Dも可）でWIDEを選ぶ。表示の滑らかさは目視所見であり、>=2fpsの数値合格にはしない。数値fps/heap/evalの欠測は、登録外コマンドやUSB直接操作を追加せず、別途対応した計測契約が必要。一般ユーザーの最小回答は「実機画面で動き/前後関係/欠け・ちらつき/停止/HOME戻りに問題があったか」。

## 保存先

`device-private/normal-smoke-result.json` にphase/race/seed・diagnostics/provenance、`normal-smoke-capture.json` とPNGにcapture証拠、`normal-flash-receipt.json` に全240行のbounded flash logsとsummary、`normal-build-output.json` に全2111行のbounded build logsとmanifestを保持。いずれもprivate限定。source/build/flash分はLibrary `libfile_b00f732ba03881918ded1f5c1ed65400`、archive SHA256 `4f21c5ecd6484611ad1efc0f8bb56bcbfb361784f343f05f9de482213b37ea21` に退避済み。smokeを含む最終通常受入zipを別途保存する。

最終通常受入zipのprivate Library ID: `libfile_99c7b9ae74908191b9cced7a7972eab9`、file ID: `file_00000000dc2881f59b46daae0196028c`、SHA256 `6a0d84e25e266b48cce6001e25e3e29169f3adeefd32682853f382f92ceeecca`。
