# DERBY WATCH 詳細計測 引継ぎ（2026-10-19 UTC）

ローカル実装・host検証・専用3branch/Draft PR・最終head全29 CIは完了。旧担当WIPは取得できず、指定exact元3版の仕様から再構成した。旧コードと同一とは主張しない。後続の親指示による正式MCP実機検証では、baselineの有限trial後にAPP ERRORとなる終了経路を検出し、厳格判定を不合格としてnative/batchの実機工程を停止した。mergeしていない。

| 版 | exact元 | 現在の専用branch / exact head | Draft PR |
|---|---|---|---|
| baseline | 0c52600fc34deafbadc53bc48e4fc98931e404e4 | feature/derby-detail-baseline-20261019 / 90b9f686e7c6897bc53e26e3b82fbe5569b968fd | https://github.com/dj-oyu/cardputer-adv-pocketjs/pull/21 |
| native | 44f9c56121b5aab4fb2eca0fcf9fbe54d833a276 | feature/derby-detail-native-20261019 / baa41e984339436dca6157a29326d3b863825761 | https://github.com/dj-oyu/cardputer-adv-pocketjs/pull/22 |
| batch | 3a641d4d996938339b44fe735aba876ad031b3a2 | feature/derby-detail-batch-20261019 / fded982793d0b99246a7335fe22d791985fd6e96 | https://github.com/dj-oyu/cardputer-adv-pocketjs/pull/23 |

作業場所は順に /workspace/derby-detail-recovery、/workspace/derby-detail-native、/workspace/derby-detail-batch。3つともclean。既存 /workspace/cardputer-adv-pocketjs もcleanで保護。native/batchは独立比較版で累積版ではない。

## 実装とhost検証

26 elapsed stageと13 eventを固定サイズ集計。JS制御/simulation/pose/projection/sort/runner/HUD、描画prepare/backdrop/composite/span、別procedural VM setup/zero/code copy/validate/match/run/segment append、TX copy/submit/reapと論理bytes・回数を観測する。owner-task限定、ISRはscope stackに触らず、continuation休止時間を除外する。inclusiveとexclusiveを混ぜない。elapsedにはpreemptionやI/O完了待ちが含まれ、純transferやCPU専有時間ではない。bytesは論理量で実bus trafficではない。大きなhistogramや最適化を導入していない。

同fixture/seed/camera・390→510の120contexts・3 dependent replay・250ms watchdog・180秒session・tail最大8step/frameを保持。報告は窓/tailの外で1行/frame、summaryとENDも別frame、最終出力前に250ms余裕を要求する。詳細OFFの生成JSと主要5C .textを元exact版と照合し、無効時のscope引数評価も排除。

- 最終CIはbaseline9/native9/batch11、計29すべて成功。CI-FINAL.json。ON/OFF各3版の実target linkとgenerated JS/BIN-ELF proof、CI-TARGET-RECEIPTS.json。
- host3版ON/OFF各3repのASan/UBSan/O2、m32、通常14 scenarios、JS syntax、parser負例、slow出力110ms/42拒否/最終write期限境界、batch proof正例8/負例26を含む。詳細はcode checkpoint REPORTと各log。実機終了処理をhost harnessが再現していない検証限界が今回判明した。
- 全窓120contexts/4975draws、race 5DC86E18、input 986b2e6e027af00d、procedural pixel c1b0fdbde748d0de、panel cec4b765a2794b14で一致。
- host各rep 3,888,000送信pixelsのうち3,499,706が前frame同値、2040stripsのうち449が全同値。性能効果や差分送信節約は断定しない。
- host O2 ON/OFF median比 baseline1.1307/native1.0761/batch1.0922。host/oracleを含む対照でありtarget overheadの証明ではない。
- static BSS/data増分3056B、dd state2304B、CI最大per-function stack2992B ON/OFF。全call chain/runtime high-waterではない。独立review結果も保存。

host再現例（ネットワークや実機操作を含まない）:

```sh
python3 /workspace/derby-detail-recovery/tools/games/compare_derby_detail.py --baseline /workspace/derby-detail-recovery --native /workspace/derby-detail-native --batch /workspace/derby-detail-batch --out /workspace/derby-evidence/reproduced-host --fast
python3 /workspace/derby-detail-recovery/tools/games/compare_derby_detail.py --baseline /workspace/derby-detail-recovery --native /workspace/derby-detail-native --batch /workspace/derby-detail-batch --out /workspace/derby-evidence/reproduced-asan
```

## 実機baseline: 厳格不合格、再試行停止

正式MCPだけで次を直列実行。直接USB、任意コマンド、登録/認可/server変更、cache削除/上限変更は行っていない。

- source job derby-detail-baseline-source-90b9f686-20261019、receipt 7a47b152ae691662b3099f7176b071d8e83a6be7f1cd9e77cdcbde8e05c5fa37、tree e71155890817044917d63c1d08f785f322d44804。
- build job derby-detail-baseline-build-90b9f686-20261019。actual generated view、detail/fixed/measure/telemetry ON proofを照合。BIN c71e7381be4ecfed8c8afeadf2d6812de920b7668bcc8b259c55202e6e22d8c4、ELF 166214130f735f298e64dc3e2143d01e645ad3c11de971a4d5f7e459f30c20d8。
- flash job derby-detail-baseline-flash-90b9f686-20261019、full segment readback・passive boot確認。ELF prefix166214130一致。build2074行/flash233行を欠落なしで保存。
- fixed job derby-detail-baseline-fixed-90b9f686-20261019、一度だけ実行。21:27:33終了。broker coarseはsucceeded/derby_fixed_trial_verified。raw31098B、88.954秒、transport complete、gap/overflow/truncated/partial/reset/disconnect/refusedなし。SHA256 c25c11fc9a04e73a430291d202f00fceca3e94748976ec37a5604e9e4d66b3d5。
- 3summaryすべてvalid1/quality0、120contexts/done120、cont0/faults0/refused0/tx_fail0。広告work_us 6814529/6812061/6810101は不合格trialからの未認定観測に留める。
- raw236行 valid END、238行 InternalError: interrupted、続くstack（fixture冒頭のキー確認）、246行APP_STOPPED、247行HOME_READY。完全ログにFRAME RUNAWAY/LOADSTALL/Guru Meditation/stack overflow/watchdog/OOM記録はない。これはruntime high-waterや物理LCD品質の証明ではない。
- unchanged strict parserが detail runtime fault in complete transport と拒否。実機captureはcapture_not_available（固定trialは画像captureなし）。ユーザーからのAPP ERROR→HOMEの目視報告と整合し、正常終了と認定しない。

原因の有力な説明は既存self-exit経路。main/pocket/pocket_app.c:638-648はapp.exitがfailed turn/interruptとして報告される制約を明記し、main/app_session.c:2362はexit_requestedでstopを立てた後guest frameへ進む。fixtureは完了時pocket.app.exit()を使う。終了時意図的interruptと計測中障害を区別する根拠の整備、または診断限定のcleanな終了経路の実装が必要。親の原因/影響判断前にparserの例外無視・再flash・再試行を行わない。

別のparser不備: detail parserはSTOP/HOMEを裸の行で要求し、実機のESP-IDF接頭辞に未対応。actual rawの判定を保持したまま、明示的な人工specimenでこの独立障害も再現。failure-forensics.json。prefix正規化を設計する場合も曖昧なsubstring一致を避け、ANSI/ログ形式・順序・重複・欠落・前後例外を負例で固定する。

現在active/queueなし、ownerなし、lease解放済み、outcome確定。装置に入っているのは詳細baseline。native/batch source/build/flash/有限trialは未着手。自動restoreなし。cache14/16、元3版・normal recovery artifactsを保持。次工程の停止は権限拒否ではなく、確定した厳格試験不合格とユーザーの停止指示による。

## PR19通常版の既実施証拠

c47084d087faf3376831b821e4c03de87a3495d5について、source/build/verified flash/registered smoke成功。全demo cycle、race/seed/phase一致のphoto render-buffer capture、q後fresh HOMEを確認。BIN659b45b919c75588aceb7a8b0c5c4fa36122469e3b0b27cf0b3a7bbfb4c5bbb5、ELF3850c1d3a249237a39e05d4baf68b68ab80cec6ae588a2ca07c018b48d93e05d。NORMAL-PR19-RESULT.md参照。既実施jobを再実行していない。

物理LCD/moving映像、数値WIDE>=2fps、heap/eval余裕、LOADSTALL完全性は未確認。smoke qualityのmissing/partial/final-write-unknownを含み、通常版overall PASS/merge-readyとはしない。4flag OFFはexactsource/configure/actual chunksと非診断C照合による導出で、直接ELF4flags native-symbol proof未取得。通常版は後続baseline flashにより現在未設置。再flashは自動実施しない。

## private Libraryと復元

1. 完全コード/patch/最終CI/独立review/復元helper: libfile_e41453d210d48191b35b9890e8667a3c、file_00000000323c81f7bce346db2ac5ad38、21,727,993B、SHA256 2e9420333d18cde41aab45902f65720d444ab62529d675bb96d7757f86b6058c。local derby-detail-code-ci-final-20261019.zip。作成時はbaseline build中であり、その時点のREPORTを今回の状態より優先しない。
2. baseline raw/result/build/flash/strict failure: libfile_88dd1d5f773481918423599b8afc357e、file_0000000071f081f78b8f493b997be109、98,159B、SHA256 cce838b39b26b807b319da1bb84568e6c9e94bc5a858fbd944c20067c3e62e43。
3. 通常PR19 acceptance: libfile_99c7b9ae74908191b9cced7a7972eab9、69,239B、SHA256 6a0d84e25e266b48cce6001e25e3e29169f3adeefd32682853f382f92ceeecca。

完全patchは /workspace/derby-code-ci-checkpoint/patches/{baseline,native,batch}.patch。bundleはpublished exact headsとroot blobsを保持するが意図的なshallow境界を持つため、通常cloneでなく同checkpointのrestore_checkpoint.pyを使う。pinned submodule Gitlinksを含むが全submodule履歴は含まない。offline復元smokeを実行し、tree/hashとhost checksを検証済み。秘密・device rawは公開repoへ出していない。

未完は、終了時APP ERRORの原因/影響レビューとclean終了・厳格parserの整合、修正時の最終head検証、native/batch実機詳細、同head実機ON/OFF overhead対照、通常候補の物理/数値acceptance。キャッシュ残2枠と現在の許可された最終3headを守り、新しいfirmware headを追加する前に親と工程を確定する。
