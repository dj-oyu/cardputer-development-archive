# Detailed baseline physical trial: strict failure

Exact head 90b9f686e7c6897bc53e26e3b82fbe5569b968fd; source, registered build, verified flash completed.
Trial derby-detail-baseline-fixed-90b9f686-20261019 completed 2026-10-19 21:27:33 UTC. Broker coarse result succeeded/derby_fixed_trial_verified, raw log 31098 bytes.

The unchanged strict local detailed parser rejects the complete transport: InternalError: interrupted after DERBY_FIXED_END valid=1 quality=0, before APP_STOPPED and HOME_READY. Therefore this is NOT a strict detailed PASS. No native or batch device source/build/flash/trial was started after this failure. Lease released after broker confirmed no active or queued operation.

Inspection of existing pocket_app.c documents app.exit intentionally delivering a failing turn/interrupt; cause and appropriate acceptance policy need review. Do not silently suppress the error, claim target overhead, retry the same device job, or continue variants.

The saved raw bytes and broker receipts are private. No source, registration, server, cache, or hardware state was changed to bypass the gate. Current installed image remains the verified detailed baseline; no automatic restore.
