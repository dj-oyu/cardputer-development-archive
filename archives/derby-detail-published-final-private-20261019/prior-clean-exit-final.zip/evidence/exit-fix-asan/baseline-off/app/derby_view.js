'use strict';
const V = pocket.kasane, H = V.procedural, K = pocket.input.keys, log = m => { if(m==='READY tones=true'||m==='READY tones=false') console.log('DERBY ' + m); else if(m.indexOf('FAIL')>=0||m.indexOf('LOADSTALL')>=0||m.indexOf('DEGRADE')>=0) pocket.derby.fixture(4,0,0,0,0,0,0); };
// Frames now, while the heap still has holes that size (MEGADEMO's lesson).
H.beginFrame(0);
const res = H.resource(), live = {}, queue = [];
derby.L = live; // the host oracle names plans by these handles
let reg = 0;
// One plan a frame from frame 1 (info() is null while evaluating), only
// with 18 KB free: a register turn dipped the heap 12.6 KB at most on the
// device (README), leaving 5 KB.
function load() {
  const n = queue[0];
  if (!n) return;
  try {
    if (pocket.memory && pocket.memory.info().internalFreeBytes < 18432) return;
    // The plan n: a built-in plan's name (derby_prog.js), exactly its
    // declared arguments, and the points of a typed-point plan.
    const k = KN[tier], i = +n[1];
    let p;
    if (n[0] === 'g' && i >= 0) {
      // Gallop frame i of the close-up horse.
      const x = [], y = [], ph = PI * i / 3, b = bob(i), put = (u, v) => { x.push(rnd(8 * u)); y.push(rnd(8 * v)); };
      let jx = 0, jy = 0;
      for (let j = 0; j < BODY.length; j += 2) {
        const u = BODY[j], l = BODY[j + 1];
        if (u < 20) { put(jx = u, jy = l + b); continue; }
        const a = .55 * sin(ph + u - 20), kx = jx + l * sin(a), ky = jy + l * M.cos(a), a2 = a - .9 * mx(0, sin(ph + u - 18.6));
        put(kx, ky); put(kx + l * sin(a2), ky + l * M.cos(a2)); put(kx, ky); put(jx, jy);
      }
      p = ['nil', [], {kind: 'affineQ14Points', x: x, y: y, color: 0xef5b, coeff: [8192, 0, 0, 8192, HX * 16384, HY * 16384]}];
    } else if (n === 'hd') p = ['nil', [], {kind: 'affineQ14Points', x: HD[0], y: HD[1], color: 0xad55, coeff: [16384, 0, 0, 16384, 0, 0]}];
    else if (n[0] === 'r' && i >= 0) p = ['runner', [F.h[i].coat, SILK[i], SILK[i] ^ 0x8410]];
    else if (n[0] === 't' && i >= 0) p = ['pt', [512 + 288 * i]];
    else if (n === 'crowd') p = [n, [k[1], k[6], k[7]].concat(KN[3].slice(0, 5))];
    else p = [n, k.slice(0, n === 'stands' ? 4 : 0)];
    live[n] = H.register('derby.' + p[0], p[1], p[2]);
    queue.shift(); ++reg;
  } catch (e) { log('LOADFAIL ' + n + ' ' + e); queue.push(queue.shift()); }
}
// Draws plan n now if it is registered (inputs are copied: pocket_proc.c).
const dr = (n, a, b, c, d, e, f, g, h) => { if (live[n]) H.draw(live[n], a, b, c, d, e, f, g, h); };
const want = l => { for (const n of l) if (!live[n] && queue.indexOf(n) < 0) queue.push(n); };
function drop(l) {
  for (const n of l) {
    if (live[n]) H.unregister(live[n]);
    delete live[n];
    if (queue.indexOf(n) >= 0) queue.splice(queue.indexOf(n), 1);
  }
}

// ---- Sound: audio.tone plays one note at a time; a short note queue.
let A = null, notes = [], busy = 0;
try { if (pocket.capabilities.get('audio.tone').available) A = pocket.audio; } catch (e) {}
const done = () => { busy = 0; }, nop = Boolean; // nop: any function without effects
function sound() {
  if (!A || busy || !notes.length) return;
  const n = notes.splice(0, 2);
  busy = 1;
  try { A.tone({frequencyHz: n[0], durationMs: n[1], gain: .45}).then(done, done); } catch (e) { busy = 0; }
}
// Notes as Hz, ms pairs; WIN and LOSE open with the camera click.
const FANFARE = [523, 110, 659, 110, 784, 110, 1047, 260], BELL = [1568, 60, 1568, 60, 1568, 260],
  WIN = [2637, 25, 784, 90, 988, 90, 1175, 90, 1568, 320], LOSE = [2637, 25, 392, 160, 330, 260];

// ---- State
let pts = 1000, raceNo = 1, pick = 0, stake = 100, scene = '', t = 0, cam = 0, camT = 0, R = [], need = 0;
let rs = null, od = null, fin = null, photoX = null, replay = 0, ph = z8(0);
let cx = 0, disp = 0, slow = 0, ld = -1, cm = 0, hold = 0, dl = 0, man = 0, cl = 0, vr = null, von = 0, ro = [0, 1, 2, 3, 4, 5, 6, 7];
// Lanes drawn, the order far to near (README "レーンの横位置").
let lz = DL.slice(), zo = [7, 6, 5, 4, 3, 2, 1, 0];
const hex = s => ('0000000' + s.toString(16).toUpperCase()).slice(-8), num = i => 'NO.' + (i + 1),
  th = p => (p + 1) + (['ST', 'ND', 'RD'][p] || 'TH');
// Seeds: the hardware's, mixed with the stored race count (README).
const ST = pocket.storage, HW = pocket.random.seed();
let sn = 19;
function save() { /* Diagnostic image: never write player storage. */ }
// Finite fixture: no player storage read or write.

// The screen (README "Turf vision"): centre x, depth, half width, bottom
// and top height (m), a 4:1 face.
const VS = [840, 34, 20, 6, 16], FN = [3, 4, 6], LO = [3, -25, -30, 1, 1, 4, -30, -2, -26, 12, 12, 8];
// The course: its sections [m along the inner rail, curvature 1/m, start x,
// z, tangent x, z (, heading on a bend)]. pose(g, w): the point g m along it,
// w m out from the side cameras' line (the side view's depth: inner rail 11,
// screen 34, stands 40), as [x, z, tangent]; a bend's centre is 1/curvature
// in from the rail. The straight gives [g, w, 1, 0] exactly. The oval (README
// "楕円"): the back straight, a 120 m bend to the right, the home straight on
// the straight's line from 650 m. CH: chord ends (pocket.derby).
const OB = 650 - 120 * PI, SC = [], OC = [[OB, 0, 650 + OB, -218, -1, 0], [120 * PI, -1 / 120, 650, -218, -1, 0, PI], [2e3, 0, 650, 0, 1, 0]];
let CRS = SC, CH;
function pose(g, w) {
  if (CRS === SC) return [g, w, 1, 0];
  let i = 0;
  while (i < 2 && g > CRS[i][0]) g -= CRS[i++][0];
  const e = CRS[i];
  let x = e[2], z = e[3], c = e[4], d = e[5];
  if (e[1]) {
    const r = 1 / e[1] + DNR, C = M.cos(e[6] + e[1] * g), S = sin(e[6] + e[1] * g);
    x += (S - d) * r; z -= (C - c) * r; c = C; d = S; g = 0;
  }
  return [x + g * c - w * d, z + g * d + w * c, c, d];
}
// ---- Cameras, a row a unit: [f, height, horizon y, lead, smoothed, lo,
// hi]. A side unit looks along the course's normal from cx: the leader
// lead/f m ahead of it (eased when smoothed, set on a cut), cx held within
// lo..hi. WIDE, CLOSE (set per lane), FIELD, FINISH (slow motion), PHOTO
// (along the line: the line is x=120), VISION (low, within 30 m of the
// screen); HEAD ON is a still (paint).
const CAMS = [[100, 9.7, 33, 880, 1, -1e9, 1e9], 0, [58, 15, 36, 880, 1, -1e9, 1e9], [170, 7, 22, 640, 0, -1e9, D - 6],
  [300, 4, 30, 880, 0, D, D], [130, 1.6, 84, 880, 1, VS[0] - 30, VS[0] + 30], 0,
  [200, 6, 28, 100, -14, -14], [200, 6, 28, 460, -14, -3], [200, 6, 28, 820, -14, -14]],
  NAMES = ['WIDE', 'CLOSE', 'FIELD', 'FINISH', '', 'VISION', 'HEAD ON', 'WIDE 1', 'WIDE 2', 'WIDE 3'];
// Panning units (rows 7..9, [least f, height, horizon y, g, w, w on the
// oval: WIDE 2 near its bend's centre]; README):
// turned to the leader, f keeping it PAN[1] px long, at most PAN[2]. WIDE
// takes the nearest when it is over PAN[0] m from the leader, or the leader
// is on the oval's bend (the side view does not bend: README). Height 6 and
// horizon 28 are baked in the pan plans. PAN[3]: the oval's bend in chords.
// pc: the unit in use, [x, z, unit vector to the aim, f, distance to the
// aim], null for a side unit.
const PAN = [60, 14, 1500, 16];
let pc = null, vq = null;
function wide(g) {
  let m = 0, e = 1e9;
  for (let i = 7; i < 10; ++i) {
    const q = pose(CAMS[i][3], CAMS[i][CRS === OC ? 5 : 4]), a = pose(g, (DNR + DFR) / 2), x = a[0] - q[0], z = a[1] - q[1];
    if (x * x + z * z < e) e = x * x + z * z, m = i;
  }
  return e > PAN[0] * PAN[0] || CRS === OC && g > OB && g < 650 ? m : 0;
}
// Sets cx for shot m (1: locked on lane l) and returns the camera.
function shot(m, xs, l, cut) {
  pc = null;
  if (m === 1) {
    const f = 24 * lz[l];
    cx = xs[l] - 12.5 * U - (HX - 120) / 24;
    return [f, 3, HY + 6 * HS - 72];
  }
  const c = CAMS[m];
  if (m > 6) {
    const q = pose(c[3], c[CRS === OC ? 5 : 4]), a = pose(mx.apply(null, xs), (DNR + DFR) / 2), x = a[0] - q[0], z = a[1] - q[1], e = M.sqrt(x * x + z * z);
    pc = [q[0], q[1], x / e, z / e, mn(PAN[2], mx(c[0], PAN[1] * e / 2.4)), e];
    return [pc[4], c[1], c[2]];
  }
  const tgt = mx.apply(null, xs) - c[3] / c[0];
  cx = mx(c[5], mn(c[6], c[4] ? cut ? tgt : cx + (tgt - cx) * .12 + mx.apply(null, rs.v) * DT * .88 : tgt));
  return c;
}
// Draws one frame of the course (dr, no list), back to front, for camera c
// at x0. K: the screen's face when this is its feed, a camera 6 m behind
// the leader, low on the rail: rails and the leading FN[tier] runners,
// those wholly inside K.
function course(c, x0, xs, close, gate, K) {
  if (!K && pc) return pan(xs);
  const f = c[0], h = c[1], hy = c[2], k = KN[tier], o = K ? (K[0] + K[2]) / 2 : 120, R = K ? K[2] - 1 : 245,
    sx = (w, d0) => o + (w - x0) * f / d0, gy = d0 => hy + h * f / d0, ty = (d0, e) => hy + (h - e) * f / d0;
  const rail = (d0, col) => {
    const p = f / d0, s = k[4] * p, a = sx((K ? M.ceil : flo)((x0 - (o - (K ? K[0] : -5)) / p) / k[4]) * k[4], d0);
    dr('rail', a, s, ty(d0, 1.1), gy(d0), mx(0, K ? flo((R - a) / s) : mn(flo((700 - a) / s), M.ceil((R - a) / s))), ty(d0, .55), col);
  };
  let q = f / 40, n;
  if (!K) {
    // Stands and crowd at 40 m, a pillar every 12 m; the crowd's pattern is
    // fixed on the stand (cells from its pillar j).
    const j = flo((x0 - 130 / q) / 12), a = sx(j * 12, 40), dx = 12 * q;
    n = mn(flo((700 - a) / dx), M.ceil((250 - a) / dx) + 1);
    dr('stands', a, dx, gy(40), -2.4 * q, n, 0, 0, ty(40, 13.5));
    dr('crowd', a, gy(40) - 1.2 * q, a + n * dx, gy(40) - 1.2 * q, -2.4 * q, -2.4 * q, j * 12 * KN[3][5], (j + n) * 12 * KN[3][5]);
    // The screen in front of the stands: dark, a grey flash, then its feed.
    if (vr) {
      dr('vis', vr[0] - 1, vr[1] - 1, vr[2], vr[3], mx(1, rnd(f / VS[1] * .4)), gy(VS[1]), von < 8 ? 0 : von < 11 ? 0x632c : 0x0866);
      feed(xs, (vr[2] - vr[0]) / 120);
    }
  }
  rail(DFR, 0xad55);
  if (!K) {
    // Turf stripes: lines of constant distance, so they meet at the vanishing
    // point; none whose near end is left of -470 (the VM's -480 limit: a
    // close-up of a far lane at LIGHT's 10 m spacing reached -499).
    q = f / DFR;
    const w = k[5], i0 = mx(flo((x0 - 125 / q) / w), M.ceil((x0 - 590 * DNR / f) / w)), xf = sx(i0 * w, DFR), xn = sx(i0 * w, DNR);
    n = mx(0, mn(M.ceil((250 - xf) / (w * q)), flo((700 - xn) / (w * f / DNR))));
    dr('turf', xn, xf, w * f / DNR, w * q, gy(DNR), gy(DFR), n, i0 & 1);
    for (let m = 200; m <= D; m += 200) {
      const p = sx(m, DFR), e = m === D;
      if (p > -40 && p < 280)
        dr('pole', p, gy(DFR), ty(DFR, e ? 4 : 2.6), (e ? .55 : .3) * q, e ? sx(m, DNR) : p, gy(e ? DNR : DFR), p, gy(DFR));
    }
    // The gate at 0 m: 9 stall posts, lane boundaries one MUL apart in depth.
    q = f * M.sqrt(Q) / DL[0];
    if (gate && M.abs(x0 * q) < 400) dr('gate', -x0 * q, h * q, (h - 2.6) * q, 1 / Q, hy);
  }
  // Slow motion: the legs' phase between sim steps, as at() places the
  // runners (ph is the step's end; disp of the next step shown).
  const sp = slow && scene === 'race' ? 1 - disp : 0;
  for (const l of zo) {
    if (K && ro.indexOf(l) >= FN[tier]) continue;
    const p = f / lz[l], S = p * U, X = o + (xs[l] - 12.5 * U - x0) * p, Y = gy(lz[l]), a = ph[l];
    if (l === close) {
      const g = (flo(a * 3 / PI) % 6 + 6) % 6;
      dr('g' + g, []);
      dr('silk', SILK[l], rnd(HS * bob(g)));
    } else if (K ? X - 2.5 * S >= K[0] && X + 12.5 * S <= R : X > -160 && X < 400) rin(l, X, S, Y, sp ? a - sp * rs.v[l] * DT / 6.5 * 2 * PI : a);
  }
  rail(DNR, 0xffff);
}
// A runner: hip x, back y, px per unit, ground y, four hooves.
const rin = (l, X, S, Y, a) => dr('r' + l, X, Y - 6 * S + .6 * S * sin(2 * a), S, Y, X + S * (.5 + 3 * sin(a)),
  X + S * (.5 + 3 * sin(a + .8)), X + S * (8 + 3 * sin(a + 3.3)), X + S * (8 + 3 * sin(a + 4.1)));
// The screen's feed on its face vr at scale z: a low camera 6 m behind the leader.
function feed(xs, z) {
  if (von > 10) course([85 * z, 3, vr[1] + 4.8 * z], mx.apply(null, xs) - 6, xs, -1, 0, vr);
}
