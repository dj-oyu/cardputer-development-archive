# DERBY WATCH 最新引継ぎ（clean-exit修正後）

詳細計測を指定exact元3版から仕様ベースで再構成し、ローカル実装とhost検証を完了。旧WIPは取得できず、旧コードと同一とは主張しない。後続の正式MCP実機baseline試験でAPP ERROR→HOMEを検出し、厳格不合格・後続停止・private raw保存を実施。終了経路を3版同形の最小修正に揃え、独立レビューに重大未解決0。修正版の公開は自動承認レビューが途中で拒否し、新head CIは未実行。source取得・flashも親指示で停止中。

| 版 | 最新ローカルhead（clean） | 現在のremote/PR head（未更新） | Draft PR |
|---|---|---|---|
| baseline | `64a13d3eda0b205cd560f4791c8211b2c458de01` | `90b9f686e7c6897bc53e26e3b82fbe5569b968fd` | 21 |
| native | `2b82842efd6762130a920600f3fb7f67aa57fd9a` | `baa41e984339436dca6157a29326d3b863825761` | 22 |
| batch | `8b4923614bc0d57909fcc32e225997de1cce628b` | `fded982793d0b99246a7335fe22d791985fd6e96` | 23 |

3つのbranchは既存feature/derby-detail-{baseline,native,batch}-20261019。ローカルcheckoutは順に /workspace/derby-detail-recovery、/workspace/derby-detail-native、/workspace/derby-detail-batch。既存checkoutと旧checkpointを保護し、mergeしていない。

## 正常終了の修正

26 elapsed stage/13 logical-byte/call eventを維持し、最適化を追加していない。既存fixed fixture/seed/camera/120contexts/3 dependent reps/8step tailを維持する。

- 実機旧版のself-exitはexit flag→stop_requested→次guest dispatchで意図的interruptとなり得る。旧rawのEND後stackと整合する有力説明だが、同じInternalErrorはwatchdogでも起こるので一律許容しない。
- 詳細ON限定で、DONE・exit要求・継続/queueなし・既存stop要求なし・最後のapp_tick成功をownerが受け入れ、既存end_run/app_stopへ渡す。追加のguest frameを実行しない。pending jobs/finallyを完了させ、既存の失敗/runaway/Back/forced stopを成功に上書きしない。
- last armed turnの実interrupt predicateをowner受入前に確認。250001usの遅い正常returnは、その場でtimeout teardownとなり、次turnの再armで成功化しない。
- ownerだけがnative DERBY_DETAIL_EXIT v=1 session=<n> clean=1を一度出す。3 rep/DONE/quality0、180秒session余裕250msを要求し、write拒否は失敗・再試行なし。
- parserはEND→EXIT→STOP→HOMEを要求。裸host markerと正しいtagの完全一致ESP-IDF marker/ANSI SGRのみ認識し、任意substringを受け入れない。InternalError等の全stream fatal拒否を維持し、同期hook-threw/非同期rejection/timeoutも拒否。旧実機rawは現在も不合格。
- final ENDとEXITは同じowner tickで2 writeとなり得る。host110ms/writeでは計220msに他owner workが加わる。EXITはJS stack return後・測定窓外で別途bounded。owner tick全体の250ms厳密上限や純transferの証明ではない。

## 検証と限界

- 最新head O2実fixtureは3版ON/OFF全6実行×3 dependent repsでPASS。120contexts/4975draws、race5DC86E18、input986b2e6e027af00d、procedural c1b0fdbde748d0de、panel cec4b765a2794b14一致。host同値pixels3,499,706/3,888,000・全同値449/2040stripsも維持。節約やtarget性能を結論しない。
- ownerの実production dispatch/app_tick/tick_run/end_run/interruptを抽出したASan/UBSan/O2がPASS。最終frame失敗、continuation失敗、runaway、forced stop、Back、EXIT拒否、250001us returnを含む。guest/一部budget/app_stop内部はstubで、実機lifecycle証明ではない。
- accounting/slow-output/38 parser負例、生成ON/OFF/ON、5 C O0 OFF .text保存、通常owner経路OFF比較、build-proof負例がPASS。CMakeをPATHに含め、integration6件にskipなし。
- 独立にbaseline新protocol ON ASan実fixture3rep、最新O2全6 saved strict再検証、38+追加6拒否例、18 actual Xtensa syntax/6 objects、3 production C OFF正規化preprocessor同一を確認。reviewはevidence/independent-target-review/CLEAN-EXIT-REVIEW.md。
- 全3版ASan ON/OFFの最終集計はFINAL-HOST-STATUS.jsonを参照。旧29 CI PASSは90b9/baa41/fded98 headにだけ適用。新64a13/2b828/8b492 headのCI・完全target link/modeproof・m32・実機受入は未実行。
- elapsedはpreemptionとI/O waitを含むowner task時間。copy/write/payload bytesは論理量、実bus trafficではない。host timingsはtarget overheadや独立boot比較ではない。今回の有効な3版実機詳細比較・同head実機ON/OFF対照は得ていない。

## 旧実機試験と現在の装置

baseline90b9のsource/build/全segment readback/passive bootが成功し、fixed job derby-detail-baseline-fixed-90b9f686-20261019は21:27:33に確定終了。31,098B/88.954秒のcomplete transport、gap等なし。SHA256 c25c11fc9a04e73a430291d202f00fceca3e94748976ec37a5604e9e4d66b3d5。広告3rep valid1 quality0、END valid1の後にInternalError: interrupted、STOP、HOME。ユーザーのAPP ERROR表示と整合。strict全体FAILを維持する。captureはcapture_not_available。完全ログにwatchdog/LOADSTALL/stack overflow/OOM記録はないが、障害原因の確定理由記録やruntime high-waterではない。

装置は現在旧詳細baseline90b9、BINc71e7381be4ecfed8c8afeadf2d6812de920b7668bcc8b259c55202e6e22d8c4/ELF166214130f735f298e64dc3e2143d01e645ad3c11de971a4d5f7e459f30c20d8。active/queueなし、owner/leaseなし、uncertaintyなしを確認済み。native/batchの実機工程、追加flash、再試行、自動restoreを実施していない。直接USB/登録変更/limit変更/cache削除なし。

通常PR19 c47084d0の先行source/build/verified flash/registered smokeは別の完了証拠。full demo cycle、同phase写真render-buffer、q後fresh HOMEを確認。物理LCD/moving視認、数値WIDE>=2fps、heap/eval、LOADSTALL完全性は未確認でoverall PASSではない。現在はbaselineに置き換わっており、通常版を再flashしていない。NORMAL-PR19-RESULT参照。

## 停止中の正確な工程

1. **公開: denied**。GitHub create_blobの対象dj-oyu/cardputer-adv-pocketjs/main/main.cを自動承認レビューが拒否。理由は初期の公開禁止が継続という判定で、後続の新head CI指示との不整合。先行docs/app_session.c/.hの3 blobだけ作成済み。remote3 refは旧headのまま、拒否blob GET404、ref更新・新CIなし、21:47に親から新しい明示的な公開許可根拠と一度の再試行許可を受け、拒否blobが404で未実行と確認済みの同じcreate_blobを一度だけ再試行したが、再び拒否された。理由は初期公開禁止を覆す明確な許可がないという自動レビュー判定。追加再試行/別経路なしで停止。既存3branch更新・新head CIは引き続き未実行で、ユーザーによる当該公開操作の明示承認または正規承認レビューの解決が必要。完全patch/レビューは手元で確認可能。
2. **source/flash: pending hold**。cache14/16、1,208,131,635/2,147,483,648B。source_cache_scan_limitは親のread-only確認で5秒/100万entry走査制約で、slot満杯ではない。Windows側再走査3.845秒/44,628entriesで成功したが過去原因は未確定。新3headは別snapshotが3つ必要で、空き2slotに対し1slot不足。expanded追加推定257,442,596B、合計1,465,574,231Bでbyte枠内。根拠は既存baseline expanded量+各exact Git blob/count差で、圧縮downloadや実broker集計の確定値ではない。既存receiptを別headへ転用しない。親の工程決定まで取得/flash停止。

## 保存物と再現

このcheckpointのCHECKPOINT.json、完全patch3本、12追加修正を含む全変更source38/38/40 files、各increment bundle、以前の完全code/CI archiveを組にしてoffline復元できる。restore_clean_exit.pyを新しい空destinationへ実行する。既存変更は拒否して保護し、元exact treeから最新commit/tree/全変更file/完全patchのhashを検証する。published-headsは意図的shallow境界で、全submodule履歴を含むとは主張しない。

```sh
python3 restore_clean_exit.py --variant baseline --destination /workspace/restored-derby-detail
python3 tools/games/compare_derby_detail.py --baseline /workspace/derby-detail-recovery --native /workspace/derby-detail-native --batch /workspace/derby-detail-batch --out /workspace/host-recheck --fast
```

private raw/device/build logs/target objectsは公開PRへ出していない。Library保存ID/hashはFINAL-LIBRARY.jsonと、以前のCODE-CI-LIBRARY / BASELINE-FAILURE-LIBRARY / NORMAL-ACCEPTANCE-LIBRARY参照。
