#include "board.h"
#include "shell.h"
#include "overlay.h"
#include "motion.h"
#include "sound.h"
#include "keymap.h"
#include "editor.h"
#include "codeedit.h"
#include "wifi_ui.h"
#include "net_autosync.h"
#include "net_service.h"
#include "tutorial.h"
#include "jpfont.h"
#include "skk_session.h"
#include "app_session.h"
#include "pocket_kasane.h"
#include "pocket/derby_fixed_workload.h"
#include "vm_wake.h"
#include "pocket_workspace.h"
#include "sd_picker.h"
#include "file_picker.h"
#include "overlay.h"
#include "app_registry.h"
#include "pet_hub.h"
#include "pocket_capture.h"
#include "pocket_av.h"
#include "pocket_video_sd_stream.h"
#ifdef KASANE_P0_PROBE
#include "pocket/app_music_view.h"
#include "pocket_mutex_arena.h"
#include "ui/kasane/ksn_schema_session.h"
#endif
#include "ui/kasane/ksn_p0_probe.h"
#ifdef KASANE_TEXT_PIE_DEVICE_PROBE
#include "ui/kasane/ksn_render.h"
#endif
#include "pocket_bridge.h"
#include "pocket_text.h"
#include "pocket_input.h"
#include "system/sys_device.h"
#include "scene_mem.h"
#include "vmprobe.h"
#include "sdkconfig.h"
#include "driver/usb_serial_jtag.h"
#include "usb_console.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "esp_log.h"
#include "esp_partition.h"
#include "esp_timer.h"
#include "nvs_flash.h"
#include <stdatomic.h>
#include <string.h>
#include "hal/fpu_latency.h"
static atomic_bool fpu_probe_requested;
#ifdef KASANE_PROC_DEVICE_PROBE
static atomic_bool proc_probe_requested;
void ksn_proc_device_probe_run(void);
#endif
#ifdef KASANE_PROC_LIMITS_PROBE
#include "ksn_proc_limits_device_probe.h"
static atomic_bool limits_probe_requested;
#endif
#ifdef KASANE_MEGADEMO_DEVICE_PROBE
static atomic_bool megademo_probe_requested;
void ksn_megademo_device_probe_run(void);
#endif
#ifdef KASANE_P5_NOTICE_PROBE
static atomic_int p5_notice_probe_requested;
#define P5_NOTICE_OWNER (UINT32_MAX-1u)
#endif
#ifdef CONFIG_POCKET_VM_RELOC
// Sticky across app starts: one arming can be followed by several runs, which
// is what a lifecycle sweep needs. Set-only, not a toggle -- a script that
// sends '&' twice to be sure must not end up disarming it.
static atomic_bool reloc_requested;
#endif
#ifdef CONFIG_KSN_DEVICE_PROBE
#include "esp_heap_caps.h"
#include "ui/kasane/ksn_runtime.h"
static atomic_bool ksn_probe_requested;
static atomic_int system_probe_requested;
void ksn_device_probe_run(void);
static void system_probe(int command){
    const uint32_t owner=UINT32_MAX;
    sys_notify *notices=sys_device_notifications();sys_timer *timers=sys_device_timers();
    if(command=='N'||command=='Z'){
        sys_timer_release_owner(timers,owner);sys_notify_release_owner(notices,owner);
    }
    if(command=='N'){
        for(unsigned i=0;i<SYS_NOTICE_SLOTS;i++)if(notices->records[i].phase){
            printf("SYS_PROBE_BUSY\n");return;
        }
        uint64_t now=(uint64_t)esp_timer_get_time();uint32_t id;
        sys_notice_result result=sys_notify_post(notices,owner,1,"SYSTEM NOTICE",0,&id);
        sys_notify_step(notices,now);
        for(unsigned i=0;i<8&&result==NOTICE_OK;i++)
            result=sys_notify_post(notices,owner,i+2,"QUEUED NOTICE",0,&id);
        if(result==NOTICE_OK)result=sys_timer_set(timers,owner,"probe","RETRY TIMER",now+100000);
        if(result!=NOTICE_OK){printf("SYS_PROBE_ERROR %u\n",(unsigned)result);return;}
    }
    unsigned queued=0,snoozed=0,count=0,blocked=0;sys_notice active;
    bool have=sys_notify_active(notices,&active);
    for(unsigned i=0;i<SYS_NOTICE_SLOTS;i++){
        queued+=notices->records[i].phase==NOTICE_QUEUED;
        snoozed+=notices->records[i].phase==NOTICE_SNOOZED;
    }
    for(unsigned i=0;i<SYS_TIMER_SLOTS;i++){
        count+=timers->records[i].due_us!=0;blocked+=timers->records[i].blocked;
    }
    printf("SYS_PROBE active=%u queued=%u snoozed=%u timers=%u blocked=%u id=%lu free=%lu largest=%lu system=%u composited=%u\n",
        have,queued,snoozed,count,blocked,(unsigned long)(have?active.id:0),
        (unsigned long)heap_caps_get_free_size(MALLOC_CAP_8BIT),
        (unsigned long)heap_caps_get_largest_free_block(MALLOC_CAP_8BIT),
        ksn_runtime_stats(KSN_SYSTEM).displayed.commands,pocket_kasane_notice_composited());
}
#endif

static QueueHandle_t keys;
static atomic_bool stop;
static atomic_bool capture;
static atomic_int diagnostic;
#ifdef KASANE_MEGADEMO_TRACE
// 'S': capture the next ticks' presents WITHOUT the full redraw 's' forces,
// so the PIX rows are exactly the damage the ordinary path sent.
static atomic_int raw_capture;
#endif
#ifdef CONFIG_POCKET_VM_SELFTEST
extern void vmtest_lifecycle_device(void);
#endif
// Whether the screen on show consumes typed bytes. Only the USB reading needs
// it: the same byte is a menu direction on the home screen and a character
// everywhere else.
static atomic_bool text_screen;
#ifdef POCKET_HEAPPROBE
// The argument of the last USB 'Q' (usb_stroke), read when it is dispatched.
static char heapprobe_arg[24];
#endif
static bool pet_repaint;
// How long the last full frame took, handed to overlay_tick() so that an
// over-budget turn can be judged as a share of the frame rather than against a
// stopwatch that counts other tasks' work. See overlay_core.h.
static uint32_t last_frame_us;

// USB drives the home screen with single letters, but an editor needs the
// bytes themselves so a host script can type at it. 0x1b closes either way.
static bool usb_stroke(char c, keystroke_t *k) {
#if defined(KASANE_D6_VIDEO_OVERLAY_PROBE) && defined(KASANE_P5_NOTICE_PROBE)
    /* Dedicated D6 aliases precede other diagnostic and guest USB handlers. */
    if(c=='U'||c=='I') {
        atomic_store(&p5_notice_probe_requested,c=='U'?'J':'C');
        return false;
    }
#endif
#ifdef KASANE_TEXT_PIE_DEVICE_PROBE
    /* Set, do not toggle: a host can safely retry after a lost USB/log byte.
     * This diagnostic path runs before guest input forwarding. */
    if(c=='K'||c=='k') {
        g_ksn_text_pie=c=='K';
        ESP_LOGI("KSN_PIE","TEXT %d",g_ksn_text_pie);
        return false;
    }
    if(c=='?') { atomic_store(&diagnostic,c); return false; }
#endif
    if(pocket_bridge_usb((uint8_t)c))return false;
    if(pet_hub_usb((uint8_t)c))return false;
#ifdef POCKET_KEYTEST
    // US-framed key presses and releases (keymap.c), ahead of the text and
    // menu readings so a frame means the same thing on every screen.
    if(keymap_inject_usb((uint8_t)c))return false;
    // The key test app (apps/keytest), started like '1'..'6'. Not a menu row:
    // tools/test_settings.py and capture_home.py count presses down the menu.
    if(c=='r'&&!atomic_load(&text_screen)) { atomic_store(&diagnostic,c); return false; }
#endif
#ifdef POCKET_HEAPPROBE
    // 'Q<index>[,<limit>]\n' starts an apps/heapprobe variant (app_session.c).
    // The bytes after 'Q' are swallowed up to the newline, because digits are
    // diagnostics of their own below. Home screen only, like 'r'.
    {
        static int n=-1;
        if(n>=0) {
            if(c=='\n'||c=='\r') {
                heapprobe_arg[n]=0; n=-1;
                atomic_store(&diagnostic,'Q');
            } else if(n<(int)sizeof heapprobe_arg-1) heapprobe_arg[n++]=c;
            return false;
        }
        if(c=='Q'&&!atomic_load(&text_screen)) { n=0; return false; }
    }
#endif
#ifdef KASANE_PROC_DEVICE_PROBE
    if(c=='|') { atomic_store(&proc_probe_requested,true); return false; }
    if(c=='J') { atomic_store(&diagnostic,c); return false; }
    if(c=='(') { atomic_store(&diagnostic,c); return false; }
#endif
#ifdef KASANE_MEGADEMO_DEVICE_PROBE
    if(c=='`') { atomic_store(&megademo_probe_requested,true); return false; }
#endif
#ifdef KASANE_MEGADEMO_TRACE
    // Guest heap cap for the next app start (app_session.c MDT_LIMITS). Read
    // only at start, so pressing it while an app runs changes nothing live.
    if(c=='~') { extern void app_trace_next_heap_limit(void); app_trace_next_heap_limit(); return false; }
    if(c=='S') { atomic_store(&raw_capture,6); return false; }
#endif
#ifdef KASANE_PROC_LIMITS_PROBE
    /* Ahead of P2's '{'/'}' navigation aliases; the two probes are not built
     * together. '{' measures natively at HOME, '}' starts the JS lifecycle app. */
    if(c=='{') { atomic_store(&limits_probe_requested,true); return false; }
    if(c=='}') { atomic_store(&diagnostic,c); return false; }
#endif
    memset(k,0,sizeof(*k));
    if(atomic_load(&text_screen)) {
        // C-s is the editor's save, so the host capture moves to C-p.
        if(c==0x10) { atomic_store(&capture,true); return false; }
        if(c==27) { k->text[0]='\0';memcpy(k->text+1,"esc",3);k->len=4;k->nav=KEY_BACK;return true; }
        if(c=='\r'||c=='\n') { k->text[0]='\n';k->len=1;k->nav=KEY_ENTER;return true; }
        if(c=='\b'||c==0x7f) { k->text[0]='\b';k->len=1;return true; }
        if(c==0x0b) { k->toggle_ime=true;return true; }   // C-k stands in for C-j
        // The arrows and Del are Fn combinations on the keyboard and have no
        // byte of their own, so a host driving this over USB gets these.
        if(c==0x02) { k->text[0]='\0';memcpy(k->text+1,"left",4);k->len=5;k->nav=KEY_LEFT;return true; }
        if(c==0x06) { k->text[0]='\0';memcpy(k->text+1,"right",5);k->len=6;k->nav=KEY_RIGHT;return true; }
        if(c==0x04) { k->text[0]='\0';memcpy(k->text+1,"del",3);k->len=4;return true; }
        k->text[0]=c;k->len=1;return true;
    }
    if(c=='s') { atomic_store(&capture,true); return false; }
#ifdef KASANE_P2_REPAIR_PROBE
    if(c=='%') { app_p2_request_repair_probe(); return false; }
    if(c=='@') { app_p2_request_patch_repair_probe(); return false; }
    if(c=='}') { k->nav=KEY_RIGHT; return true; }
    if(c=='{') { k->nav=KEY_LEFT; return true; }
    if(c=='!') { k->nav=KEY_UP; return true; }
    if(c==']') { k->nav=KEY_DOWN; return true; }
#endif
#ifdef KASANE_P5_OVERLAY_REPAIR_PROBE
    if(c=='%'||c=='^') { shell_overlay_repair_request(c=='^'); return false; }
#endif
#ifdef KASANE_P5_LOWHEAP_PROBE
    if(c=='H') { shell_lowheap_toggle_request(); return false; }
#endif
#ifdef KASANE_P5_NOTICE_PROBE
    if(c=='J'||c=='C') { atomic_store(&p5_notice_probe_requested,c); return false; }
#endif
#if defined(KASANE_P1_OUTPUT_OVERLAY_PROBE) || defined(KASANE_D6_VIDEO_OVERLAY_PROBE) || \
    defined(KASANE_D2_OVERLAY_PROC_PROBE)
    /* P0's USB 'u' starts a foreground diagnostic and 'b' starts a P0 app.
     * These aliases keep overlay navigation available in combined probes. */
    if(c=='&') { k->nav=KEY_UP; return true; }
    if(c=='>') { k->nav=KEY_RIGHT; return true; }
#endif
    // Not behind CONFIG_KSN_DEVICE_PROBE: this one measures the CPU rather than
    // the display, it is about a kilobyte, and the build that needs it is
    // whichever build is being optimised -- which is the shipping one.
    if(c=='F') { atomic_store(&fpu_probe_requested,true); return false; }
#ifdef CONFIG_KSN_DEVICE_PROBE
    if(c=='~') { atomic_store(&ksn_probe_requested,true); return false; }
    if(c=='N'||c=='O'||c=='Z'){atomic_store(&system_probe_requested,c);return false;}
#endif
    if(c=='c') { motion_recenter(); return false; }
    // '8' is not an app: it checks the baked sound tables against this chip's
    // own libm (sound_check_tables), and is handled where the others start. It
    // is not folded into the range because '7' is a separate Kasane wall-source
    // diagnostic only in P0 builds; a normal build still leaves it unused.
    // '9' is the same kind of thing for the microphone: it sweeps the codec's
    // input paths and its ADC volume and prints what each produces, because the
    // board answered the first register table with silence and guessing again
    // is not a method. Like every letter in this function it arrives over USB;
    // the Cardputer's own '9' key goes to the shell and does nothing here.
    if((c>='1'&&c<='6')||c=='8'||c=='9') { atomic_store(&diagnostic,c); return false; }
#ifdef KASANE_P0_PROBE
    if(c==';') { (void)pocket_mutex_arena_device_race_probe(); return false; }
    if(c==':') { (void)pocket_mutex_arena_device_oom_probe(); return false; }
    if(c=='g') {
        bool fullscan=ksn_schema_session_toggle_fullscan_probe();
        ESP_LOGI("KSN_P2","FULLSCAN %u",(unsigned)fullscan);
        return false;
    }
    if(c=='7'||c=='0'||c=='v'||c=='V'||c=='w'||c=='y'||c=='z'||c=='j'||c=='h'||c=='i'||c=='l'||c=='T'||c=='t'||c=='R'||c=='#'
#ifndef KASANE_P5_FAIRNESS_PROBE
       ||c=='b'||c=='u'
#endif
#ifdef KASANE_P0_COPY_PROBE
       ||c=='x'
#endif
      ) { atomic_store(&diagnostic,c); return false; }
#endif
#ifdef CONFIG_POCKET_VM_SELFTEST
    if(c=='J'||c=='L'||c=='M'||c=='Y'||c=='Z'||c=='S') { atomic_store(&diagnostic,c); return false; }
    if(c=='['||c=='\\'||c==']') { atomic_store(&diagnostic,c); return false; }
#endif
#ifdef CONFIG_POCKET_VM_PROBE
    // VM probe workload triggers (docs/vm/quickjs-freertos-vm-spec.md sec.5),
    // USB-only and gated by CONFIG_POCKET_VM_PROBE so a normal build's key
    // table is byte-for-byte unchanged. 'A'..'F' select one of apps/vmprobe/'s
    // six workloads the same way '1'..'6' select the lifecycle diagnostics
    // above -- tools/vm_l0_capture.py drives these.
    if(c>='A'&&c<='F') { atomic_store(&diagnostic,c); return false; }
    if(c=='X') { atomic_store(&diagnostic,c); return false; }
    // '<' and '>' are POCKET PET and PET COMPANION, the two shipped apps whose
    // frames are the heaviest measured (docs/vm/vm-L2-results.md sec.8.1) and
    // which the menu is the only other way to start. Through here they take the
    // contention conditions, which is what sec.8.7 needs them for. Note they
    // write their own saved state as usual.
    if(c=='<'||c=='>') { atomic_store(&diagnostic,c); return false; }
    if(c>='G'&&c<='K') { vmprobe_segment_set((unsigned)(c-'G')); return false; }
    if(c=='O') { vmprobe_segment_set(5); return false; }
    // The contention condition the NEXT workload runs under (sec.5's "fix the
    // UI / audio / communication contention"): 'P' + mask, so 'P' is base and
    // 'W' is all three. Sticky and separate from the workload letter, because
    // one capture runs all six workloads under one condition. Taken from
    // letters nothing else in this function reads: 'A'..'F' are the workloads,
    // '1'..'9' the diagnostics, and the home screen's own keys are lower case.
    if(c>='P'&&c<=(char)('P'+VMPROBE_COND_ALL)) {
        vmprobe_condition_set((unsigned)(c-'P')); return false;
    }
#endif
    // Not behind CONFIG_KSN_DEVICE_PROBE: this one measures the CPU rather than
    // the display, it is about a kilobyte, and the build that needs it is
    // whichever build is being optimised -- which is the shipping one. PLACED
    // AFTER the probe block for the same reason 'K' is: 'F' is also the probe's
    // sixth workload (async_generator), and taking it here made that workload
    // unreachable in a probe build -- tools/vm_l0_capture.py asked for it and
    // got a pipeline measurement instead, silently, from whenever this key was
    // added until 2026-09-23.
    // L3a (docs/vm/vm-L3-design.md sec.7): arm the segment move for whatever
    // app is started NEXT. Sticky and separate from the app letter, the same
    // shape as the probe's 'P' contention mask, because what it modifies is
    // the run rather than which run it is.
    //
    // Taken on the HOME SCREEN only, which is why it arms the next app instead
    // of the running one: a byte arriving while an app is up is offered to
    // pocket_bridge_usb() and pet_hub_usb() first, and an app that claimed '&'
    // would take this silently. Placed after the probe block for the reason
    // the two keys above it record -- 'F' was taken here while it was also the
    // probe's sixth workload, and that workload became unreachable without
    // anyone noticing for as long as it took to find.
#ifdef CONFIG_POCKET_VM_RELOC
    if(c=='&') { atomic_store(&reloc_requested,true); return false; }
    // '%' is the deep-parking workload the move needs in order to be measured
    // on anything but a one-frame chain (app_session.c). A diagnostic letter
    // like '1'-'6', not an app.
    if(c=='%') { atomic_store(&diagnostic,c); return false; }
#endif
#ifdef CONFIG_POCKET_VM_OOMPROBE
    // G12's OOM workloads (app_session.c). Shifted digits, which nothing else
    // on the home screen reads.
    if(c=='!'||c=='@'||c=='#'||c=='$'||c=='^') { atomic_store(&diagnostic,c); return false; }
#endif
    if(c=='F') { atomic_store(&fpu_probe_requested,true); return false; }
    // The Kasane demo trigger ('K', app_session.c's kasane_demo_start). PLACED
    // AFTER the probe block on purpose: 'G'..'K' is the probe's segment range, so
    // with CONFIG_POCKET_VM_PROBE on a 'K' still selects probe segment 4, and
    // with it off (every shipping build, and the KSN ones) 'K' reaches the demo.
    if(c=='K') { atomic_store(&diagnostic,c); return false; }
    // The volume pair and '?', as TEXT rather than as nav, because that is what
    // the Cardputer's own keys produce and what volume_key() and an overlay
    // read. Without them a host script could reach every other key on the home
    // screen and not these -- the two that are the shell's everywhere, and the
    // one an overlay uses for its own help.
    if(c=='-'||c=='='||c=='?') { k->text[0]=c;k->len=1;return true; }
    if(c=='\r'||c=='\n'||c=='e')k->nav=KEY_ENTER;
    else if(c=='q'||c==27)k->nav=KEY_BACK;
    else if(c=='b')k->nav=KEY_RIGHT;
    else if(c=='a')k->nav=KEY_LEFT;
    else if(c=='u')k->nav=KEY_UP;
    else if(c=='d')k->nav=KEY_DOWN;
    else return false;
    return true;
}

static void input_task(void *arg) {
    (void)arg;
    while(1) {
        keystroke_t k;
        bool have=keymap_poll(&k);
        motion_poll();
        char c;
        if(!have && usb_serial_jtag_read_bytes(&c,1,0)>0) have=usb_stroke(c,&k);
        if(have) {
#ifdef KASANE_P0_PROBE
            k.queued_at_us=(uint32_t)esp_timer_get_time();
#endif
            // Only the force stop jumps the queue, and it does so because the
            // drawing task may be inside a guest call that has to be
            // interrupted rather than waited out. Everything else is ordered.
            if(k.force_stop) { atomic_store(&stop,true); app_request_stop(); }
            else xQueueSend(keys,&k,0);
        }
        vTaskDelay(pdMS_TO_TICKS(5));
    }
}

// ---------------------------------------------------------------------------
// Screens.
//
// One task draws, and only one screen is up at a time. They were four nested
// branches in the loop below, each repeating the capture handling, the repaint
// test and the frame pacing; the two most recent bugs were both a branch that
// copied three of those four correctly. The table makes each screen say what
// it is instead, and the loop does the repeated parts once.
// ---------------------------------------------------------------------------

typedef enum {
    SCREEN_HOME = 0,
    SCREEN_PRACTICE,
    SCREEN_CODE,
    SCREEN_TUTORIAL,
    SCREEN_WIFI,
    SCREEN_COUNT
} screen_id_t;

typedef struct {
    const char *tag;                 // log tag
    const char *ready;               // logged on arrival
    void (*open)(void);
    // The other end of open(): called on the screen being left, so a screen
    // that took memory to be on show can give it back. Without it every screen
    // held its buffers from boot to power-off whether it was up or not.
    void (*close)(void);
    bool (*key)(const keystroke_t *k);   // false: leave for the home screen
    bool (*dirty)(void);
    void (*draw)(void);
    // Set when the screen can run JavaScript. Returns true once it wants to.
    bool (*wants_run)(const char **source, size_t *len);
    // What has to be evaluated before that source, in the same realm, or NULL.
    // Only a source the screen asked to run carries it: an app started from the
    // home screen or by pocket.workspace.run() is a whole program of its own,
    // and those call sites pass NULL rather than reading this.
    const char *(*prelude)(size_t *len);
    // How the run ended, for the screen that asked for it.
    void (*ended)(esp_err_t started, const char *error);
    // The buffers a screen lends the parser. run_release() is called once the
    // guest has finished reading the source -- not before: app_start_source()
    // parses straight out of the caller's bytes -- and run_restore() before
    // ended(), so whatever ended() reads is back. A screen that holds 8 KB of
    // editable source is dead for the whole of a run, which is the one stretch
    // in which the guest, the font atlas and the radio all want that block.
    void (*run_release)(void);
    void (*run_restore)(void);
    // For a screen that sends only the strips it changed. Two things make that
    // record wrong from outside: board_capture prints the strips that are
    // sent, so a partial frame is a partial screenshot, and pet_hub_overlay
    // rides on board_present, so the pet only moves on the strips that go out.
    // Both are announced here rather than guessed at by the screen.
    void (*repaint_all)(void);
    uint8_t frame_ms;
    bool takes_text;
} screen_ops_t;

static screen_id_t screen=SCREEN_HOME;
static bool        running;          // a guest owns the display
static screen_id_t owner;            // which screen asked for it
static esp_err_t   run_started;
static const char *home_error;
static unsigned    home_phase;

// The home screen predates this table and keeps its own shapes, so it is
// adapted rather than changed.
static bool home_dirty(void) { return true; }   // the background animates
static void home_draw(void)  { shell_draw(home_error,home_phase++); }

static void enter(screen_id_t next);
static void begin_run(const char *app_id, const char *prelude, size_t prelude_len,
                      const char *source, size_t len);

// The calibration program is embedded rather than kept in a source slot: it is
// the thing you reach for when the sensor is wrong, and a slot someone has
// edited is exactly what you cannot trust at that moment.
extern const char imucal_start[] asm("_binary_imucal_js_start");
extern const char imucal_end[]   asm("_binary_imucal_js_end");
extern const char pet_start[] asm("_binary_pet_js_start");
extern const char pet_end[] asm("_binary_pet_js_end");
extern const char companion_start[] asm("_binary_companion_js_start");
extern const char companion_end[] asm("_binary_companion_js_end");
// Heap churn + drawing load (apps/stress/README.md), a test app kept on the menu.
extern const char stress_start[] asm("_binary_stress_js_start");
extern const char stress_end[] asm("_binary_stress_js_end");
extern const char proc_megademo_start[] asm("_binary_proc_megademo_js_start");
extern const char proc_megademo_end[] asm("_binary_proc_megademo_js_end");
extern const char grid_lab_start[] asm("_binary_grid_lab_js_start");
extern const char grid_lab_end[] asm("_binary_grid_lab_js_end");
extern const char video_lab_start[] asm("_binary_video_lab_js_start");
extern const char video_lab_end[] asm("_binary_video_lab_js_end");
extern const char lcd_catch_start[] asm("_binary_lcd_catch_js_start");
extern const char lcd_catch_end[] asm("_binary_lcd_catch_js_end");
extern const char derby_watch_start[] asm("_binary_derby_watch_js_start");
extern const char derby_watch_end[] asm("_binary_derby_watch_js_end");
extern const char big_wave_start[] asm("_binary_big_wave_js_start");
extern const char big_wave_end[] asm("_binary_big_wave_js_end");
#ifdef KASANE_D4_PIXEL_APP_PROBE
extern const char pixel_lab_probe_start[] asm("_binary_pixel_lab_probe_js_start");
extern const char pixel_lab_probe_end[] asm("_binary_pixel_lab_probe_js_end");
#endif
#ifdef KASANE_D2_MULTI_SURFACE_PROBE
extern const char proc_multi_surface_probe_start[] asm("_binary_proc_multi_surface_probe_js_start");
extern const char proc_multi_surface_probe_end[] asm("_binary_proc_multi_surface_probe_js_end");
#endif
#ifdef KASANE_D5_SD_STREAM_PROBE
extern const char video_stream_lab_start[] asm("_binary_video_stream_lab_js_start");
extern const char video_stream_lab_end[] asm("_binary_video_stream_lab_js_end");
#endif
#ifdef KASANE_D6_SD_AV_STREAM_PROBE
extern const char video_sd_av_stage_start[] asm("_binary_video_sd_av_stage_js_start");
extern const char video_sd_av_stage_end[] asm("_binary_video_sd_av_stage_js_end");
extern const char video_sd_av_cleanup_start[] asm("_binary_video_sd_av_cleanup_js_start");
extern const char video_sd_av_cleanup_end[] asm("_binary_video_sd_av_cleanup_js_end");
#endif

// shell_key() cannot say "hand the display to another screen": its bool already
// means "launch the app shell_app() names". The request is left behind instead,
// and every shell_key() call site has to collect it — one that does not leaves
// the request standing until the next press, which then opens the screen on the
// wrong key.
static void take_pending_screen(void) {
    switch(shell_pending_screen()) {
        case SHELL_SCREEN_WIFI: enter(SCREEN_WIFI); break;
        case SHELL_SCREEN_NONE: break;
    }
}

// The volume keys, and they belong to the SHELL rather than to whatever is on
// the home screen. Pressed while the player is up they change the volume, which
// is what makes volume operable from the player -- but the player is not what
// changes it, and no app can. An app that could turn itself up is an app that
// could turn itself up while nobody is watching, and this keeps the practical
// half of that without the dangerous half.
//
// They cost two keys out of the residue 3.1 hands to an overlay, which is a
// real price and is why it is two and not a row of them. `-` and `=` are the
// unshifted pair on the top row; the shifted spellings are accepted because a
// person holding shift meant the same thing.
//
// Taken on the home screen only. A foreground app receives every key and having
// two of them silently disappear is a worse surprise than reaching for Settings.
static bool volume_key(const keystroke_t *k) {
    if(!k||k->len!=1) return false;
    char c=k->text[0];
    int step=(c=='-'||c=='_')?-1:((c=='='||c=='+')?1:0);
    if(!step) return false;
    unsigned now=sound_volume();
    if(step<0&&now) sound_set_volume(now-1);
    else if(step>0&&now+1<SOUND_VOLUME_STEPS) sound_set_volume(now+1);
    // Shown and stored even when the step was clamped: pressing down at the
    // bottom is a person asking where they are, and answering with nothing is
    // indistinguishable from a key that did not arrive.
    shell_volume_touched();
    shell_settings_save();
    return true;
}

// Whether a host screen is up over the home screen. 3.1: modals beat the
// overlay, and that has to include the RESERVED KEY -- Escape on a folder
// picker means "I decline", and spending it on standing the overlay down would
// leave the picker up with its promise unsettled and no way to answer it.
static bool home_modal(void) {
    return pocket_workspace_modal()||sd_picker_modal()||file_picker_modal();
}

static bool home_key(const keystroke_t *k) {
    board_key_t nav=k->nav;
    if(nav==KEY_NONE) return true;
    // An app that failed leaves its reason on the home screen. Either key
    // dismisses it, and the screen says so, which is what a host driving this
    // over USB waits for.
    if(home_error) {
        if(nav==KEY_ENTER||nav==KEY_BACK) {
            home_error=NULL;
            ESP_LOGI("shell","HOME_READY");
        }
        return true;
    }
    // Back at the root of the home screen stops the background music (S5 in
    // docs/vm/app-suspend-design.md): with no overlay up there is no other
    // control for it. Back with a value list open closes the list.
    if(nav==KEY_BACK && !shell_choices_open() && pocket_av_background_active())
        pocket_av_background_stop("back");
    bool launch=shell_key(nav);
    take_pending_screen();
    if(!launch) return true;
    switch(shell_app()) {
        case 1: enter(SCREEN_PRACTICE); break;
        case 2: enter(SCREEN_CODE); break;
        case 3: enter(SCREEN_TUTORIAL); break;
        case 4: begin_run("local.imucal",NULL,0,imucal_start,(size_t)(imucal_end-imucal_start-1)); break;
        case 5: begin_run("local.pet",NULL,0,pet_start,(size_t)(pet_end-pet_start-1)); break;
        case 6: begin_run("local.companion",NULL,0,companion_start,(size_t)(companion_end-companion_start-1)); break;
        case 7: begin_run("local.stress",NULL,0,stress_start,(size_t)(stress_end-stress_start-1)); break;
        case 8: begin_run("local.megademo",NULL,0,proc_megademo_start,
                          (size_t)(proc_megademo_end-proc_megademo_start-1)); break;
        case 9:
#ifdef KASANE_D6_SD_AV_STREAM_PROBE
            begin_run("local.gridlab",NULL,0,video_sd_av_cleanup_start,
                      (size_t)(video_sd_av_cleanup_end-video_sd_av_cleanup_start-1));
#else
            begin_run("local.gridlab",NULL,0,grid_lab_start,
                      (size_t)(grid_lab_end-grid_lab_start-1));
#endif
            break;
        case 10:
#ifdef KASANE_D4_PIXEL_APP_PROBE
            begin_run("local.videolab",NULL,0,pixel_lab_probe_start,
                      (size_t)(pixel_lab_probe_end-pixel_lab_probe_start-1));
#elif defined(KASANE_D2_MULTI_SURFACE_PROBE)
            begin_run("local.videolab",NULL,0,proc_multi_surface_probe_start,
                      (size_t)(proc_multi_surface_probe_end-proc_multi_surface_probe_start-1));
#elif defined(KASANE_D6_SD_AV_STREAM_PROBE)
            begin_run("local.videolab",NULL,0,video_sd_av_stage_start,
                      (size_t)(video_sd_av_stage_end-video_sd_av_stage_start-1));
#elif defined(KASANE_D5_SD_STREAM_PROBE)
            begin_run("local.videolab",NULL,0,video_stream_lab_start,
                      (size_t)(video_stream_lab_end-video_stream_lab_start-1));
#else
            begin_run("local.videolab",NULL,0,video_lab_start,
                      (size_t)(video_lab_end-video_lab_start-1));
#endif
            break;
        case 11: begin_run("local.lcdcatch",NULL,0,lcd_catch_start,
                           (size_t)(lcd_catch_end-lcd_catch_start-1)); break;
        case 12: begin_run("local.derby",NULL,0,derby_watch_start,
                           (size_t)(derby_watch_end-derby_watch_start-1)); break;
        case 13: begin_run("local.bigwave",NULL,0,big_wave_start,
                           (size_t)(big_wave_end-big_wave_start-1)); break;
        default: begin_run("local.hello",NULL,0,NULL,0);          // the built-in app
    }
    return true;
}

static bool code_wants_run(const char **source, size_t *len) {
    if(code_state()!=CODE_RUNNING) return false;
    *source=code_source(len);
    return true;
}
static void code_ended(esp_err_t started, const char *error) {
    // A source with no frame drew what it drew and has nothing to run, so its
    // output is the result rather than a failure.
    if(started==ESP_ERR_NOT_FOUND)  code_returned("EVALUATED (NO frame)");
    else if(started!=ESP_OK)        code_returned(error[0]?error:"START FAILED");
    else                            code_returned(error[0]?error:NULL);
}

static bool tutorial_wants_run(const char **source, size_t *len) {
    if(tutorial_state()!=TUTORIAL_WRITING || code_state()!=CODE_RUNNING) return false;
    *source=tutorial_source(len);
    return true;
}

static const screen_ops_t SCREENS[SCREEN_COUNT]={
    [SCREEN_HOME]={
        .tag="shell", .ready="HOME_READY",
        .key=home_key, .dirty=home_dirty, .draw=home_draw,
        .frame_ms=33,
    },
    [SCREEN_PRACTICE]={
        .tag="editor", .ready="EDITOR_READY", .open=editor_open,
        .key=editor_key, .dirty=editor_dirty, .draw=editor_draw,
        .frame_ms=16, .takes_text=true,
    },
    [SCREEN_CODE]={
        .tag="code", .ready="CODE_READY", .open=code_open, .close=code_close,
        .key=code_key, .dirty=code_dirty, .draw=code_draw,
        .wants_run=code_wants_run, .ended=code_ended,
        .run_release=code_run_release, .run_restore=code_run_restore,
        .repaint_all=code_repaint_all,
        .frame_ms=16, .takes_text=true,
    },
    [SCREEN_TUTORIAL]={
        .tag="tutorial", .ready="TUTORIAL_READY", .open=tutorial_open,
        .close=tutorial_close,
        .key=tutorial_key, .dirty=tutorial_dirty, .draw=tutorial_draw,
        .wants_run=tutorial_wants_run, .prelude=tutorial_prelude,
        .ended=tutorial_ran,
        .run_release=tutorial_run_release, .run_restore=tutorial_run_restore,
        .frame_ms=16, .takes_text=true,
    },
    // Nothing on this screen animates; it repaints when a key or the sync task
    // moves it. 33 ms is the pace of waiting for a radio, not of typing.
    [SCREEN_WIFI]={
        .tag="wifi_ui", .ready="WIFI_READY", .open=wifi_ui_open,
        .key=wifi_ui_key, .dirty=wifi_ui_dirty, .draw=wifi_ui_draw,
        .frame_ms=33, .takes_text=true,
    },
};

static void enter(screen_id_t next) {
    // docs/api/common-api.md 3.1 moves the guest's lifetime from "entering and
    // leaving the app screen" to "the home screen owning the frame", and this
    // is the leaving half: the home screen is giving the display away, so the
    // session it owns ends here. It has to be before the screen changes,
    // because app_stop() tears down surfaces that the arriving screen may
    // immediately build again.
    if(next!=SCREEN_HOME) {
        overlay_release();
        shell_release_background_frames();
        // Every other screen either starts a guest (the editors) or wants the
        // radio itself (Wi-Fi: its scan starts on arrival and would be refused
        // as busy). A home-screen clock sync gives way to both.
        net_autosync_yield("screen");
    }
    if(SCREENS[screen].close) SCREENS[screen].close();
    screen=next;
    atomic_store(&text_screen,SCREENS[next].takes_text);
    if(SCREENS[next].open) SCREENS[next].open();
    ESP_LOGI(SCREENS[next].tag,"%s",SCREENS[next].ready);
}

static void go_home(void) {
    sound_play(2);
    enter(SCREEN_HOME);
}

static void take_pending_run(void);

static void end_run(esp_err_t tick_err) {
    app_stop();
    running=false;
    xQueueReset(keys);
    const screen_ops_t *o=&SCREENS[owner];
    // Before ended(): the tutorial's verdicts read the editor's source, and the
    // editor's own ended() draws it.
    if(o->run_restore) o->run_restore();
    const char *why=app_error();
    if(o->ended) o->ended(run_started, tick_err==ESP_OK?why:(why[0]?why:"EXECUTION FAILED"));
    else {
        if(tick_err!=ESP_OK) home_error="EXECUTION FAILED";
        sound_play(2);
        ESP_LOGI("shell","HOME_READY");
    }
    // A session that ended because it called pocket.workspace.run() hands the
    // screen straight to the work it named: section 7 has the current session
    // end and the target take over, with no second program running at any
    // moment. The screen the run belongs to is unchanged, so Back still leaves
    // to where the person started.
    take_pending_run();
}

// Resident suspension (docs/vm/app-suspend-design.md): the app is asleep, not
// gone, so none of end_run()'s teardown runs -- the home screen simply comes
// back, and the menu row of the app shows it paused.
static void suspend_run(void) {
    running=false;
    xQueueReset(keys);
    sound_play(2);
    ESP_LOGI("shell","HOME_READY");
}

static void take_pending_run(void) {
    const char *source=NULL;
    size_t      length=0;
    if(!pocket_workspace_run_take(&source,&length)) return;
    begin_run(APP_ID_WORK,NULL,0,source,length);
    // app_start_source() borrows the bytes only for the length of the start.
    pocket_workspace_run_done();
}

// Which app is starting, by name. Section 3 gives the host the identity, and
// app_session.c reads it back out of the registry to key the stores and to
// check what the manifest requires — so the name here is the whole of the
// decision, and the ternary on a source pointer that used to stand in for it
// is gone.
static void begin_run(const char *app_id, const char *prelude, size_t prelude_len,
                      const char *source, size_t len) {
    owner=screen;
    // APPS FIRST (docs/platform/wifi-autostart.md). A clock sync the idle home
    // screen started holds about 48 KB while the radio is up; the guest below,
    // or the resume of a kept one, is built only after it has given that back.
    // A no-op when no sync is running, which is nearly always.
    net_autosync_yield("app");
    // A kept app is resumed by opening it again from the menu (sec.8-4); any
    // other start ends it first -- stop("evict") is its last chance to save --
    // because there is one guest slot and this start is about to take it.
    // S5: the background music gives way to an app that starts short of room.
    // 128 KiB covers the shipped apps' 38-107 KB with the Kasane arena on top;
    // below it the app's heap wins over the song.
    if(pocket_av_background_active() &&
       heap_caps_get_free_size(MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT)<128*1024)
        pocket_av_background_stop("memory");
    const char *kept=app_dormant_id();
    if(kept[0]) {
        if(!strcmp(kept,app_id) && app_resume()==ESP_OK) {
            run_started=ESP_OK;
            running=true;
            app_force_redraw();
            ESP_LOGI(SCREENS[owner].tag,"RESUME %s",app_id);
            return;
        }
        app_stop();
    }
    // The other half of the same rule. Every path that builds a foreground
    // guest comes through here, and app_session.c holds ONE set of statics --
    // so the overlay's session must be gone before this one is built. A path
    // that reached app_start_test() without passing here would silently
    // overwrite a live guest pointer; the one that exists (the USB
    // diagnostics) releases the overlay itself.
    overlay_release();
    // app_session releases background scratch before every foreground start,
    // including diagnostics, while preserving it for background overlays.
    app_registry_select(app_id);
    run_started = source ? app_start_source(prelude,prelude_len,source,len)
                         : app_start();
    // The bytes have been parsed, so the screen that lent them can put them
    // back in the heap for as long as the guest is up.
    if(SCREENS[owner].run_release) SCREENS[owner].run_release();
    ESP_LOGI(SCREENS[owner].tag,"RUN %u bytes -> %s",
             (unsigned)len,esp_err_to_name(run_started));
    if(run_started==ESP_OK) { running=true; return; }
    // The guest never came up, so there is nothing to tick or stop; report it
    // to whoever asked and stay where we are.
    app_stop();
    running=false;
    const screen_ops_t *o=&SCREENS[owner];
    if(o->run_restore) o->run_restore();
    if(o->ended) o->ended(run_started,app_error());
    else home_error="START FAILED";
}

// One frame of a running guest. Back returns to the screen that started it,
// except from the home screen, where the whole app is what Back leaves.
#ifdef POCKET_DERBY_DETAIL_MEASURE
static bool end_derby_detail_run(esp_err_t result) {
    if(result!=ESP_OK || !app_derby_detail_finished()) return false;
    // A late return must fail now, before another tick can rearm its deadline.
    if(!app_derby_detail_deadline_ok()) { end_run(ESP_ERR_TIMEOUT); return true; }
    // Use the ordinary owner teardown; do not dispatch an interrupting turn.
    end_run(df_detail_exit_record()?ESP_OK:ESP_FAIL);
    return true;
}
#endif
static void tick_run(bool have, const keystroke_t *stroke) {
    // The three pickers below keep the guest from being ticked, so its
    // input.keys cannot see that the keys pressed meanwhile were theirs.
    if(pocket_workspace_modal() || sd_picker_modal() || file_picker_modal())
        pocket_input_keys_withhold();
    // The works picker is a host screen over a live guest: while it is up the
    // guest is not ticked and the keys are the picker's. Its promise settles on
    // the turn after it closes, which is the first turn the guest runs again.
    if(pocket_workspace_modal()) {
        if(have) pocket_workspace_modal_key(stroke);
        if(pocket_workspace_modal_dirty()) pocket_workspace_modal_draw();
        if(!pocket_workspace_modal()) app_force_redraw();
        return;
    }
    // fs.requestFolder puts up the same kind of screen for the same kind of
    // reason: the person choosing a folder on the card IS the grant, so the
    // guest waits while they do it. An app that opened both in one turn gets
    // them in this order rather than on top of each other; the second one's
    // deadline keeps running while it waits, which is what a person who is
    // being asked two questions at once would expect of the second.
    if(sd_picker_modal()) {
        if(have) sd_picker_modal_key(stroke);
        if(sd_picker_modal_dirty()) sd_picker_modal_draw();
        if(!sd_picker_modal()) app_force_redraw();
        return;
    }
    // fs.pickFile is the same screen again, one grant further in: the person
    // choosing a file is choosing convenience rather than permission, so this
    // one comes after the grant picker for the same reason the grant picker
    // comes after the works picker -- two questions asked in one turn are
    // answered in the order they would have to be answered anyway.
    if(file_picker_modal()) {
        if(have) file_picker_modal_key(stroke);
        if(file_picker_modal_dirty()) file_picker_modal_draw();
        if(!file_picker_modal()) app_force_redraw();
        return;
    }
    // A text session takes the keyboard from the guest for as long as it is
    // open: section 6 gives the HOST the field, so the app receives neither the
    // keystrokes nor the Back that would otherwise end it -- Escape there means
    // "cancel the conversion, or the field", and both are pocket_text's.
    if(have && pocket_text_active()) {
        pocket_text_key(stroke);
        have=false;
        // The guest's renderer presents only when IT has damage, so a field
        // that moved on a frame the app did not would not be sent at all.
        app_force_redraw_bands(pocket_text_take_dirty());
    }
    board_key_t key=have?stroke->nav:KEY_NONE;
    bool leave = have && key==KEY_BACK;
    esp_err_t e=ESP_OK;
    // An app that can be kept goes to sleep instead (docs/vm/app-suspend-design
    // .md). Only from the menu: a Playground or tutorial run hands its buffer
    // back to the editor on the way out, which a kept guest would not. A
    // suspension that fails is the ordinary Back below.
    // Not a work launched by workspace.run(): every work shares APP_ID_WORK, so a
    // kept one could not be told from the next.
    if(leave && owner==SCREEN_HOME && app_can_suspend() &&
       strcmp(app_registry_current()->id,APP_ID_WORK) && app_suspend()==ESP_OK) {
        suspend_run();
        return;
    }
    // Let the guest persist its last state before cancellation tears it down.
    if(leave) { e=app_tick(0x2000); app_request_stop(); }

    bool shot=atomic_exchange(&capture,false);
    if(shot) { board_capture(true); app_force_redraw(); }
#ifdef KASANE_MEGADEMO_TRACE
    if(!shot&&atomic_load(&raw_capture)>0) { atomic_fetch_sub(&raw_capture,1); shot=true; board_capture(true); }
#endif
    if(!leave) {
        if(key==KEY_ENTER) sound_play(1);
        uint32_t buttons=key==KEY_ENTER?0x4000:key==KEY_UP?0x10:
                         key==KEY_RIGHT?0x20:key==KEY_DOWN?0x40:key==KEY_LEFT?0x80:0;
        e=app_tick(buttons);
        // A release frame, so consecutive queued presses stay distinct.
#ifdef POCKET_DERBY_DETAIL_MEASURE
        if(e==ESP_OK && buttons && !app_derby_detail_finished()) e=app_tick(0);
#else
        if(e==ESP_OK && buttons) e=app_tick(0);
#endif
    }
    if(shot) board_capture(false);
    // Again after the turn, for the field the app itself moved: open() and
    // close() are ordinary JS calls and can happen in a frame with no key and
    // no damage of the guest's own. The repaint lands on the next frame, which
    // is 33 ms and is why the check above exists as well -- a keystroke has to
    // be seen in the frame it was typed in.
    app_force_redraw_bands(pocket_text_take_dirty());
    // The recording indicator is composited into every strip that is sent, so
    // it needs a strip to be sent: an app that has stopped drawing would
    // otherwise leave the screen it last drew, with no dot on it.
    if(pocket_capture_take_dirty()) app_force_redraw();

    // Accepted this turn, so no further input reaches the app: the session ends
    // here and end_run() starts what it asked for.
#ifdef POCKET_DERBY_DETAIL_MEASURE
    if(!leave && end_derby_detail_run(e)) return;
#endif
    if(!leave && e==ESP_OK && pocket_workspace_run_requested()) { end_run(ESP_OK); return; }
    if(leave || e!=ESP_OK) end_run(e);
}

// Repaint, and report what one costs. The frame cap would hide it otherwise.
static void paint(const screen_ops_t *s) {
    int64_t began=esp_timer_get_time();
    bool shot=atomic_exchange(&capture,false);
    if(!shot && !pet_repaint && !s->dirty()) return;
    if((shot||pet_repaint) && s->repaint_all) s->repaint_all();
    if(shot) board_capture(true);
    s->draw();
    if(shot) board_capture(false);
    if(shot || s->frame_ms>=33) return;      // the home screen logs its own
    static int64_t sum, peak; static unsigned n;
    int64_t work=esp_timer_get_time()-began;
    sum+=work; if(work>peak) peak=work;
    if(++n==8) { ESP_LOGI(s->tag,"REPAINT avg=%lldus max=%lldus",sum/8,peak);
                 sum=0; peak=0; n=0; }
}

// The frame period floor for a running guest (vm-L1-design sec.4.2). Without
// it, an app whose completions arrive back to back (a 10 ms sleep loop, a UART
// that keeps answering) would be woken from the frame cap over and over and
// call frame() far faster than 30 fps -- onFrame's dt stays honest, being
// computed from the clock, but an app that counts frames as a clock would not.
// 8 ms is the job budget: below it the transfer alone (7.7 ms, measured
// (device)) cannot keep up anyway.
#define VM_MIN_PERIOD_MS 8

// Start of the display period the current frame() belongs to -- i.e. when the
// previous frame()'s turn finished waiting. Continuation turns run inside it
// without restarting it; see the rule at the bottom of ui_task().
static int64_t period_began;

static bool ui_key_receive(keystroke_t *stroke) {
    bool have=xQueueReceive(keys,stroke,0)==pdTRUE;
#ifdef KASANE_P0_PROBE
    // Measures queue residence after the input task saw the event. It does
    // not claim to measure physical key-down or USB host transport latency.
    if(have&&overlay_running())
        ksn_p0_probe_sample(KSN_P0_INPUT_QUEUE,
                            (uint32_t)esp_timer_get_time()-stroke->queued_at_us);
#endif
    return have;
}

static void ui_task(void *arg) {
    (void)arg;
    // Before anything can post: every producer of a completion runs on a task
    // this one starts, or on an interrupt armed from it.
    vm_wake_bind();
    ESP_LOGI("shell","ui runs on core %d",xPortGetCoreID());
    ESP_LOGI("shell","HOME_READY");
#ifdef KASANE_P0_PROBE
    int64_t previous_overlay_frame_started=0;
#endif
    while(1) {
        /* App teardown can time out while an SD read is in progress. Reap its
         * acknowledged lease even when HOME has no guest turns to pump. */
        pocket_video_sd_stream_reap();
#ifdef KASANE_MEGADEMO_DEVICE_PROBE
        if(!running&&screen==SCREEN_HOME&&atomic_exchange(&megademo_probe_requested,false)){
            ksn_megademo_device_probe_run();
            ESP_LOGI("shell","HOME_READY");
        }
#endif
#ifdef KASANE_PROC_LIMITS_PROBE
        if(!running&&screen==SCREEN_HOME&&atomic_exchange(&limits_probe_requested,false)){
            ksn_proc_limits_device_probe_run();
            ESP_LOGI("shell","HOME_READY");
        }
#endif
#ifdef KASANE_PROC_DEVICE_PROBE
        if(!running&&screen==SCREEN_HOME&&atomic_exchange(&proc_probe_requested,false)){
            ksn_proc_device_probe_run();
            ESP_LOGI("shell","HOME_READY");
        }
#endif
#ifdef CONFIG_KSN_DEVICE_PROBE
        if(!running&&screen==SCREEN_HOME&&atomic_exchange(&ksn_probe_requested,false)){
            ksn_device_probe_run();
            ESP_LOGI("shell","HOME_READY");
        }
#endif
        if(!running&&screen==SCREEN_HOME&&atomic_exchange(&fpu_probe_requested,false)){
            fpu_latency_run();
            ESP_LOGI("shell","HOME_READY");
        }
#ifdef CONFIG_POCKET_VM_RELOC
        // Acknowledged on the home screen with a marker of its own, so a host
        // script knows the arming landed before it starts an app -- otherwise
        // a VM_RELOC line that never appears is ambiguous between "the key was
        // dropped" and "the app never parked where a move was legal".
        if(!running&&screen==SCREEN_HOME&&atomic_exchange(&reloc_requested,false)){
            app_vm_reloc_request();
            ESP_LOGI("shell","VM_RELOC_ARMED");
            ESP_LOGI("shell","HOME_READY");
        }
#endif
        int64_t frame_start=esp_timer_get_time();
        DF_OWNER_BEGIN((uint64_t)frame_start);
#ifdef KASANE_P0_PROBE
        if(overlay_running()) {
            if(previous_overlay_frame_started)
                ksn_p0_probe_sample(KSN_P0_UI_INTERVAL,
                    (uint32_t)(frame_start-previous_overlay_frame_started));
            previous_overlay_frame_started=frame_start;
        } else previous_overlay_frame_started=0;
#endif
        keystroke_t stroke={0};
        bool have=ui_key_receive(&stroke);
        // For net_autosync_poll(): the home screen is idle only while nobody is
        // typing at it, and `have` is consumed by the handlers below.
        const bool key_seen=have;
#ifdef CONFIG_KSN_DEVICE_PROBE
        /* Replay the visual diagnostic from the physical keyboard as well. */
        if(have&&!running&&screen==SCREEN_HOME&&stroke.len==1&&stroke.text[0]=='~'){
            atomic_store(&ksn_probe_requested,true);
            continue;
        }
#endif
        // Before everything: the volume is the device's, so it is answered
        // before any question about who owns the screen.
        if(have&&!running&&screen==SCREEN_HOME&&!home_modal()&&volume_key(&stroke))
            have=false;
#ifdef CONFIG_KSN_DEVICE_PROBE
        int system_probe_command=atomic_exchange(&system_probe_requested,0);
        if(system_probe_command)system_probe(system_probe_command);
#endif
#ifdef KASANE_P5_NOTICE_PROBE
        int p5_notice_command=atomic_exchange(&p5_notice_probe_requested,0);
        if(p5_notice_command=='J'){
            uint32_t id=0;
            sys_notice_result result=sys_notify_post(sys_device_notifications(),P5_NOTICE_OWNER,
                                                     1,"P5 SYSTEM NOTICE",0,&id);
            ESP_LOGI("KSN_P5_NOTICE","POST result=%u id=%u",(unsigned)result,(unsigned)id);
        }else if(p5_notice_command=='C'){
            sys_notify_release_owner(sys_device_notifications(),P5_NOTICE_OWNER);
            ESP_LOGI("KSN_P5_NOTICE","CLEAR");
        }
#endif
        sys_device_step();
#ifdef KASANE_P0_PROBE
        int64_t av_service_started=esp_timer_get_time();
#endif
        pocket_av_service_stream();
#ifdef KASANE_P0_PROBE
        if(overlay_running())
            ksn_p0_probe_sample(KSN_P0_AV_SERVICE,
                                (uint32_t)(esp_timer_get_time()-av_service_started));
#endif
        pet_repaint=pet_hub_pump();
        if(have&&pet_hub_key(stroke.nav)){have=false;pet_repaint=true;}
        if(pet_repaint&&running)app_force_redraw();
        const screen_ops_t *s=&SCREENS[screen];

        // The force stop, and Back on the home screen, arrive out of band.
        if(atomic_exchange(&stop,false)) {
            if(running) end_run(ESP_OK);
            else if(screen!=SCREEN_HOME) go_home();
            else if(home_error) home_error=NULL;
            // The force stop stands an overlay down too. This is NOT the
            // reserved key -- this block only runs for Ctrl+Alt+Del, which is
            // why putting the reserved key here left Back travelling the
            // ordinary path and reaching the guest. The reserved key is in the
            // residue loop below, where every other keystroke is decided.
            else if(overlay_running()&&!home_modal()) overlay_yield("force stop",false);
            else { shell_key(KEY_BACK); take_pending_screen(); }
            xQueueReset(keys);
            have=false;
        }

        if(running) {
            tick_run(have,&stroke);
        } else {
            // A repaint costs about as much as a whole frame, so taking one
            // key per frame capped typing at the frame rate -- and the queue
            // then threw the rest away without saying so: a 3,055 byte source
            // typed in over USB arrived 621 bytes short. Keys are drained and
            // painted once, which is also the only state anybody can see.
            //
            // A key that moves screens or asks for a run ends the batch, so
            // the screen it moved to gets its own frame rather than being fed
            // the keys meant for the one before it. Both wants_run predicates
            // are pure, which is what makes asking twice per frame free.
            // MODALS BEAT THE OVERLAY (3.1). The same three screens tick_run()
            // drives for a foreground guest, driven here for an overlay one --
            // and this is not symmetry for its own sake: without it a modal an
            // overlay opened would never be drawn and never take a key, so
            // "the shell's prompts win" would be a sentence in a document with
            // nothing behind it. The order is tick_run()'s, for the reason
            // given there.
            if(!running && screen==SCREEN_HOME && overlay_running()) {
                if(pocket_workspace_modal()) {
                    if(have) pocket_workspace_modal_key(&stroke);
                    if(pocket_workspace_modal_dirty()) pocket_workspace_modal_draw();
                    goto framed;
                }
                if(sd_picker_modal()) {
                    if(have) sd_picker_modal_key(&stroke);
                    if(sd_picker_modal_dirty()) sd_picker_modal_draw();
                    goto framed;
                }
                if(file_picker_modal()) {
                    if(have) file_picker_modal_key(&stroke);
                    if(file_picker_modal_dirty()) file_picker_modal_draw();
                    goto framed;
                }
            }
            screen_id_t was=screen;
            // The residue. An overlay has ended the menu, so the keys the menu
            // used to consume are no longer consumed by anything -- that is the
            // premise 3.1's older text was missing, not a rule it got wrong.
            // Back never arrives: it was taken above.
            if(!running && screen==SCREEN_HOME && overlay_running()) {
                while(have) {
                    // THE RESERVED KEY, taken before delivery and never after.
                    // 3.1 asks that the way out be undeliverable to the overlay
                    // by construction, and this `break` is that construction:
                    // the loop that hands keys to the guest is the only path
                    // there is, and Back leaves it before reaching the call.
                    //
                    // A modal keeps it -- Escape on a folder picker means "I
                    // decline", and spending it on standing the overlay down
                    // would leave that screen up with its promise unsettled.
                    if(stroke.nav==KEY_BACK&&!home_modal()) {
                        overlay_yield("the person",true);
                        // The menu is back, which is what this marker has
                        // always meant. Saying it here keeps the contract the
                        // host scripts read -- they open with Back and wait for
                        // this line, and an armed overlay would otherwise make
                        // that wait forever.
                        ESP_LOGI("shell","HOME_READY");
                        have=false;
                        break;
                    }
                    overlay_key(&stroke);
                    have=ui_key_receive(&stroke);
                }
            }
            while(have) {
                if(!s->key(&stroke)) { go_home(); break; }
                if(screen!=was) break;
                const char *ignored; size_t ignored_len;
                if(s->wants_run && s->wants_run(&ignored,&ignored_len)) break;
                have=ui_key_receive(&stroke);
            }
            s=&SCREENS[screen];              // key() may have moved us
            // One overlay turn, before the frame it will be composited into
            // and only where the home screen still owns the display. It runs
            // ahead of the wants_run test below so that a key which starts a
            // foreground app in this same frame still finds the overlay
            // released by begin_run() rather than half-ticked.
            // The previous frame's length, which is the only one that has
            // finished. This frame's is not knowable here -- the overlay turn
            // is part of it -- and the scene does not change cost from one
            // frame to the next by anything like the factor this decides.
            // Not while an app is kept asleep (sec.8-3): an overlay would need
            // the guest slot and the Kasane lease the sleeping app holds.
            if(!running && screen==SCREEN_HOME && !app_dormant_id()[0]) {
                // The overlay's start is gated on free heap and a refusal
                // sticks until the person re-arms it, so a radio that happened
                // to be up at that moment must not be what it measures.
                if(overlay_starting()) net_autosync_yield("overlay");
                overlay_tick(last_frame_us);
            }
            const char *source=NULL; size_t len=0;
            if(!running && s->wants_run && s->wants_run(&source,&len)) {
                const char *pre=NULL; size_t pre_len=0;
                if(s->prelude) pre=s->prelude(&pre_len);
                begin_run(screen==SCREEN_TUTORIAL?"local.tutorial":"local.playground",
                          pre,pre_len,source,len);
            }
            else if(!running)
                paint(s);

            framed:
        {
            int test=atomic_exchange(&diagnostic,0);
#ifdef KASANE_P0_PROBE
            if(test=='R'){
                ksn_p0_probe_reset();
                pocket_app_music_view_probe_reset_counters();
                ESP_LOGI("KSN_P0","RESET requested");
                test=0;
            }
#endif
            // The diagnostics below assume no guest exists; a kept one is ended
            // first, the way any other start ends it. Outside the SELFTEST
            // block: 'K', '1'..'6' and the sound checks are in every build.
            if(test && !running && screen==SCREEN_HOME && app_dormant_id()[0]) app_stop();
            // Every diagnostic below builds a guest or measures the heap, and
            // neither wants a radio in the middle of it.
            if(test && !running && screen==SCREEN_HOME) net_autosync_yield("diagnostic");
#ifdef CONFIG_POCKET_VM_SELFTEST
            if((test=='L'||test=='M') && !running && screen==SCREEN_HOME) {
                overlay_release();
                scene_mem_release();
                if(test=='L') vmtest_lifecycle_device();
                else {
                    app_registry_select(APP_ID_DEFAULT);
                    app_vm_back_selftest();
                }
                test=0;
            }
#endif
            // Runs in place of starting a guest: it needs no app, and holding
            // 6,480 bytes of scratch is only affordable while none is running.
            if(test=='8') { sound_check_tables(); test=0; }
            // Returns immediately: the sweep runs on its own task, because
            // twelve seconds of it inline here is twelve seconds without a
            // frame reaching the panel. Started from here anyway, so it cannot
            // begin while a guest owns the display.
            if(test=='9') { sound_capture_probe(); test=0; }
#ifdef POCKET_HEAPPROBE
            // Through begin_run, the path a menu app takes (identity, Kasane
            // arena, eval_user_source), so a variant is evaluated exactly as
            // an app would be.
            if(test=='Q') {
                const char *src,*id; size_t len;
                if(!running && screen==SCREEN_HOME &&
                   app_heapprobe_select(heapprobe_arg,&src,&len,&id)) {
                    begin_run(id,NULL,0,src,len);
                    app_heapprobe_release();
                }
                test=0;
            }
#endif
            if(test && !running && screen==SCREEN_HOME) {
                overlay_release();
                owner=SCREEN_HOME;
                // A diagnostic normally runs as the default app. The two app
                // letters must not: the manifest decides which capabilities are
                // injected (pet.companion) and which store owns the saved
                // state, and running pet under hello's identity would give it
                // neither.
                const char *diag_id=APP_ID_DEFAULT;
#ifdef CONFIG_POCKET_VM_PROBE
                if(test=='<') diag_id="local.pet";
                else if(test=='>') diag_id="local.companion";
#endif
                app_registry_select(diag_id);
                run_started=app_start_test(test);
                running = run_started==ESP_OK;
                if(!running) { app_stop(); home_error="TEST ERROR"; }
            }
            }
        }

        // Which reading of the USB byte stream applies. A running app is
        // normally not a text screen, and a text session makes it one for as
        // long as it is up -- otherwise a host script driving this over USB
        // could not type into the field it just opened.
        atomic_store(&text_screen,
                     SCREENS[screen].takes_text || pocket_text_active());

        // Once a frame, on every screen: a frame away from home is what resets
        // the idle clock. Eligible means the menu (or an overlay that is up) is
        // all there is -- no guest, no modal, no error waiting to be read, no
        // overlay about to start. A kept app does not disqualify it: a
        // suspension already guarantees the room for a radio
        // (APP_SUSPEND_MIN_FREE), and the resume yields like any start.
        // Background music does: it is the one thing on the home screen with a
        // deadline, it holds about 62 KB, and the radio's effect on it has not
        // been measured -- the clock can wait for the song to end.
        net_service_pump();
        net_autosync_poll(!running && screen==SCREEN_HOME && !home_modal() &&
                          !home_error && !overlay_starting() &&
                          !pocket_av_background_active(),
                          key_seen);

        DF_WORK_END((uint64_t)esp_timer_get_time());
        last_frame_us=(uint32_t)(esp_timer_get_time()-frame_start);
#ifdef KASANE_P0_PROBE
        // Unlike overlay_draw, this includes the synchronous SD producer.
        // Do not count the frame that ends/reports the session after reset.
        if(overlay_running()) ksn_p0_probe_sample(KSN_P0_UI_FRAME,last_frame_us);
#endif
        int held=(int)(last_frame_us/1000);
        unsigned cap = running ? VM_DISPLAY_PERIOD_MS : SCREENS[screen].frame_ms;
        unsigned rest = (unsigned)held<cap?cap-held:1;
        // The one wait L1 can actually replace (vm-L1-design sec.4.1: this task
        // cannot stop, because the home screen, the pet and the overlay all
        // ride on it, so a guest with nothing to do is not a reason to idle).
        // A completion posted by another task or an ISR cuts the frame cap
        // short instead of waiting out the period; the measured (device) cost
        // it removes is the "up to one frame period" term of completion
        // latency, and nothing else.
        if(running) {
            // THE RULE (docs/vm/vm-L1-report.md sec.2.4): the display period
            // paces PICTURES, so it is charged once per frame() and from the
            // start of that frame's period -- not once per turn. A turn that
            // only drains jobs shows nothing anyone is waiting for, so it
            // waits the job budget's floor instead, and the time it spent
            // counts towards the period of the frame() it works towards.
            //
            // Charging every turn was the regression, and it was the WAIT and
            // not the JavaScript: measured (device) on async_generator, three
            // continuations of 8 ms held + 23 ms waited, then one ordinary
            // turn -- 125 ms for one picture, 7.72 fps against legacy's 28.20,
            // with the same 62 jobs at the same 0.49 ms each.
            //
            // The alternatives, and why they lose:
            //   - keep the period on continuations: the regression above.
            //   - no wait at all on a continuation: this task is priority 5
            //     and a long drain would hold its core for the whole drain,
            //     starving everything below it. The runaway guard would not
            //     catch it either -- that guard charges drain time, which is
            //     honest work here. Hence a floor that is never zero.
            //   - drop the display period and let frame() run at the 8 ms
            //     floor: four transfers per period on a bus that needs 7.7 ms
            //     for one (measured (device)), and every app that counts
            //     frame() calls as a clock changes speed.
            //   - charge the period from THIS turn's start (the obvious
            //     one-line version): the continuations already spent inside
            //     the period get charged to it twice, and the measured result
            //     is 17 fps where this rule gives 23.
            const bool cont=app_turn_continued();
            if(cont) {
                // Never zero. At CONFIG_FREERTOS_HZ=1000 one tick is a real
                // yield, and a yield is all a turn that just ran 8 ms of jobs
                // owes the rest of the machine.
                rest = (unsigned)held<VM_MIN_PERIOD_MS?VM_MIN_PERIOD_MS-(unsigned)held:1;
                DF_PACE_BEGIN(DF_PACE_CONT,(uint64_t)esp_timer_get_time(),pdMS_TO_TICKS(rest));
                vTaskDelay(pdMS_TO_TICKS(rest));
                DF_PACE_END((uint64_t)esp_timer_get_time());
            } else {
                unsigned since=(unsigned)((esp_timer_get_time()-period_began)/1000);
                unsigned floor_ms = (unsigned)held<VM_MIN_PERIOD_MS?VM_MIN_PERIOD_MS-(unsigned)held:0;
                if(floor_ms) {
                    // Not interruptible: this is the rate limit, not the cap.
                    DF_PACE_BEGIN(DF_PACE_FLOOR,(uint64_t)esp_timer_get_time(),pdMS_TO_TICKS(floor_ms));
                    vTaskDelay(pdMS_TO_TICKS(floor_ms));
                    DF_PACE_END((uint64_t)esp_timer_get_time());
                    since+=floor_ms;
                }
                rest = since<VM_DISPLAY_PERIOD_MS ? VM_DISPLAY_PERIOD_MS-since : 0;
                // A completion posted by another task or an ISR cuts the frame
                // cap short instead of waiting out the period; the measured
                // (device) cost it removes is the "up to one frame period"
                // term of completion latency, and nothing else.
                if(rest){
                    uint64_t wait_now=(uint64_t)esp_timer_get_time();
                    uint32_t ticks=sys_device_wait_ticks(wait_now,pdMS_TO_TICKS(rest),
                                                         configTICK_RATE_HZ);
#ifdef POCKET_DERBY_FIXED_WORKLOAD
                    // Record the actual selected wait ticks without a second policy call.
                    uint32_t df_wait_ticks=pocket_kasane_source_wait_ticks(
                        wait_now,ticks,configTICK_RATE_HZ);
                    DF_PACE_BEGIN(DF_PACE_CAP,(uint64_t)esp_timer_get_time(),df_wait_ticks);
                    vm_wake_wait(df_wait_ticks);
                    DF_PACE_END((uint64_t)esp_timer_get_time());
#else
                    vm_wake_wait(pocket_kasane_source_wait_ticks(
                        wait_now,ticks,configTICK_RATE_HZ));
#endif
                }
                // The next period starts where this one's wait ended, so the
                // continuations that follow are charged to it exactly once.
                period_began=esp_timer_get_time();
            }
            DF_OWNER_END((uint64_t)esp_timer_get_time(),running);
            continue;
        }
        DF_OWNER_END((uint64_t)esp_timer_get_time(),false);
        // No guest, so no display period is running: the next one starts
        // when a frame() first does, and this keeps a stale `period_began`
        // from making the first frame of a new session skip its wait.
        period_began=esp_timer_get_time();
        uint64_t wait_now=(uint64_t)esp_timer_get_time();
        uint32_t ticks=sys_device_wait_ticks(wait_now,pdMS_TO_TICKS(rest),
                                             configTICK_RATE_HZ);
        vm_wake_wait(pocket_kasane_source_wait_ticks(
            wait_now,ticks,configTICK_RATE_HZ));
    }
}

// Every stored preference, the SKK settings and the Wi-Fi credentials live in
// NVS, so it comes up before the first thing that reads it. It used to be one
// term of an && chain inside shell_init(), where the failure was discarded and
// surfaced only as settings that had reset themselves.
static void nvs_init(void) {
    esp_err_t err=nvs_flash_init();
    // These two are the only failures an erase fixes: the partition is full of
    // stale pages, or it was written by a different NVS version. Erasing on
    // anything else would throw away the user's settings to work around a fault
    // we would rather see, so the rest is logged and left alone.
    if(err==ESP_ERR_NVS_NO_FREE_PAGES||err==ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_LOGW("boot","NVS_ERASED %s",esp_err_to_name(err));
        err=nvs_flash_erase();
        if(err==ESP_OK) err=nvs_flash_init();
    }
    if(err!=ESP_OK) ESP_LOGE("boot","NVS_INIT_FAILED %s",esp_err_to_name(err));
}

void app_main(void) {
    usb_serial_jtag_driver_config_t usb={.tx_buffer_size=1024,.rx_buffer_size=256};
    ESP_ERROR_CHECK(usb_serial_jtag_driver_install(&usb));
    ESP_ERROR_CHECK(usb_console_init());
    ESP_LOGI("boot","Cardputer ADV PocketJS M1; app=3MiB skk=2MiB fonts=512KiB");
#if POCKET_PROBES
    { extern void ble_probe(void); ble_probe(); }
#endif
    ESP_ERROR_CHECK(board_init());
    nvs_init();
    // Before shell_init(), which loads the AUTO TIME SYNC row into it.
    net_autosync_init();
    pet_hub_init();
    shell_init();
    // After shell_init(), which is where the stored arming bit reaches the
    // overlay's setter, and before the UI task, which is what would start it.
    // This is the boot that decides whether an overlay that did not survive
    // its last start gets another one, and the answer is no.
    overlay_init();
    // Neither is fatal: the home stays usable with no dictionary and no font,
    // and the editors show which one is missing.
    jpfont_init();
    skk_session_init();
#if POCKET_PROBES
    { extern void opus_probe(void); opus_probe(); }
#endif
#if POCKET_PROBES
    { extern void sd_probe(void); sd_probe(); }
#endif
    keys=xQueueCreate(16,sizeof(keystroke_t));configASSERT(keys);
    configASSERT(xTaskCreate(input_task,"input",4096,NULL,6,NULL)==pdPASS);
    // Pinned or not, ONE call site (xTaskCreate is itself a wrapper for this
    // with tskNO_AFFINITY), so CONFIG_POCKET_UI_TASK_CORE changes an immediate
    // and nothing else -- the three settings are one binary family, which is
    // what makes a measurement across them mean anything. Why it exists:
    // CCOUNT is per core, so a budget that reads it needs a task that cannot
    // migrate between two reads (docs/vm/vm-L1-report.md sec.8).
    configASSERT(xTaskCreatePinnedToCore(ui_task,"ui",32768,NULL,5,NULL,
        CONFIG_POCKET_UI_TASK_CORE<0?tskNO_AFFINITY:CONFIG_POCKET_UI_TASK_CORE)==pdPASS);
}
