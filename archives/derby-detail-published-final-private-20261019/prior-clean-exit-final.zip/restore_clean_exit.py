#!/usr/bin/env python3
"""Offline restore into a new empty checkout; verify previous and new trees."""
from pathlib import Path
import argparse,hashlib,json,subprocess,sys,tempfile,zipfile
p=argparse.ArgumentParser();p.add_argument('--variant',choices=('baseline','native','batch'),required=True);p.add_argument('--destination',type=Path,required=True);a=p.parse_args()
b=Path(__file__).resolve().parent;m=json.loads((b/'CHECKPOINT.json').read_text());info=m['variants'][a.variant];dest=a.destination.resolve()
if dest.exists() and any(dest.iterdir()):raise SystemExit('Destination must be empty; existing work is protected')
prior=b/'prior-code-ci-final.zip';assert hashlib.sha256(prior.read_bytes()).hexdigest()==m['prior_archive_sha256']
with tempfile.TemporaryDirectory(prefix='derby-restore-base-') as td:
 with zipfile.ZipFile(prior) as z:
  for n in z.namelist():
   assert not Path(n).is_absolute() and '..' not in Path(n).parts
  z.extractall(td)
 helper=next(Path(td).rglob('restore_checkpoint.py'))
 subprocess.run([sys.executable,str(helper),'--variant',a.variant,'--destination',str(dest)],check=True)
def git(*args):return subprocess.check_output(['git','-C',str(dest),*args])
assert git('rev-parse','HEAD').decode().strip()==info['previous_remote_commit']
bundle=b/'increments'/(a.variant+'.bundle');assert hashlib.sha256(bundle.read_bytes()).hexdigest()==info['bundle_sha256']
git('bundle','unbundle',str(bundle));git('checkout','-B',info['branch'],info['local_commit'])
assert git('rev-parse','HEAD^{tree}').decode().strip()==info['local_tree']
patch=b/'patches'/(a.variant+'.patch');assert hashlib.sha256(patch.read_bytes()).hexdigest()==info['patch_sha256']
assert git('diff','--binary','--full-index',info['base_commit'],'HEAD')==patch.read_bytes()
for name,want in info['modified_files'].items():assert hashlib.sha256((dest/name).read_bytes()).hexdigest()==want,name
assert not git('status','--porcelain').strip()
print(json.dumps({'restored':True,'variant':a.variant,'exact_commit':info['local_commit'],'exact_tree':info['local_tree'],'newhead_ci_verified':False,'hardware_accepted':False}))
