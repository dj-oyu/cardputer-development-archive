#!/usr/bin/env python3
"""Local-only compiler peak experiment. Does not model ESP32 physical memory."""
from pathlib import Path
import argparse, json, os, shutil, subprocess, sys, hashlib
ap=argparse.ArgumentParser();ap.add_argument('--variant',required=True);a=ap.parse_args()
v=a.variant
root=Path('/workspace')/('derby-detail-recovery' if v=='baseline' else 'derby-detail-'+v)
out=Path('/workspace/derby-evidence/device-v2-20261020/local-compile-investigation')/v
out.mkdir(parents=True,exist_ok=True)
sys.path[:0]=[str(root/'tools/games'),str(root/'tools')]
import run_derby,run_derby_fixed
cache=out/'build';cache.mkdir(exist_ok=True)
original=Path('/workspace/derby-evidence/exit-fix-fast')/(v+'-on')
for name in ('dtoa','libregexp','libunicode','quickjs','quickjs-vm'):
 shutil.copy2(original/'build-fast-detail'/(name+'.o'),cache/(name+'.o'))
h=run_derby_fixed.make_harness(out)
text=h.read_text().replace('static size_t cur_bytes,peak_bytes;','static size_t cur_bytes,peak_bytes,diag_phase_peak;')
needle='if(cur_bytes>turn_hi)turn_hi=cur_bytes;}'
assert text.count(needle)==1
text=text.replace(needle,'if(cur_bytes>turn_hi){turn_hi=cur_bytes;}\n    if(cur_bytes>diag_phase_peak){diag_phase_peak=cur_bytes;}}')
text+='''
void diag_mem_begin(JSRuntime *r,const char *name,const char *phase){
 size_t used,limit;JS_GetMemoryCounters(r,&used,&limit);diag_phase_peak=cur_bytes;
 printf("COMPILE_TRACE_BEGIN chunk=%s phase=%s used=%zu allocator_live=%zu limit=%zu\\n",name,phase,used,cur_bytes,limit);
}
void diag_mem_end(JSRuntime *r,const char *name,const char *phase){
 size_t used,limit;JS_GetMemoryCounters(r,&used,&limit);
 printf("COMPILE_TRACE_END chunk=%s phase=%s used=%zu allocator_live=%zu allocator_peak=%zu limit=%zu\\n",name,phase,used,cur_bytes,diag_phase_peak,limit);
}
'''
h.write_text(text)
loader=out/'pocket_app_load_trace.c'
text=(root/'main/pocket/pocket_app_load.c').read_text()
text=text.replace('static const char *TAG =','extern void diag_mem_begin(JSRuntime *,const char *,const char *);\nextern void diag_mem_end(JSRuntime *,const char *,const char *);\nstatic const char *TAG =',1)
text=text.replace('    JSValue fn=JS_Eval(ctx,chunk->start,bytes,chunk->file,','    diag_mem_begin(rt,chunk->name,"compile");\n    JSValue fn=JS_Eval(ctx,chunk->start,bytes,chunk->file,',1)
text=text.replace('    if(JS_IsException(fn)) return fail(ctx,chunk,false);','    diag_mem_end(rt,chunk->name,"compile");\n    if(JS_IsException(fn)) return fail(ctx,chunk,false);',1)
text=text.replace('    JSValue result=JS_EvalFunction(ctx,fn);','    diag_mem_begin(rt,chunk->name,"run");\n    JSValue result=JS_EvalFunction(ctx,fn);',1)
text=text.replace('    loading&=~bit;','    diag_mem_end(rt,chunk->name,"run");\n    loading&=~bit;',1)
loader.write_text(text)
run_derby.EXTRA=[str(loader) if x=='main/pocket/pocket_app_load.c' else x for x in run_derby.EXTRA]
options={'measure':True,'fixed_workload':True,'harness':h}
if v=='batch':options['runner_batch']=True
binary=run_derby.build(['-O2','-DPOCKET_DERBY_DETAIL_MEASURE'],cache,**options)
cases=['original']+(['defer-buffer','split-controller'] if v=='batch' else [])
summary={}
for case in cases:
 target=out/case/'app';target.mkdir(parents=True,exist_ok=True)
 for p in (original/'app').iterdir():
  if p.is_file():shutil.copy2(p,target/p.name)
 if case=='defer-buffer':
  pan=target/'derby_pan.js';t=pan.read_text();assert t.count('const rb = new Float64Array(40);')==1
  pan.write_text(t.replace('const rb = new Float64Array(40);','let rb;'))
  w=target/'derby_watch.js';t=w.read_text();assert t.count("pocket.app.load('play');")==1
  w.write_text(t.replace("pocket.app.load('play');","pocket.app.load('play'), rb = new Float64Array(40);"))
 if case=='split-controller':
  p=target/'derby_play.js';t=p.read_text();marker='// DF fixture oval-pan8-390-510-v1: three dependent replays in one boot.'
  assert t.count(marker)==1;i=t.index(marker)
  p.write_text(t[:i]);(target/'derby_detail_ctl.js').write_text("'use strict';\n"+t[i:])
  with (target/'chunks.txt').open('a') as file:file.write('detail_ctl derby_detail_ctl.js\n')
  w=target/'derby_watch.js';t=w.read_text();assert t.count("pocket.app.load('play');")==1
  w.write_text(t.replace("pocket.app.load('play');","pocket.app.load('play'), pocket.app.load('detail_ctl');"))
 env=dict(os.environ,DERBY_APP_DIR=str(target),DERBY_HEAP_LIMIT='524288',DERBY_HW='0x2545F491',DERBY_DEVICE_FIXTURE_HOST='1',DERBY_SER_ORACLE='1',DERBY_SER_FUZZ='4000')
 r=subprocess.run([str(binary)],cwd=root,env=env,capture_output=True)
 raw=r.stdout+r.stderr;(out/case/'trial.log').write_bytes(raw)
 if r.returncode:raise RuntimeError(case+' failed; see trial.log')
 from derby_fixed_result import parse_trial
 from derby_detail_result import parse_detail
 coarse=parse_trial(raw,transport_complete=True);detail=parse_detail(raw.decode(),expected=True)
 windows=[json.loads(l[len('DEVICE_WINDOW '):]) for l in raw.decode().splitlines() if l.startswith('DEVICE_WINDOW ')]
 result={'variant':v,'trial':coarse,'windows':windows,'device_sized_model':False}
 run_derby_fixed.check_result(result);assert len(detail)==3
 traces=[]
 for l in raw.decode().splitlines():
  if l.startswith('COMPILE_TRACE_END '):
   d=dict(x.split('=',1) for x in l.split()[1:]);traces.append({k:int(x) if x.isdigit() else x for k,x in d.items()})
 summary[case]={'returncode':r.returncode,'known_work_and_hashes_pass':True,'detail_strict_pass':True,'traces':traces,'windows':windows,'raw_sha256':hashlib.sha256(raw).hexdigest(),'generated':{p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in target.glob('*.js')},'scope':'64-bit QuickJS/libc functional compiler-peak experiment; 524288B quota; not ESP physical memory, not actual OOM reproduction, not device performance'}
(out/'result.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'variant':v,'cases':list(summary),'strict_all_pass':True}))
