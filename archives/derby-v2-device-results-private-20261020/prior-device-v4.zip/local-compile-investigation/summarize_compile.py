#!/usr/bin/env python3
from pathlib import Path
import json,sys,difflib
p=Path(__file__).resolve().parent
sys.path.insert(0,'/workspace/derby-detail-batch/tools/games')
from derby_detail_result import parse_detail
original=parse_detail((p/'batch/original/trial.log').read_text(),expected=True)
checks={}
for case in ('original','defer-buffer','split-controller'):
 r=parse_detail((p/'batch'/case/'trial.log').read_text(),expected=True)
 assert [x['events'] for x in r]==[x['events'] for x in original]
 assert [[s['calls'] for s in x['stages']] for x in r]==[[s['calls'] for s in x['stages']] for x in original]
 checks[case]={'events_identical_to_original':True,'all_stage_calls_identical_to_original':True}
 if case=='original':continue
 d=[];a=p/'batch/original/app';b=p/'batch'/case/'app'
 for name in sorted({x.name for x in a.glob('*')}|{x.name for x in b.glob('*')}):
  old=(a/name).read_text().splitlines(keepends=True) if (a/name).exists() else []
  new=(b/name).read_text().splitlines(keepends=True) if (b/name).exists() else []
  d.extend(difflib.unified_diff(old,new,fromfile='a/'+name,tofile='b/'+name))
 (p/'batch'/case/'generated-candidate.patch').write_text(''.join(d))
(p/'semantic-counter-comparison.json').write_text(json.dumps(checks,indent=2)+'\n')
summary={'scope':'local-only 64-bit QuickJS/libc 524288B quota; TLSF-rounded guest live-payload peak in each chunk compile phase, excluding QuickJS bookkeeping/libc overhead and watch entry compilation; no ESP OOM reproduction or device action','cases':[],'semantic_counter_comparison':checks,'m32_local':'not run; no i386 libc/sysroot available locally; saved current-head CI m32 proof retained separately','superseded':'batch/split-controller-v1-sloppy and batch/result-before-strict.json are preserved but not current candidate; strict directive restored and rerun'}
for v in ['baseline','native','batch']:
 results=json.loads((p/v/'result.json').read_text())
 for case,r in results.items():
  comp=[t for t in r['traces'] if t['phase']=='compile']
  relevant=[t for t in comp if t['chunk'] in ('play','detail_ctl')]
  row={'variant':v,'case':case,'play_controller_phase_peak':max(t['allocator_peak'] for t in relevant),'all_chunk_compile_phase_peak':max(t['allocator_peak'] for t in comp),'compile_phases':relevant,'known_work_and_hashes_pass':r['known_work_and_hashes_pass'],'detail_strict_pass':r['detail_strict_pass'],'raw_sha256':r['raw_sha256'],'play_source_bytes':r['generated']['derby_play.js']['bytes'],'controller_source_bytes':r['generated'].get('derby_detail_ctl.js',{}).get('bytes',0)}
  summary['cases'].append(row)
assert (p/'batch/split-controller/app/derby_detail_ctl.js').read_text().startswith("'use strict';\n")
(p/'SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'strict_directive_preserved':True,'semantic_counters_identical':True,'cases':len(summary['cases'])}))
