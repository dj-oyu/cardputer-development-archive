# Measurement interpretation

These are three independent source variants (PR13 baseline root, PR14 native root,
PR15 batch root), each with the same detailed instrumentation and clean-exit fix.
Native and batch are not cumulative variants. Each accepted variant uses one
verified flash with one verified post-flash normal boot and one finite workload
job. Serial-open control lines may reset the device as disclosed by the plan;
additional physical resets before collection were not independently counted.
The recorded boot count refers to the verified post-flash boot. The three
summaries are dependent replays within the workload session (`independent=0`),
not three independent boots or statistical samples. Existing fixed fixture,
seed/camera, 390→510, 120 contexts, three summaries and 8-step tail are preserved.

The saved pipeline separates exact source receipt, registered build, actual
BIN/ELF mode proof, verified full-segment readback and expected boot observation,
exclusive lease/epoch/device association, v2 transport, and the firmware tree's
strict detailed parser. A configured expected firmware hash in the trial receipt
does not independently authenticate the installed image. Boot text is not a
cryptographic binary proof. Physical LCD observation is not claimed.

26 stages have inclusive and exclusive owner-task elapsed totals and call counts.
Inclusive parent and child scopes overlap and must not be added. Exclusive
`self_us` removes nested scopes and may be summed; unscoped elapsed is work minus
that sum for the same replay. Instrumentation overhead is charged to these
elapsed scopes. Timings include owner preemption and synchronous waits; JS pause
across a parked QuickJS turn is excluded. Foreign tasks/ISR do not use the scope
stack. `TX_REAP` is completion-wait elapsed and is not pure SPI transfer time.

13 events report logical buffer/payload amounts and submit/reap/failure counts.
They are not measured bus traffic. Some amounts describe the same pixels at
different pipeline stages; do not sum them into a physical memory-traffic number.
VM zero and code-copy counters are distinct; boundary snapshots are distinct
from segment copies. The implementation does not optimize or skip any of them.

`stages.csv` contains every replay's inclusive_us/exclusive_us/calls/work_us.
`logical-events.csv` contains every replay's amount and explicit unit.
`DETAILED-STAGES.md` presents medians of the three dependent replays. Medians of
separate stage rows need not sum to the median work. Raw values are authoritative.

Detailed ON/OFF semantic equality, disabled-path nonintervention, owner lifecycle,
negative parser cases and drawing hashes were validated on host and current-head
CI. Current-head CI also built real target detail ON/OFF images. These device
jobs use the registered detail-ON profile; no paired device detail-OFF overhead
control or independent-boot repetition was added. Therefore the table does not
establish an optimization speedup or instrumentation-free cost. Old coarse trial
timings are a separate experiment and cannot isolate this instrumentation's
target overhead. The old 90b9 APP ERROR trial remains failed.

Host drawing evidence: input986b2e6e027af00d, proceduralc1b0fdbde748d0de,
panelcec4b765a2794b14, race5DC86E18. Host previous-frame equality observations
(3,499,706/3,888,000 pixels and449/2040 entire strips per replay) are retained in
the earlier code checkpoint, not reclassified as hardware traffic savings or a
new device screen-hash measurement.
