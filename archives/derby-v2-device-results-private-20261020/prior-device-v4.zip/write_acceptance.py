#!/usr/bin/env python3
"""Summarize an already strictly verified local trial without device access."""
import hashlib
import json
from pathlib import Path
import re
import statistics
import sys

b = Path(__file__).resolve().parent
v = sys.argv[1]
assert v in ('baseline', 'native', 'batch')
r = json.loads((b / f'{v}-strict-result.json').read_text())
j = json.loads((b / f'{v}-fixed-result.json').read_text())
assert r['strict_pass'] and j['state'] == 'succeeded'
raw = (b / f'{v}-trial.log').read_bytes()
markers = {}
for name, tag in [('DERBY_FIXED_END',''), ('DERBY_DETAIL_EXIT',''),
                  ('APP_STOPPED','app'), ('HOME_READY','shell')]:
    found = []
    for i, line in enumerate(raw.decode('ascii').splitlines(), 1):
        line = re.sub(r'\x1b\[[0-9;]*m', '', line)
        matches = (line.startswith(name + ' ') if name.startswith('DERBY') else
                   re.fullmatch(r'(?:I \([0-9]+\) ' + tag + r': )?' + name, line))
        if matches:
            found.append(i)
    assert len(found) == 1, name
    markers[name] = found
assert [x[0] for x in markers.values()] == sorted(x[0] for x in markers.values())
work = [int(x['work_us']) for x in r['coarse']['repetitions']]
a = {'accepted_scope': 'one fresh flash boot, one fixed diagnostic job, three dependent replays',
     'strict_pass': True, 'source_commit': r['source_commit'], 'source_tree': r['source_tree'],
     'measurement_job': r['job_id'], 'finished_utc': j['finished'], 'protocol': r['protocol'],
     'plan_terminal_contract': 'end_owner_exit_stop_home_v2',
     'readback_terminal_contract': r['terminal_contract'], 'terminal_success_verified': True,
     'raw_sha256': hashlib.sha256(raw).hexdigest(), 'raw_bytes': len(raw),
     'markers_lines_1based': markers,
     'valid': [x['valid'] for x in r['coarse']['repetitions']],
     'quality': [x['quality'] for x in r['coarse']['repetitions']],
     'work_us': work, 'work_median_us': statistics.median(work),
     'device_boots': 1, 'dependent_replays': 3, 'independent_replay_trials': False,
     'quiet_close_basis': 'v2 receipt after quiet boundary and succeeded after confirmed close',
     'physical_lcd_attested': False, 'target_off_overhead_control': False,
     'old_90b9_failure_preserved': True}
(b / f'{v}-acceptance.json').write_text(json.dumps(a, indent=2) + '\n')
print(json.dumps({'variant': v, 'strict_pass': True, 'markers': markers, 'work_us': work}))
