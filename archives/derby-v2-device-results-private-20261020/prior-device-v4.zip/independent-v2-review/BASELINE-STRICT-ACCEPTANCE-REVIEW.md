# v2 baseline strict acceptance — independent review

Reviewed UTC: 2026-10-20T01:13:32.563056+00:00

**PASS for the saved baseline v2 verified-flash chain and complete strict trial. No unresolved acceptance finding within this scope.** This review performed local file reads and host parsing only; it made no live MCP/device/USB request, execution, retry or repository change.

The chain names frozen baseline `37af4225ad329aac4c5e79c880d7d69760b770be` / tree `7753c5c8919ee36c24080ce08102438a285da6f2`. The registered build was already independently checked as detail ON with required native owner EXIT. Flash plan/execute/result and manifest binding agree on app BIN `63f35801715ce8f211a7ded14c138f1e9a6a40415bc39170660f92c779743e7d` and ELF `e2e49a8637d0ef0ee3c7f839c7323f76d5d230e66e474216419a7ba21f7c3a3b`.

The primary saved flash server response (baseline-flash-logs-007.json) reports full-segment SHA256 readback verification, passive boot verification and expected-artifact boot observation. It matches the normalized receipt. Flash finished before trial creation; flash and trial plans/binding share device fingerprint, lease session and broker epoch `62c7885ab3f34ce6b9fc6973754c85f2`. Job/plan IDs and hashes match their execute/results. This separate recorded flash/ownership chain is the source/build link: trial configured_expected_firmware_sha256 and installed_boot_source_image=unverified are not treated as image authentication.

The two terminal contract strings are validated **separately and exactly**: immutable plan `pocketjs-derby-fixed-v2` / `end_owner_exit_stop_home_v2`; readback envelope `owner_exit_v2`, terminal_success_verified=true, no validation_error. They are distinct schema fields, not strings silently normalized into one another. The actual raw END/EXIT/STOP/HOME sequence independently supplies the completion evidence. The plan's older owner-exit wire commit identifies unchanged runtime/wire code; the final source differs only in the previously reviewed proof helper repair. The parent's MCP-source line inspection was not repeated through an external API here.

The raw file is byte-identical to strict base64 decoding of the broker envelope: **30,931 bytes**, SHA256 `8dca87258c207e6aceb2f373f8ef99cf59e5c81a6576ecca1c99d7686463662a`. Transport is complete, 87,918 ms, all gap/truncation/partial-tail/disconnect/reset/refusal/overflow flags false. Maximum complete line is 575 bytes, below the 1,024-byte limit; total remains below 64 KiB / 200 seconds. No raw prefix, unrelated log, error or suffix was removed.

Independent parse_collected and the exact clean checkout's parse_detail(expected=True), with expected-ON established by the verified build, pass and reproduce both the broker coarse result and saved strict coarse/detail structures exactly. Variant is baseline; three complete dependent repetitions each have 26 stages and 13 events. Identity, work counters, unsigned schema, detail totals/pairs, accounting and quality gates pass.

| Terminal | One-based raw line |
|---|---:|
| whole END | 237 |
| owner EXIT, same session and clean=1 | 238 |
| APP_STOPPED, correct IDF tag | 240 |
| HOME_READY, correct IDF tag | 241 |

There is exactly one of each in that order. The complete raw stream passes the existing fatal/hook-error checks, including text after HOME. In-memory copies with a late InternalError after HOME, missing EXIT or another EXIT session are all rejected; these copies were never substituted for the retained capture. Observed work_us are 6,775,160 / 6,772,381 / 6,767,447.

Limits remain: one collected firmware session with three dependent replays, no target detail-OFF overhead control, no physical LCD pixel verification or runtime heap/stack high-water measurement, and no native/batch acceptance from this baseline result. Logical byte counters are not bus traffic and elapsed scopes include preemption/waits. This review authorizes no next execution; later variants remain the parent's formally gated workflow.

The old raw failure remains unchanged (independently rehashed as `c25c11fc9a04e73a430291d202f00fceca3e94748976ec37a5604e9e4d66b3d5`) and remains FAIL. Reproduction: review_baseline_v2.py. Structured bindings, input hashes and negative cases: BASELINE-STRICT-ACCEPTANCE-REVIEW.json. Raw/receipts remain private.
