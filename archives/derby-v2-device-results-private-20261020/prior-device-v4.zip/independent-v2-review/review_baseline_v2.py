"""Private, local-only independent receipt/raw analysis. No device/API actions."""
from pathlib import Path
import base64,datetime,hashlib,json,re,subprocess,sys
R=Path(__file__).resolve().parent.parent;E=Path(__file__).resolve().parent
repo=Path('/workspace/derby-detail-recovery');expected_head='37af4225ad329aac4c5e79c880d7d69760b770be';expected_tree='7753c5c8919ee36c24080ce08102438a285da6f2'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==expected_head
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True).strip()
sys.path.insert(0,str(repo/'tools/games'))
from derby_fixed_result import parse_collected
from derby_detail_result import parse_detail
read=lambda n:json.loads((R/n).read_text())
build=read('baseline-source-build-proof.json');flash=read('baseline-flash-receipt.json');flashplan=read('baseline-flash-plan.json');flashjob=read('baseline-flash-result.json');flash_execute=read('baseline-flash-execute.json');plan=read('baseline-fixed-plan.json');job=read('baseline-fixed-result.json');execute=read('baseline-fixed-execute.json');stored=read('baseline-strict-result.json');server=read('baseline-flash-logs-007.json');trial=job['fixed_trial'];fp=flashplan['plan'];tp=plan['plan'];binding=trial['binding'];proof=build['proof']
assert build['source']['commit']==expected_head and build['source']['tree_sha1']==expected_tree
assert proof['detail_measurement']['mode']=='ON' and 'df_detail_exit_record' in proof['fixed_workload']['native_symbols']
assert flash['job']==flashjob and flash['plan']==flashplan
assert flashjob['state']=='succeeded' and flashjob['result']=='firmware_flash_completed'
assert flashjob['id']==fp['job_id']==flash_execute['id'] and flashjob['plan_hash']==flashplan['plan_hash']==flash_execute['plan_hash']
assert fp['build_job_id']==build['job']['id']
assert hashlib.sha256(json.dumps(build['manifest'],sort_keys=True,separators=(',',':')).encode()).hexdigest()==fp['manifest_sha256']
assert fp['expected_app_bin_sha256']==proof['artifacts']['cardputer_pocketjs.bin']['sha256']
assert fp['expected_elf_sha256']==proof['artifacts']['cardputer_pocketjs.elf']['sha256']
summary=server['flash_summary'];assert summary['readback_verified'] and summary['passive_boot_verified'] and summary['boot_observed'] and summary['boot_log_matches_expected_artifact']
assert summary['verification_basis']=='full_segment_sha256_readback_and_boot_elf_prefix'
assert all(summary[k]==v for k,v in flash['summary'].items())
assert summary['observed_elf_sha256_prefix']==fp['expected_elf_sha256'][:len(summary['observed_elf_sha256_prefix'])]
assert job['id']==tp['job_id']==execute['id']==binding['job_id']
assert job['plan_hash']==plan['plan_hash']==execute['plan_hash']==binding['plan_hash']
assert job['state']=='succeeded' and job['stage']=='serial_close' and job['result']=='derby_fixed_trial_verified'
assert tp['protocol']=='pocketjs-derby-fixed-v2'
assert tp['fixed_workload']['terminal_contract']=='end_owner_exit_stop_home_v2'
assert trial['terminal_contract']=='owner_exit_v2' and trial['terminal_success_verified'] is True
assert trial['available'] is True and trial['valid'] is True and trial['validation_error'] is None
assert tp['fixed_workload']['max_seconds']==200 and tp['fixed_workload']['max_bytes']==65536 and tp['fixed_workload']['max_line_bytes']==1024 and tp['fixed_workload']['repetitions']==3 and tp['fixed_workload']['retry']==0
assert fp['broker_epoch']==tp['broker_epoch']==binding['broker_epoch']=='62c7885ab3f34ce6b9fc6973754c85f2'
assert fp['session_id']==tp['session_id']
assert fp['device_fingerprint']==tp['device_fingerprint']==binding['device_fingerprint']
assert fp['device']==tp['device'] and fp['backend']==tp['backend']=='serial'
assert flashjob['finished']<job['created']<job['finished']
raw=(R/'baseline-trial.log').read_bytes();receipt=trial['receipt']
assert raw==base64.b64decode(trial['raw_base64'],validate=True)
assert hashlib.sha256(raw).hexdigest()=='8dca87258c207e6aceb2f373f8ef99cf59e5c81a6576ecca1c99d7686463662a'
assert len(raw)==30931 and raw.endswith(b'\n') and all(len(l)+1<=1024 for l in raw.split(b'\n')[:-1])
coarse=parse_collected(raw,receipt);detail=parse_detail(raw.decode('ascii'),expected=True)
assert coarse['variant']=='baseline' and len(detail)==len(coarse['repetitions'])==3
assert detail==stored['detail'] and coarse==stored['coarse']==trial['parsed']
assert stored['source_commit']==expected_head and stored['source_tree']==expected_tree and stored['build_job_id']==build['job']['id']
assert stored['receipt']==receipt and stored['session']==coarse['session']==binding['device_reported_session']
lines=raw.decode('ascii').splitlines();plain=[re.sub(r'\x1b\[[0-9;]*m','',l) for l in lines]
marker=lambda l,t,p:re.fullmatch(r'(?:I \([0-9]+\) '+t+': )?'+p,l) is not None
positions={'END':[i+1 for i,l in enumerate(lines) if l.startswith('DERBY_FIXED_END ')],'EXIT':[i+1 for i,l in enumerate(lines) if l.startswith('DERBY_DETAIL_EXIT ')],'STOP':[i+1 for i,l in enumerate(plain) if marker(l,'app','APP_STOPPED')],'HOME':[i+1 for i,l in enumerate(plain) if marker(l,'shell','HOME_READY')]}
assert all(len(x)==1 for x in positions.values()) and positions['END'][0]<positions['EXIT'][0]<positions['STOP'][0]<positions['HOME'][0]
negative=[]
for name,text in [('late-fault-after-HOME',raw.decode('ascii')+'InternalError: interrupted\n'),('missing-owner-EXIT','\n'.join(l for l in lines if not l.startswith('DERBY_DETAIL_EXIT '))+'\n'),('wrong-owner-session',raw.decode('ascii').replace('DERBY_DETAIL_EXIT v=1 session=1','DERBY_DETAIL_EXIT v=1 session=2'))]:
 try:parse_detail(text,expected=True)
 except ValueError as error:negative.append({'case':name,'rejected':True,'reason':str(error)})
 else:raise AssertionError('accepted synthetic negative '+name)
inputs=['baseline-source-build-proof.json','baseline-flash-plan.json','baseline-flash-execute.json','baseline-flash-result.json','baseline-flash-receipt.json','baseline-flash-logs-007.json','baseline-fixed-plan.json','baseline-fixed-execute.json','baseline-fixed-result.json','baseline-strict-result.json','baseline-trial.log']
report={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pass':True,'scope':'Independent saved baseline v2 verified-flash/receipt/raw strict acceptance only; no direct physical observation or image authentication from trial bytes alone.','source_commit':expected_head,'source_tree':expected_tree,'plan_terminal_contract':tp['fixed_workload']['terminal_contract'],'readback_terminal_contract':trial['terminal_contract'],'raw_bytes':len(raw),'raw_sha256':receipt['sha256'],'duration_ms':receipt['duration_ms'],'max_line_bytes':max(len(l) for l in raw.splitlines(keepends=True)),'terminal_line_positions':positions,'record_counts':{'repetitions':len(detail),'stages_per_rep':[len(x['stages']) for x in detail],'events_per_rep':[len(x['events']) for x in detail]},'work_us':[int(x['work_us']) for x in coarse['repetitions']],'same_device_session_epoch_chain':True,'verified_build_detail_ON':True,'server_readback_verified':True,'configured_hash_is_not_image_authentication':True,'synthetic_negative_cases_on_in_memory_copies':negative,'input_sha256':{n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in inputs},'parser_sha256':hashlib.sha256((repo/'tools/games/derby_detail_result.py').read_bytes()).hexdigest(),'not_established':['physical LCD correctness','runtime heap/stack high-water','target OFF overhead control','three independent boots','native or batch acceptance'],'no_MCP_USB_device_repo_operation':True}
(E/'BASELINE-STRICT-ACCEPTANCE-REVIEW.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:report[k] for k in ['pass','raw_bytes','raw_sha256','terminal_line_positions','work_us']}))
