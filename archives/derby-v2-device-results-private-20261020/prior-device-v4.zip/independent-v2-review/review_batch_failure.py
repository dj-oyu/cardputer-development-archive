"""Local-only source/build/flash/strict review. Never invokes device/MCP tools."""
from pathlib import Path
import argparse,base64,datetime,hashlib,json,re,subprocess,sys
p=argparse.ArgumentParser();p.add_argument('--variant',choices=['native','batch'],required=True);p.add_argument('--raw-sha256',required=True);p.add_argument('--raw-bytes',type=int,required=True);a=p.parse_args()
R=Path('/workspace/derby-evidence/device-v2-20261020');E=Path(__file__).resolve().parent;v=a.variant
head,tree={'native':('92e70b7fbb2c15d99734a518096dffdf046d2ae3','24f0575743c7de7d4873c531221db6e1fcf1f14f'),'batch':('ea64b0ec9c176f852c853cb10142581ee527d7fc','63bf0b2ee03168230de588f2a038e3e694b1d4d4')}[v]
repo=Path('/workspace/derby-detail-'+v);assert subprocess.check_output(['git','rev-parse','HEAD','HEAD^{tree}'],cwd=repo,text=True).splitlines()==[head,tree];assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True).strip()
sys.path.insert(0,str(repo/'tools'));sys.path.insert(0,str(repo/'tools/games'))
from record_verification import FIXED_REQUIRED,FIXED_SYMBOLS,DETAIL_FIXED_SYMBOLS,DETAIL_REQUIRED,TELEMETRY_SYMBOLS,MEASURE_SYMBOLS
from derby_fixed_result import parse_collected
from derby_detail_result import parse_detail
inputs={}
def load(name):
 path=R/(v+'-'+name+'.json');raw=path.read_bytes();inputs[path.name]=hashlib.sha256(raw).hexdigest();return json.loads(raw)
sp,se,sr,bp,be,bj,build=[load(n) for n in ['source-plan','source-execute','source-result','build-plan','build-execute','build-result','source-build-proof']];src=sr['diagnostic']['source'];manifest=build['manifest'];proof=build['proof']
assert sr['state']=='succeeded' and sr['result']=='source_snapshot_fetched_no_build_no_flash';assert sp['result']['plan_hash']==se['plan_hash']==sr['plan_hash'];assert sp['request']['job_id']==sp['result']['plan']['job_id']==se['id']==sr['id'];assert sp['request']['source_commit']==sp['result']['plan']['source_commit']==src['commit']==head;assert src['tree_sha1']==tree and build['source']==src
assert bj==build['job'] and bj['state']=='succeeded' and bj['result']=='firmware_build_succeeded_no_flash';bplan=bp['result']['plan'];assert bj['id']==bplan['job_id']==be['id']==manifest['build_job_id'];assert bj['plan_hash']==bp['result']['plan_hash']==be['plan_hash']==manifest['build_plan_hash'];assert bplan['source_provenance']==manifest['source_provenance'];assert bplan['source_receipt']==bp['request']['source_receipt']==src['source_receipt'];assert all(bplan['source_provenance'][k]==src[k] for k in ['commit','tree_sha1','source_sha256','submodules'])
primary_verified=[];logged_proofs=[]
for path in sorted(R.glob(v+'-build-logs-*.json')):
 raw=path.read_bytes();d=json.loads(raw)
 if d.get('artifact_status')=='verified':assert d['manifest']==manifest;primary_verified.append(path.name);inputs[path.name]=hashlib.sha256(raw).hexdigest()
 for e in d.get('entries',[]):
  prefix='DERBY_DIAGNOSTIC_BUILD_PROOF '
  if e['text'].startswith(prefix):assert json.loads(e['text'][len(prefix):])==proof;logged_proofs.append({'file':path.name,'sequence':e['sequence']});inputs[path.name]=hashlib.sha256(raw).hexdigest()
assert primary_verified and logged_proofs and load('diagnostic-proof')==proof
assert manifest['idf_version']=='6.0.1' and manifest['target']=='esp32s3';assert proof['fixed_workload']['mode']==proof['detail_measurement']['mode']==proof['build_measure']['measure_mode']==proof['build_mode']['telemetry_mode']=='ON';syms=set(proof['fixed_workload']['native_symbols']);assert FIXED_REQUIRED|DETAIL_FIXED_SYMBOLS<=syms<=FIXED_SYMBOLS|DETAIL_FIXED_SYMBOLS;assert DETAIL_REQUIRED<=set(proof['detail_measurement']['native_symbols']);assert set(proof['build_mode']['native_symbols'])==TELEMETRY_SYMBOLS and set(proof['build_measure']['native_symbols'])==MEASURE_SYMBOLS;assert not proof['hardware_tested'] and proof['build_mode']['elf_embedded_play_verified'];assert proof['build_mode']['cmake_cache_sha256']==proof['build_measure']['cmake_cache_sha256'];seed=proof['comparison_seed'];assert seed['mode']=='fixed' and seed['hardware_seed']=='2545F491' and seed['elf_embedded_view_verified'] and seed['elf_seed_symbol_verified']
artifacts={x['name']:x for x in manifest['artifacts']}
for n,x in proof['artifacts'].items():assert artifacts[n]['bytes']==x['bytes'] and artifacts[n]['sha256']==x['sha256']
fr,fp,fe,fj=[load(n) for n in ['flash-receipt','flash-plan','flash-execute','flash-result']];fplan=fp['plan'];assert fr['job']==fj and fr['plan']==fp;assert fj['state']=='succeeded' and fj['result']=='firmware_flash_completed';assert fj['id']==fplan['job_id']==fe['id'] and fj['plan_hash']==fp['plan_hash']==fe['plan_hash'];assert fplan['build_job_id']==bj['id'];assert hashlib.sha256(json.dumps(manifest,sort_keys=True,separators=(',',':')).encode()).hexdigest()==fplan['manifest_sha256'];assert fplan['expected_app_bin_sha256']==proof['artifacts']['cardputer_pocketjs.bin']['sha256'] and fplan['expected_elf_sha256']==proof['artifacts']['cardputer_pocketjs.elf']['sha256']
primary_flash=[]
for path in sorted(R.glob(v+'-flash-logs-*.json')):
 raw=path.read_bytes();d=json.loads(raw)
 if 'flash_summary' in d:
  summary=d['flash_summary'];assert all(summary[k]==value for k,value in fr['summary'].items());assert summary['readback_verified'] and summary['passive_boot_verified'] and summary['boot_observed'] and summary['boot_log_matches_expected_artifact'];assert summary['verification_basis']=='full_segment_sha256_readback_and_boot_elf_prefix';assert summary['observed_elf_sha256_prefix']==fplan['expected_elf_sha256'][:len(summary['observed_elf_sha256_prefix'])];primary_flash.append(path.name);inputs[path.name]=hashlib.sha256(raw).hexdigest()
assert primary_flash

plan,execute,job,recheck,status,release=[load(n) for n in ['fixed-plan','fixed-execute','fixed-result','failure-job-recheck','failure-device-status','idle-release']];tplan=plan['plan'];trial=job['fixed_trial'];binding=trial['binding'];diag=job['diagnostic']
assert job['state']==recheck['state']=='needs_review' and job['result']==recheck['result']=='serial_fault_marker';assert job['stage']=='serial_close' and diag['code']=='serial_fault_marker' and diag['serial_close_confirmed'] is True
assert job['id']==tplan['job_id']==execute['id']==binding['job_id'];assert job['plan_hash']==plan['plan_hash']==execute['plan_hash']==binding['plan_hash'];assert tplan['protocol']=='pocketjs-derby-fixed-v2' and tplan['fixed_workload']['terminal_contract']=='end_owner_exit_stop_home_v2';assert trial['terminal_contract']=='owner_exit_v2' and trial['terminal_success_verified'] is False and trial['valid'] is False
assert all(diag[k] is False for k in ['workload_end_observed','owner_exit_observed','app_stopped_observed','home_ready_observed','partial_workload_is_terminal_success'])
assert fplan['session_id']==tplan['session_id'];assert fplan['device_fingerprint']==tplan['device_fingerprint']==binding['device_fingerprint'];assert fplan['broker_epoch']==tplan['broker_epoch']==binding['broker_epoch']=='62c7885ab3f34ce6b9fc6973754c85f2';assert fj['finished']<job['created']<job['finished']
raw=(R/'batch-fixed_trial-partial.log').read_bytes();inputs['batch-fixed_trial-partial.log']=hashlib.sha256(raw).hexdigest();assert len(raw)==a.raw_bytes==902 and inputs['batch-fixed_trial-partial.log']==a.raw_sha256;assert raw==base64.b64decode(trial['raw_base64'],validate=True);text=raw.decode('ascii');receipt=trial['receipt'];assert receipt['bytes']==len(raw) and receipt['sha256']==a.raw_sha256 and receipt['complete'] is False and receipt['gaps'] is True and receipt['truncated'] is True
assert "APP_LOAD play failed chunk 'play' did not compile: out of memory" in text and 'EVAL_ERROR' in text and 'START_FAILED ESP_FAIL' in text and 'OOM n=1 first_req=9944 used=139340' in text;assert not any(x in text for x in ['DERBY READY','DERBY_FIXED','DERBY_DETAIL','APP_STOPPED','HOME_READY'])
rejections=[]
for name,fn in [('receipt',lambda:parse_collected(raw,receipt)),('strict_detail',lambda:parse_detail(text,expected=True))]:
 try:fn()
 except ValueError as e:rejections.append({'gate':name,'rejected':True,'reason':str(e)})
 else:raise AssertionError('failed batch accepted')
assert status['ok'] and status['active_job'] is None and status['profile_active_job'] is None;assert all(status[k]==0 for k in ['queue_depth','wait_queue_depth','profile_queue_depth']);assert all(status[k] is False for k in ['ownership_uncertain','profile_uncertain','execution_uncertain']);assert status['safety']['current_resource_uncertain'] is False;assert release=={'ok':True,'released':True}
pat=re.compile(r'APP_LOAD (\w+) bytes=(\d+) compile_us=(\d+) run_us=(\d+) used=(\d+)>(\d+)>(\d+)');loading={}
for variant in ['baseline','native','batch']:
 path=R/(variant+'-'+('fixed_trial-partial.log' if variant=='batch' else 'trial.log'));s=path.read_text();loading[variant]=[{'chunk':m[1],'source_bytes':int(m[2]),'used_before':int(m[5]),'used_after_compile':int(m[6]),'used_after_run':int(m[7])} for m in pat.finditer(s)]
source_hashes={}
for variant,suffix in [('baseline','recovery'),('native','native'),('batch','batch')]:
 root=Path('/workspace/derby-detail-'+suffix);source_hashes[variant]={f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in ['main/app_session.c','main/pocket/pocket_app_load.c','components/pocketjs_guest/src/guest.c','components/quickjs-ng/quickjs-ng/quickjs.c']}
assert source_hashes['baseline']==source_hashes['native']==source_hashes['batch']
report={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'result':'CONFIRMED_FAILED_batch_startup_play_compile_OOM','source_commit':head,'source_tree':tree,'source_build_flash_chain_verified':True,'primary_server_artifact_verified_files':primary_verified,'primary_logged_proofs':logged_proofs,'primary_flash_summary_files':primary_flash,'artifacts':proof['artifacts'],'job_state':job['state'],'job_result':job['result'],'serial_close_confirmed':True,'idle_without_current_uncertainty':True,'lease_released':True,'raw_bytes':len(raw),'raw_sha256':a.raw_sha256,'measured_windows':0,'terminal_success_verified':False,'OOM_canary':{'count':1,'first_req':9944,'first_used':139340,'normal_source_heap_limit':163840,'first_used_plus_request':149284,'reason_split_present_in_raw':False},'MCP_caught_diagnostic':True,'MCP_GUI_visibility':'not observed','host_parser_rejections':rejections,'loading_comparison':loading,'budget_loader_guest_engine_source_sha256':source_hashes,'input_sha256':inputs,'scope':'Local saved evidence/code reads and host parsing only; no source/budget change, instrumentation, runtime test, device/MCP/USB/reset/serial/flash action.'}
(E/'BATCH-FAILURE-REVIEW.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:report[k] for k in ['result','source_build_flash_chain_verified','job_state','job_result','raw_bytes','raw_sha256','MCP_caught_diagnostic','MCP_GUI_visibility','idle_without_current_uncertainty','lease_released','host_parser_rejections']}))
