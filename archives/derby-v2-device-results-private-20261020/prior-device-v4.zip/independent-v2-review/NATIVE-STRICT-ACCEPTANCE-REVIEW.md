# v2 native strict acceptance — independent review

Reviewed UTC: 2026-10-20T01:29:06.884495+00:00

**PASS for the recorded native source/build/verified-flash chain and complete strict trial. No unresolved finding within this scope.** Local file reads and host analysis only; no MCP/device/USB action, retry, repository or GitHub change.

Frozen native head `92e70b7fbb2c15d99734a518096dffdf046d2ae3` / tree `24f0575743c7de7d4873c531221db6e1fcf1f14f` matches the clean local checkout, source result and registered build provenance. Source receipt/submodules, prepare/execute/result IDs and plan hashes are consistent. Registered source/build jobs reached their successful terminal states.

Primary build response **native-build-logs-020.json** has artifact_status=verified and the identical manifest. Its actual diagnostic proof at sequence2105 equals native-diagnostic-proof.json and the combined build receipt. Detail/fixed/measure/telemetry are all ON, required dd_ APIs and df_detail_exit_record are present; exact fixed-symbol rules, embedded play/view and fixed seed proof pass.

| Artifact | Bytes | Recorded SHA256 |
|---|---:|---|
| app BIN | 2,296,864 | `4c5a0de77860fc615bcdd8885440566586e89ac6fbb587e71dcb49a349781063` |
| app ELF | 20,045,892 | `b77239b7a861a236c28660851fc694bc3450fe8e6301a90b37bf4618ea281166` |

Manifest, paired diagnostic proof and flash plan agree on these hashes and sizes; canonical manifest hash matches flash prepare. Primary saved flash summary reports full-segment SHA256 readback, expected-artifact boot observation and passive boot verification, and matches the normalized receipt. Flash and trial use the same device fingerprint, lease session, backend and epoch `62c7885ab3f34ce6b9fc6973754c85f2`. Source→build→flash→trial timestamps are ordered; job/execute/plan bindings match. Trial configured_expected_hash and installed-image-unverified fields are not substituted for the separate verified flash/ownership chain. No full binary download or local rehash was performed.

The immutable v2 plan requires `end_owner_exit_stop_home_v2`; the readback envelope separately requires `owner_exit_v2`, terminal_success_verified=true and no validation_error. Both exact values are checked without broadening the contract. The raw terminal sequence independently agrees.

Raw capture: **30,914 bytes**, SHA256 `8241cfca31b886462ad4ac485f2d583771db3dcfa281d966dac973bfd15c69a1`, identical to validated base64 decoding of the broker receipt. Complete, 87,599 ms, maximum full line 577 bytes, all gap/overflow/truncation/partial-tail/disconnect/reset/refusal flags false; 200s/64KiB/1024B limits pass.

Independent parse_collected and the exact repo's parse_detail(expected=True), based on verified detail ON, reproduce saved strict coarse/detail and broker parsed structures exactly. Variant is native, all three repetitions valid/quality0, each with 26 stages and 13 events. Known native work, fixture identity, schema, totals, pairs and accounting pass. Whole END line237 → same-session clean owner EXIT238 → correctly tagged STOP240 → HOME241 occur exactly once in order. Complete-stream fatal/hook-error rejection is preserved. In-memory copies with an InternalError after HOME, removed EXIT or another EXIT session are rejected; actual raw bytes were never changed.

Observed work_us: **6,717,191 / 6,711,418 / 6,725,544**. This is one collected native session with three dependent replays, not three independent boots, target OFF overhead control, physical LCD proof or runtime memory high-water evidence. No native/baseline performance conclusion is made here; elapsed scopes include preemption/waits and logical bytes are not bus traffic. Batch acceptance remains a separate step. The old failed capture and prior proof-failed CI remain historical FAIL.

Structured artifact/raw/input hashes: NATIVE-STRICT-ACCEPTANCE-REVIEW.json. Reproduce locally with review_variant_v2.py --variant native --raw-sha256 8241cfca31b886462ad4ac485f2d583771db3dcfa281d966dac973bfd15c69a1 --raw-bytes 30914. Evidence remains private; this review delegates no execution or retry.
