独立レビュー結果: 保存された5ケースは、64-bitホストの対象chunk compile中のゲストlive payload peak低下と、試験したfixed fixtureの出力・work counters維持を支持する。実機OOM再現・解消、全JS意味の同一性、実機性能の証拠にはならない。

対象は frozen baseline `37af4225ad329aac4c5e79c880d7d69760b770be`、native `92e70b7fbb2c15d99734a518096dffdf046d2ae3`、batch `ea64b0ec9c176f852c853cb10142581ee527d7fc`。3worktreeはcleanで変更していない。調査script SHA256は `3f7855743a69532ba9c5404e6260a22213bb5c39015182747cc811ab8127280c`。原型生成appと再使用QuickJSオブジェクトは、対応する既存exit-fix-fast保存物とbyte一致を確認した。copied loader/harnessも宣言されたtrace追加だけである。

| 保存ケース | play compile peak (B) | 追加chunk compile peak (B) | 独立再解析 |
|---|---:|---:|---|
| baseline original | 184684 | — | PASS |
| native original | 184680 | — | PASS |
| batch original | 186360 | — | PASS |
| batch defer-buffer | 185088 | — | PASS |
| batch split-controller (strict修正版) | 173684 | detail_ctl 172944 | PASS |

batch original比でdefer-bufferは1272B、split-controllerの両compile phase最大値は12676B低い。これは`allocator_peak`という同一ホストモデル内の比較である。`used`のcompile後残量や、ESP32の実占有量とは別の値。

全5保存rawをresultのSHA256、全COMPILE_TRACE_END項目、生成JSの長さ/hash、DEVICE_WINDOWと照合した。現frozen `parse_trial(..., transport_complete=True)`、`parse_detail(..., expected=True)`、`check_result`でそれぞれ3repが通過した。各repは120contexts、4975draws、input hash `986b2e6e027af00d`、procedural pixel hash `c1b0fdbde748d0de`、panel hash `cec4b765a2794b14`を維持し、既知work/race-finish、END→EXIT→STOP→HOMEの受入条件も通る。reviewerはbinaryを再実行していない。

候補差分を文字列で確認した。defer-bufferはPAN末尾の`const rb = new Float64Array(40)`を`let rb`にし、playのloadが返った直後に確保するだけ。split-controllerはplay末尾2695BのDF controllerを新chunkへ移し、元のstrict directiveを加え、play直後にloadする。最終新chunkは2709B、SHA256 `809a807b724900c568f91b466010b2a8a39b8c9c0d9315c068013ac5fb7e955a`。最初の分割候補でstrict directiveが落ちた点は親へ報告し、親が候補だけ修正・再走行した。旧sloppy候補/resultはsupersededであり、今回の結論はstrict修正版へbindする。

traceの計数は`test_derby_host.c:94–113`のhost libc malloc/reallocの上にTLSF長丸めを施したゲストlive payload。phase開始時にlive値へresetし、`pk_count`で最大を更新する。loaderのcompile/run前後だけを囲む。libc metadata、reallocの一時的な旧/新領域同時占有、watch entryのparseや全起動の最大、ESP capability heap/block cache、native/shared system heap、fragmentationを測っていない。hostはx86-64、quota524288Bであり、実機の160KiB予算・firmware namespace構築・物理heapを再現しない（`test_derby_host.c:1080–1088`、PRELUDE）。original batch自体がhostで成功しているので、実機失敗の再現試験ではない。定量値をESPへ換算したり、quota/物理heap/断片化の原因を確定したりできない。

意味維持の結論は試験した固定seed/camera、3rep、draw/race/pixelとwork countersに限る。deferはbuffer初期化・確保失敗の時点を変え、splitはchunk境界・load状態を増やす。全入力・全例外経路・通常OFFまで同一とは主張しない。生成コピーだけの探索候補であり、production generator、chunk registry/proof、全3版同形適用、ON/OFF、通常host、target link/資源の更新・受入は未実施。

実機の凍結batch失敗（play compile out of memory、needs_review/serial_fault_marker、測定窓0）は未解決のまま。現在halt/idle・lease releaseの保存事実と失敗jobを区別する。実機OOM解消も、次の実機実行許可も、このレビューからは導かない。reviewerによるroot変更・MCP操作・USB/serial/reset/flashはない。

構造化結果・入力ファイル長/hashは `COMPILE-CANDIDATES-REVIEW.json` に保存した。
