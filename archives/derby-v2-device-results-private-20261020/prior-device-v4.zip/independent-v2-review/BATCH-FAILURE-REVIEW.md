# Batch v2 failure — independent local review

Reviewed UTC: 2026-10-20T01:53:07.104134+00:00

**MCP caught and stored the firmware startup error. Batch is FAILED, with zero measured windows.** Whether the MCP GUI displayed that stored diagnostic is **not observed** in this local evidence. The user's reported device APP ERROR is consistent with the saved startup failure, but this reviewer did not observe either UI.

## Exact failure and capture

Frozen batch head `ea64b0ec9c176f852c853cb10142581ee527d7fc`, tree `63bf0b2ee03168230de588f2a038e3e694b1d4d4`, matches the clean checkout and registered source/build provenance. Source/build succeeded; primary build response has artifact_status=verified and the logged mandatory proof agrees with the manifest. All four diagnostic modes are ON and required EXIT symbols exist. The saved formal flash plan/result and primary full-segment SHA256 readback/passive-boot summary bind the expected app BIN `c696bcda9def6cfc25fb9a99d309dc8412edcee19c766629cd2bb4697c59f5de` and ELF `6cd208f176e0e1e74642b11bf3f5314fc2d8297013beb600308c9de995683e1f` to this build. Device/session/epoch and flash→trial order agree. Build/link/readback success does not imply app startup success.

Job `derby-v2-batch-fixed-ea64b0ec-20261020`, finished **2026-10-20 01:43:53 UTC**, is `needs_review` / `serial_fault_marker`, stage serial_close. Its diagnostic identifies command enter, records the app-load fault, has all workload-END / owner-EXIT / APP_STOPPED / HOME_READY observations false, and serial_close_confirmed=true. The API envelope's ok=true describes a successful API response, not a passing workload.

Untouched workload capture: **902 bytes**, SHA256 `92b8e47e55c6aeeccc57e2e622154319b5c243499613418bb14b7020ca8232f6`; it exactly matches the broker's base64 bytes. Twelve captured lines include APP_ID, successful prog/view/scene/PAN loads, then **play did not compile: out of memory**, EVAL_ERROR, an OOM canary and START_FAILED ESP_FAIL. No DERBY READY, measurement summary, detailed record, END or EXIT appears. Failure is during startup compilation, before the 120-context measurement, not a measured performance result or reporting/watchdog failure.

The fixed receipt is incomplete, gaps=true/truncated=true, valid=false and terminal_success_verified=false. No success is inferred from the complete individual lines or closed port. Independent parse_collected rejects transport_quality; the unchanged strict detailed parser also rejects the missing repetitions/final record. These partial-capture flags are retained, not stripped to manufacture a result.

## Heap budget and canary interpretation

Budget and loader source are byte-identical across baseline/native/batch. `main/app_session.c:1466` sets the normal foreground guest to **163,840 bytes** heap, **20,480 bytes** JS/parser stack and prefer_psram=false; `components/pocketjs_guest/src/guest.c:674` installs the memory cap and :688 installs the stack limit. No budget or source was changed here. Compile failure is distinguished from top-level-run failure by `main/pocket/pocket_app_load.c:183–187` (JS_Eval COMPILE_ONLY) and :90–121 (load-error conversion). The successful-load used figures at :202 are after compilation/run; parser temporaries have already gone, so they are not compile peaks.

The canary reports **one rejection, first_req=9,944 and first_used=139,340**. `quickjs.c:1898–1909` stores the first rejection and separate quota/allocator counts. The quota tests and actual allocator-NULL tests call it separately at :1930–1939, :1960–1969 and :2016–2025. `components/pocketjs_guest/src/guest.c:1250–1256` passes this state to `main/app_session.c:216–235`, whose ordinary OOM log emits only count/request/used. It does **not** expose the quota/allocator split. The extra classification is only printed under POCKET_HEAPPROBE; fixed-workload CMake rejects that probe combination (`main/CMakeLists.txt:420–423`).

Under the normal 163,840-byte cap, **139,340 + 9,944 = 149,284**, below the quota; realloc's used-without-old quota condition is no stricter. Thus actual allocator NULL is a strong inference if the normal cap was active. The capture does not independently print the actual runtime cap, rejection-class counts or rejection-time free/largest blocks. A trace-build heap override also exists in source (`app_session.c:310–316,1474–1475`). This report therefore does **not** turn that inference into a definitive quota/allocator classification, and does not diagnose fragmentation or recommend raising a budget. ESP32 allocation uses internal-capability heap and optional small-block cache (`guest.c:349–415`); a shared native-heap or contiguous-allocation limitation is possible, not established by this canary alone.

## Comparison with accepted baseline/native startup

| Version | PAN source bytes | Used after PAN run | Play source bytes | Play startup |
|---|---:|---:|---:|---|
| baseline | 2,120 | 109,588 | 9,683 | compile/run succeeded |
| native | 2,120 | 109,564 | 9,683 | compile/run succeeded |
| batch | 2,302 | 111,084 | 9,683 | compile OOM |

All three verified embedded-play hashes are identical (`4c4a243639b85df2d1285c226373eb8bc966dac71ecceda8ce4daaee106547a0`). Batch enters play compilation with **1,496 / 1,520 bytes more held** than baseline/native after PAN. The batch transform adds 182 source bytes and a Float64Array(40), whose payload is 320 logical bytes (`tools/games/derby_runner_batch.py:15–35`). Object/compiler/atom costs are additional; the observed difference cannot be attributed to the payload alone. The failing request's exact compiler allocation site/peak is not available.

Host PASS did not prove this startup fits target DRAM. Ordinary fixed-host runs use 524,288 bytes; m32 sets 163,840 (`tools/games/run_derby_fixed.py:225–229`). Even m32 uses the host libc-backed, TLSF-rounded PEAK_MF allocator (`tools/games/test_derby_host.c:94–113`), not ESP capability heaps/block-cache/shared DRAM. It creates the context before setting the cap (:1080–1082), eagerly builds derby namespace (:1084–1088), and substitutes pocket namespace objects in PRELUDE (:1050–1060), including capabilities/memory/audio/storage behavior. ABI/accounting approximation and renderer/semantic coverage therefore do not establish real firmware namespace residency, allocation peaks, physical free space or fragmentation. No host fixture was rerun in this review.

## Stopped state and remaining blocker

Saved status shows active_job/profile_active_job=null, all queues zero, ownership/profile/execution/current-resource uncertainty false. Job recheck still preserves needs_review/serial_fault_marker and confirmed serial close. Saved release is exactly ok=true/released=true. This is a **caught, retained failure**, not current execution uncertainty or a denied action; history remains failed even though resources are idle.

Further batch measurement and the full three-version detailed comparison are blocked by this startup compile OOM. Baseline/native accepted data remain valid within their prior limits, but supply no batch window or target OFF overhead control. GUI rendering of the caught diagnostic remains unobserved. No reset, retry, new instrumentation, budget/source change, source/build/flash, MCP/device read, USB/serial or GitHub operation was performed by this reviewer.

Structured bindings, source/input hashes and parser rejection results: BATCH-FAILURE-REVIEW.json. Reproduction: review_batch_failure.py --variant batch --raw-sha256 92b8e47e55c6aeeccc57e2e622154319b5c243499613418bb14b7020ca8232f6 --raw-bytes 902. Raw/receipts remain private.
