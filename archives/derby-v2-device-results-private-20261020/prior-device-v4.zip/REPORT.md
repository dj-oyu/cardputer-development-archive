# DERBY WATCH 詳細計測：2版受入、batch起動OOMで停止

baseline/nativeは正式source/build/proof/flash/full readback/bootとv2有限計測のstrict受入までPASS。batchはsource/build/proof/flash/readback/bootに成功したが、アプリ起動時にplay chunkのコンパイルがOOMで失敗し、測定は始まっていない。3版実機比較は未完了。失敗後の新規serial接続・reset・flash・試験・recoveryは行わず停止した。

旧担当のWIPは取得できていない。コードは仕様から再構成したもので、旧コードと同一の復元とは主張しない。最適化は追加していない。

## 実機APP ERRORとMCPの対応

- 現在の実機：batch ea64b0ec9c176f852c853cb10142581ee527d7fc。最後のflash jobはderby-v2-batch-flash-ea64b0ec-20261020、01:43:10 UTC成功。BIN SHA256 c696bcda9def6cfc25fb9a99d309dc8412edcee19c766629cd2bb4697c59f5de。
- 測定job：derby-v2-batch-fixed-ea64b0ec-20261020、2026-10-20 01:43:49→01:43:53 UTC、needs_review / serial_fault_marker / serial_close。valid=false、terminal_success_verified=false。
- 保存rawにAPP_LOAD play did not compile: out of memory、EVAL_ERROR、OOM n=1 first_req=9944 used=139340、START_FAILED ESP_FAILを捕捉。実機uptimeは73063/73066/73067/73068ms。壁時計の正確なsubsecondは取得していない。timeoutではなくアプリ起動失敗。
- 部分rawは902B、SHA256 92b8e47e55c6aeeccc57e2e622154319b5c243499613418bb14b7020ca8232f6。complete=false、gaps/truncated=true。受信全体2831Bのうちコマンド前1929Bと後902Bを診断が区別する。902Bを全受信2831Bと取り違えない。
- DERBY READY・3 summaries・END/EXIT/STOP/HOMEは出ていない。MCPは失敗を保存している。GUI画面は未観測のため、GUI staleと診断非表示のどちらかは判断できない。
- serial_close_confirmed=true。失敗後device_statusのactive job/queueは空、current_resource_uncertain=false。idle leaseはok=true/released=trueで解放。needs_review履歴は残し、実行/所有不確実性とは区別した。インストール済みbatchは保持し、自動restoreしていない。

証拠：batch-fixed-result.json、batch-fixed_trial-partial.log、batch-failure-job-recheck.json、batch-failure-device-status.json、batch-idle-release.json、batch-failure.json。exact版parserは不完全transportを拒否し、強制completeでもthree_repetitions_and_final_record_requiredで拒否（batch-parser-rejection.json）。

## 版と受入範囲

| 版 | Draft PR / exact head | 結果 | work 3 dependent reps (ms) | median (ms) |
|---|---|---|---|---:|
| baseline | [PR21](https://github.com/dj-oyu/cardputer-adv-pocketjs/pull/21) / 37af4225ad329aac4c5e79c880d7d69760b770be | strict PASS | 6775.160 / 6772.381 / 6767.447 | 6772.381 |
| native | [PR22](https://github.com/dj-oyu/cardputer-adv-pocketjs/pull/22) / 92e70b7fbb2c15d99734a518096dffdf046d2ae3 | strict PASS | 6717.191 / 6711.418 / 6725.544 | 6717.191 |
| batch | [PR23](https://github.com/dj-oyu/cardputer-adv-pocketjs/pull/23) / ea64b0ec9c176f852c853cb10142581ee527d7fc | 起動OOM、測定未開始 | — | — |

各版は別のverified postflash bootから1計測job。受入2版の各3 repsは同起動/session内のdependent replayで、3独立boot試行や統計的優劣を示さない。serial-openによる追加resetはplanに含まれ得るため物理boot総数は独立計数していない。各source/build/flash/fixedは1回、実行retry0。native/batchは独立比較版で累積ではない。比較元exact commit：

- baseline 0c52600fc34deafbadc53bc48e4fc98931e404e4
- native 44f9c56121b5aab4fb2eca0fcf9fbe54d833a276
- batch 3a641d4d996938339b44fe735aba876ad031b3a2

## 詳細内訳（受入2版のみ）

[26段階のself/inclusive表](DETAILED-STAGES.md)、[全repの時間・calls CSV](stages.csv)、[論理bytes/回数CSV](logical-events.csv)、[機械可読集計](DETAILED-SUMMARY.json)を保存。batchの値をhost結果から補完していない。

| Stage | baseline self ms | native self ms |
|---|---:|---:|
| JS_FRAME | 964.324 | 963.726 |
| SIMULATION | 198.974 | 198.472 |
| POSE_PROJECTION | 347.257 | 348.998 |
| SORT | 48.444 | 47.860 |
| RUNNER | 346.071 | 340.490 |
| HUD | 124.808 | 123.648 |
| NATIVE_SERIES | 680.732 | 646.934 |
| VM_SETUP | 58.025 | 56.560 |
| VM_ZERO | 22.010 | 22.571 |
| VM_COPY | 19.710 | 19.448 |
| VM_VALIDATE | 48.957 | 48.267 |
| VM_MATCH | 119.814 | 118.122 |
| VM_RUN | 257.912 | 254.013 |
| SEGMENT_APPEND | 15.310 | 15.046 |
| RENDER_PREPARE | 36.398 | 36.628 |
| BACKDROP | 9.754 | 8.478 |
| COMPOSITE | 998.282 | 997.082 |
| TX_COPY | 12.798 | 12.761 |
| TX_SUBMIT | 22.096 | 22.044 |
| TX_REAP | 826.625 | 826.740 |

inclusiveは階層で重複するため合計しない。selfはnested scopeを除いたowner-task elapsedで、計測overhead、preemption、同期waitを含む。JSのpark待ちはscopeから除外する。TX_REAPは完了待ちelapsedで純SPI transfer時間ではない。JS_FRAME selfは制御・VM/binding・計測overhead等を含む残余で純JS演算だけを分離した値ではない。

受入2版の各repでVM_ZERO_BYTES=4,955,100（4975×996）、VM_CODE_COPY_BYTES=2,854,704、SEGMENT_COPY_BYTES=498,540、TX_COPY/PAYLOAD各7,776,000 logical bytes、TX_SUBMITS/REAPS各2040、FAILURES0。全13項目・全repはCSV参照。同じpixelsを異なる段階で数えるため合算して実memory/bus trafficと呼ばない。差分送信・copy削減は未実装。hostの前frame同値3,499,706/3,888,000pixels、449/2040stripも実機bus節約を証明しない。

## 受入証拠・検証限界

| 版 | raw bytes / SHA256 | END→EXIT→STOP→HOME 行 | 終了UTC |
|---|---|---|---|
| baseline | 30,931 / 8dca87258c207e6aceb2f373f8ef99cf59e5c81a6576ecca1c99d7686463662a | 237→238→240→241 | 2026-10-20 01:10:30 |
| native | 30,914 / 8241cfca31b886462ad4ac485f2d583771db3dcfa281d966dac973bfd15c69a1 | 237→238→240→241 | 2026-10-20 01:27:03 |

受入2版はcomplete=true、gap/overflow/truncated/partial_tail/disconnect/reset/refused=false、全3 reps quality0/valid1、26stage/13event、120contexts。同sessionのEND→EXIT→STOP→HOME、quiet境界・confirmed close・全streamのlate fault拒否を検証。rawを削除せずexact treeのparse_detail(expected=True)へ入力。独立reviewはindependent-v2-review/。旧90b9のEND後InternalError/APP ERROR試行はstrict全体FAILのまま保持。

plan protocol=pocketjs-derby-fixed-v2、plan terminal_contract=end_owner_exit_stop_home_v2、readback envelope terminal_contract=owner_exit_v2を個別照合。旧契約fallbackなし。exact source→登録build/proof（4 mode ON、seed2545F491、EXIT symbol必須、BIN/ELF hash一致）→全segment readback/boot→同lease/epoch/device fingerprint→trialの連鎖を保存。fixed receiptのconfigured hash / installed image unverified欄だけでimageを認証したとは主張しない。

同headの保存済CI29/29・実target ON/OFF proof6件とhost O2/ASan/UBSan ON/OFF12実行/36dependent windows、m32/SSE2 160KiBモデル、負例・lifecycle・描画hash証拠はcode-checkpoint.zipに含む。しかしhostモデルは実firmwareの全namespace・allocator・system memory状態を再現しない。batch実機のcompile OOMが発生した以上、host/CI PASSを実機起動PASSへ拡張しない。

未実施：有効なbatch実機詳細計測、同head target OFF overhead対照、独立boot反復、runtime heap/stack high-water、新しい実機描画hash取得。受入2版の物理LCD正常表示は独立確認していない。ユーザーのbatch APP ERROR目視報告は今回の捕捉失敗と整合する。通常PR19限定smokeとは別の受入範囲。

この実機試験フェーズで新しいpush/CI起動/main merge、直接USB、cache削除、認可/設定変更、broker再起動、暗黙restoreは行っていない。旧source-cache scan失敗は旧jobとして保持。新deployment/正式inventory/新source jobで進行した。metadata20→22tools不足は解消済み。通信エラー時は既存job/cursorの読取のみ回復し実行は再送しなかった。

## 保全・再現・残るブロッカー

code-checkpoint.zip（SHA256 2a118ca9f72e2764f56df663caec1d157c873223ec8d25e2cb22fc70d6e25ca7）に3専用branchの変更source/完全patch/commit bundle/host・CI証拠/旧FAILを含み、外側に今回の実機raw・receipt・解析・独立reviewを含む。SDK・全submodule履歴・MCPホストの実BIN/ELFバイトのdownloadは含まない。MCP retained artifacts/LKGは保護した。

再現は空の新destinationへ python3 restore_code.py --variant baseline --destination /workspace/restored-baseline、続けて python3 verify_v2_trial.py --variant baseline --repo /workspace/restored-baseline。集計は python3 summarize_v2.py。batchはwrapperで実際に復元しexact ea64b0ec/tree63bf0b2e・40変更file・完全patch hash一致を確認（complete-restore-smoke.log）。これはコード復元の検証でbatch実機PASSを意味しない。batch rawはbatch-parser-rejection.jsonの通り受入不可。SHA256SUMSは全収録fileのhash。外側ZIPのLibrary ID・version・hashは自己参照を避けV2-DEVICE-LIBRARY.jsonに保存。共有linkや生ログ公開なし。

残るブロッカーはbatch実機play compiler OOM。現jobはneeds_reviewで失敗確定、serial close/idle/releaseは確認済み、結果不明の実行は残っていない。原因の詳細切分けはlocal read-onlyで行い、実装変更・新head公開・新CI・実機再試験は親の次の判断を待つ。

## ホストでの原因切分け・修正候補

[起動メモリ比較と候補](local-compile-investigation/FINDINGS.md)を保存。別chunkへ分割したstrict-preserving候補は当該64bitホストのcompile phase live payload peakを186360Bから173684Bへ減らし、固定fixtureのwork/hash/calls/events一致を確認。実機OOM再現・解消の証明ではなく、凍結branchへは未適用。

親からGUIには01:47接続済み行があるとの報告を受けた。MCP rawで原因捕捉は確認済みで、GUIが原因を十分表示していない点とは別に扱う。こちらでGUI画面自体は観測していない。
