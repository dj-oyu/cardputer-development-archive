#!/usr/bin/env python3
"""Preserve complete source/evidence for two accepted trials and batch failure."""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile

d = Path(__file__).resolve().parent
b = d.parent
s = json.loads((d / 'DETAILED-SUMMARY.json').read_text())
assert s['all_three_accepted'] is False
assert s['accepted_variants'] == ['baseline', 'native']
for v in ('baseline', 'native'):
    a = json.loads((d / f'{v}-acceptance.json').read_text())
    assert a['strict_pass'] and a['terminal_success_verified']
    release = json.loads((d / f'{v}-idle-release.json').read_text())
    assert release['release']['released'] is True
failure = json.loads((d / 'batch-failure.json').read_text())
assert failure['state'] == 'needs_review' and failure['result'] == 'serial_fault_marker'
assert failure['strict_pass'] is False and failure['terminal_success_verified'] is False
assert failure['serial_close_confirmed'] is True and failure['retries'] == 0
assert json.loads((d / 'batch-idle-release.json').read_text())['released'] is True
assert hashlib.sha256((d / 'batch-fixed_trial-partial.log').read_bytes()).hexdigest() == failure['raw_sha256']
assert not (d / 'batch-strict-result.json').exists()
code = b / 'derby-detail-published-final-private-20261019.zip'
assert hashlib.sha256(code.read_bytes()).hexdigest() == '2a118ca9f72e2764f56df663caec1d157c873223ec8d25e2cb22fc70d6e25ca7'
shutil.copy2(code, d / 'code-checkpoint.zip')
def preserve(p):
    rel = p.relative_to(d)
    return (p.is_file() and p.name != 'SHA256SUMS' and '__pycache__' not in rel.parts
            and not ('local-compile-investigation' in rel.parts and 'build' in rel.parts))
files = sorted(p for p in d.rglob('*') if preserve(p))
(d / 'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest() +
    '  ' + str(p.relative_to(d)) + '\n' for p in files))
a = b / 'derby-v2-device-results-private-20261020.zip'
with zipfile.ZipFile(a, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for p in sorted(d.rglob('*')):
        if preserve(p) or p == d / 'SHA256SUMS':
            z.write(p, str(p.relative_to(d)),
                    compress_type=zipfile.ZIP_STORED if p.suffix == '.zip' else zipfile.ZIP_DEFLATED)
with zipfile.ZipFile(a) as z:
    assert z.testzip() is None
    for line in z.read('SHA256SUMS').decode().splitlines():
        want, name = line.split('  ', 1)
        assert hashlib.sha256(z.read(name)).hexdigest() == want, name
info = {'path': str(a), 'bytes': a.stat().st_size,
        'sha256': hashlib.sha256(a.read_bytes()).hexdigest(),
        'phase': 'baseline/native strict accepted; batch startup OOM; complete source checkpoint included',
        'manifest_files': len(files), 'hardware_variants_accepted': 2,
        'failed_variants': ['batch'], 'all_three_accepted': False,
        'original_code_archive_sha256': hashlib.sha256(code.read_bytes()).hexdigest()}
(b / 'V2-DEVICE-ARCHIVE.json').write_text(json.dumps(info, indent=2) + '\n')
print(json.dumps(info))
