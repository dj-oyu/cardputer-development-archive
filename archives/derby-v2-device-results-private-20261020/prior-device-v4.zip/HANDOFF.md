DERBY WATCH handoff: baseline/native strict accepted; batch startup compiler OOM, measurement not started.

Current installed batch ea64b0ec9c176f852c853cb10142581ee527d7fc. Fixed job derby-v2-batch-fixed-ea64b0ec-20261020 failed 01:43:53 UTC needs_review/serial_fault_marker. valid=false, terminal_success_verified=false; close, idle and lease release confirmed. No later device connections/reset/flash/recovery.

Full result: REPORT.md. Measured stages: DETAILED-STAGES.md / stages.csv / logical-events.csv. Local correction candidates: local-compile-investigation/FINDINGS.md, generated-candidate.patch, SUMMARY.json. Independent reviews: independent-v2-review/. Candidates are not applied to frozen branches, not hardware validated.

Complete code, full patches, commit bundles, saved host/CI and prior failures: code-checkpoint.zip SHA256 2a118ca9f72e2764f56df663caec1d157c873223ec8d25e2cb22fc70d6e25ca7. Restore wrapper actually verified batch exact head/tree and 40 modified files. SDK/all submodule history and downloaded MCP BIN/ELF bytes are not included; BUILD-ARTIFACT-PRESERVATION.json preserves artifact/proof/readback identities, MCP retained artifacts/LKG not deleted.

Private Library stable ID libfile_54f384d164808191a369081825204874. Latest version and outer ZIP SHA256 are outside the ZIP in V2-DEVICE-LIBRARY.json, avoiding self-reference. All files inside listed in SHA256SUMS. No public raw sharing.

Blocker: actual batch startup OOM unresolved. Proposed fixed-controller chunk split reduces host compile phase live payload by12676B with tested fixture/hash/counters preserved; it is not a demonstrated device fix. Full three-version device comparison, candidate production generator/proof, candidate ON/OFF and target checks remain undone. Parent decides next implementation/publication/CI/device action. No automatic retries/restore/cleanup.
