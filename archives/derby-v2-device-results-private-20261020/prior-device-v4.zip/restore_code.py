#!/usr/bin/env python3
"""Restore exact public code from this private checkpoint; no hardware use."""
import argparse
import hashlib
from pathlib import Path
import subprocess
import sys
import tempfile
import zipfile

p = argparse.ArgumentParser()
p.add_argument('--variant', required=True, choices=('baseline', 'native', 'batch'))
p.add_argument('--destination', required=True, type=Path)
a = p.parse_args()
b = Path(__file__).resolve().parent
src = b / 'code-checkpoint.zip'
assert hashlib.sha256(src.read_bytes()).hexdigest() == '2a118ca9f72e2764f56df663caec1d157c873223ec8d25e2cb22fc70d6e25ca7'
dest = a.destination.resolve()
if dest.exists() and any(dest.iterdir()):
    raise SystemExit('Destination must be empty; existing changes are protected')
with tempfile.TemporaryDirectory(prefix='derby-v2-restore-') as td:
    with zipfile.ZipFile(src) as z:
        for name in z.namelist():
            assert not Path(name).is_absolute() and '..' not in Path(name).parts
        z.extractall(td)
    helper = Path(td) / 'restore_final.py'
    subprocess.run([sys.executable, str(helper), '--variant', a.variant,
                    '--destination', str(dest)], check=True)
