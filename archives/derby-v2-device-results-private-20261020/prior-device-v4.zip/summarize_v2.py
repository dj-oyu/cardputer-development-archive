#!/usr/bin/env python3
"""Export measured exclusive/inclusive stages and logical events; no hardware I/O."""
import csv
import json
from pathlib import Path
import statistics

b = Path(__file__).resolve().parent
variants = ('baseline', 'native', 'batch')
results = {v: json.loads((b / f'{v}-strict-result.json').read_text())
           for v in variants if (b / f'{v}-strict-result.json').exists()}
assert results and all(r['strict_pass'] for r in results.values())
first = next(iter(results.values()))
assert all(r['stages'] == first['stages'] and r['events'] == first['events']
           for r in results.values())
stage_rows, event_rows, summaries = [], [], {}
for v, r in results.items():
    work = [int(x['work_us']) for x in r['coarse']['repetitions']]
    stages = []
    for i, name in enumerate(r['stages']):
        rows = [x['stages'][i] for x in r['detail']]
        stages.append({'name': name,
                       'inclusive_us_median': statistics.median(x['inc_us'] for x in rows),
                       'exclusive_us_median': statistics.median(x['self_us'] for x in rows),
                       'calls': [x['calls'] for x in rows]})
        for rep, row in enumerate(rows, 1):
            stage_rows.append([v, rep, name, row['inc_us'], row['self_us'], row['calls'], work[rep-1]])
    for rep, row in enumerate(r['detail'], 1):
        for name, amount in row['events'].items():
            event_rows.append([v, rep, name, amount,
                               'count' if name in ('TX_SUBMITS','TX_REAPS','TX_FAILURES') else 'logical_bytes'])
    summaries[v] = {'source_commit': r['source_commit'], 'work_us': work,
                    'work_us_median': statistics.median(work), 'stages': stages,
                    'unscoped_elapsed_us': [work[i] - sum(x['self_us'] for x in row['stages'])
                                            for i, row in enumerate(r['detail'])],
                    'events': [x['events'] for x in r['detail']],
                    'device_boots': 1, 'dependent_replays': 3,
                    'target_off_control': False}
for name, header, rows in [
        ('stages.csv', ['variant','dependent_rep','stage','inclusive_us','exclusive_us','calls','work_us'], stage_rows),
        ('logical-events.csv', ['variant','dependent_rep','event','amount','unit'], event_rows)]:
    with (b / name).open('w', newline='') as f:
        writer = csv.writer(f); writer.writerow(header); writer.writerows(rows)
summary = {'accepted_variants': list(results), 'all_three_accepted': len(results) == 3,
           'summaries': summaries,
           'limits': 'One boot per variant and three dependent replays; no independent-device statistics. '
                     'Elapsed includes preemption/wait. Inclusive rows overlap; do not sum them. '
                     'Exclusive includes timing overhead; no paired target OFF overhead control. '
                     'Logical copy/write amounts are not physical bus traffic.'}
(b / 'DETAILED-SUMMARY.json').write_text(json.dumps(summary, indent=2) + '\n')
md = ['# Detailed measurement stages', '', summary['limits'], '',
      'Median of the three dependent replays; time columns are milliseconds.', '',
      '| Stage | ' + ' | '.join(v + ' self / inclusive ms' for v in results) + ' |',
      '|---|' + '|'.join('---:' for _ in results) + '|']
for i, name in enumerate(first['stages']):
    cells = []
    for v in results:
        s = summaries[v]['stages'][i]
        cells.append(f"{s['exclusive_us_median']/1000:.3f} / {s['inclusive_us_median']/1000:.3f}")
    md.append('| ' + name + ' | ' + ' | '.join(cells) + ' |')
md += ['', 'Full per-replay values and calls: stages.csv. Logical events and counts: logical-events.csv.', '']
(b / 'DETAILED-STAGES.md').write_text('\n'.join(md))
print(json.dumps({'accepted': list(results), 'all_three_accepted': len(results) == 3,
                  'median_work_ms': {v: s['work_us_median']/1000 for v, s in summaries.items()}}))
