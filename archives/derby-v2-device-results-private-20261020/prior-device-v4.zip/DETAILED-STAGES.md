# Detailed measurement stages

One boot per variant and three dependent replays; no independent-device statistics. Elapsed includes preemption/wait. Inclusive rows overlap; do not sum them. Exclusive includes timing overhead; no paired target OFF overhead control. Logical copy/write amounts are not physical bus traffic.

Median of the three dependent replays; time columns are milliseconds.

| Stage | baseline self / inclusive ms | native self / inclusive ms |
|---|---:|---:|
| JS_FRAME | 964.324 / 3342.233 | 963.726 / 3285.807 |
| SIMULATION | 198.974 / 198.974 | 198.472 / 198.472 |
| POSE_PROJECTION | 347.257 / 347.257 | 348.998 / 348.998 |
| SORT | 48.444 / 48.444 | 47.860 / 47.860 |
| RUNNER | 346.071 / 484.707 | 340.490 / 473.501 |
| HUD | 124.808 / 124.808 | 123.648 / 123.648 |
| NATIVE_SERIES | 680.732 / 1147.931 | 646.934 / 1107.957 |
| PROC_BUILD | 88.180 / 629.852 | 84.765 / 618.630 |
| VM_SETUP | 58.025 / 148.628 | 56.560 / 146.839 |
| VM_ZERO | 22.010 / 22.010 | 22.571 / 22.571 |
| VM_COPY | 19.710 / 19.710 | 19.448 / 19.448 |
| VM_VALIDATE | 48.957 / 48.957 | 48.267 / 48.267 |
| VM_MATCH | 119.814 / 119.814 | 118.122 / 118.122 |
| VM_RUN | 257.912 / 257.912 | 254.013 / 254.013 |
| SEGMENT_APPEND | 15.310 / 15.310 | 15.046 / 15.046 |
| RENDER | 17.639 / 3171.845 | 17.744 / 3169.021 |
| RENDER_PREPARE | 36.398 / 36.398 | 36.628 / 36.628 |
| BACKDROP | 9.754 / 9.754 | 8.478 / 8.478 |
| COMPOSITE | 998.282 / 2192.536 | 997.082 / 2190.624 |
| IMAGE_SPAN | 486.594 / 1194.254 | 486.148 / 1193.542 |
| BAND_RASTER | 258.051 / 258.051 | 257.501 / 257.501 |
| SPAN_COPY | 449.609 / 449.609 | 449.893 / 449.893 |
| TX_SYNC | 53.914 / 915.371 | 53.629 / 915.248 |
| TX_COPY | 12.798 / 12.798 | 12.761 / 12.761 |
| TX_SUBMIT | 22.096 / 22.096 | 22.044 / 22.044 |
| TX_REAP | 826.625 / 826.625 | 826.740 / 826.740 |

Full per-replay values and calls: stages.csv. Logical events and counts: logical-events.csv.
