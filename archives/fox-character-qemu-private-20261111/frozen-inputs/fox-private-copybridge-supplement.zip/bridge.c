#include "bridge.h"
#include <string.h>
static bool valid(copy_bridge*b){return b&&b->board.strip_rows&&b->board.strip_rows(b->board.ctx)==4&&b->board.finish&&b->board.next_half&&b->board.submit;}
bool bridge_submit(void*ctx,unsigned y,unsigned rows,const uint16_t*src){
 copy_bridge*b=ctx;if(!valid(b)||b->quarantine||!src||y>=135||y!=b->next_y||y%4||rows!=(135-y<4?135-y:4))return false;
 if(!b->board.finish(b->board.ctx)){b->quarantine=true;return false;}
 uint16_t*dst=b->board.next_half(b->board.ctx);if(!dst){b->quarantine=true;return false;}
 memcpy(dst,src,rows*240*sizeof *src);
 if(!b->board.submit(b->board.ctx,y,rows,dst)){b->quarantine=true;return false;}
 b->next_y+=rows;return true;
}
bool bridge_drain(void*ctx){copy_bridge*b=ctx;if(!valid(b)||b->quarantine)return false;if(!b->board.finish(b->board.ctx)){b->quarantine=true;return false;}if(b->next_y==135)b->next_y=0;return true;}
