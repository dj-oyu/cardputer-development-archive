# Private integrated scene → copy bridge → mutating board mock

## Result
Actual frozen 1982-triangle diagnostic geometry now passes through the frozen `fh_frame` producer and frozen `copy_bridge` into a board mock that mutates and retains its own shared half-strip. O2 and ASan/UBSan pass. No baseline source was changed. Independent review approved this bounded host integration.

The normal campaign executes 30 excluded warmups then 120 measured complete frames, exactly eight poses × three cameras × five samples. Each frame submits 34 strips, 64,800 bytes, with three rows in its final strip. Every submission compares the entire original 1920-byte producer half before/after bridge invocation: 5,100 checks. The mock XOR-mutates the copied board half and retains it; finish verifies the mutated bytes have remained unchanged until completion: 5,100 checks. The mock retains borrowed board pointers, not producer pointers. No panel framebuffer is allocated.

Ready snapshot identity is checked during every submit and drain callback, then successful promotion to the other snapshot is asserted after final successful completion. This is snapshot commitment, **not atomic physical display**. The mock does not produce image/pixel comparisons, original BSDF/alpha parity, or actual SPI results. Those cannot be inferred from these checks.

## Failure contract
- Prepare failure at vertex 1321 leaves old ready intact and makes no board submit/finish call. Its campaign ends there. It does not quarantine bridge or owner, and no such claim is made.
- Failed fifth board submission retains the mutated board-half borrow. Bridge enters terminal quarantine, owner retains candidate pins, old ready is unchanged. Neither explicit recovery nor another frame invokes further board work.
- Failed final board finish is demonstrated with submits=34, last_rows=3, next_y=135 and retained non-NULL borrow. It also terminally quarantines bridge/owner, with no promotion or recovery.
- A caller-side producer abort before y=20 submission sets a terminal caller-aborted flag. The bridge itself has not had a board-operation failure, so it is not falsely labeled quarantined; its sequence remains next_y=20. The caller refuses drain/restart, leaving owner pinned/quarantined. No partial-frame restart is attempted.
- Each terminal fault uses its own static fixture, retained until process exit. No frozen state is reset, no abandoned transport is assumed safe, and no automatic repair is promised.

The board callback `finish=true` represents successful completion plus released borrow, not descriptor recycling. Callbacks are serialized and trusted, as required by the frozen bridge/harness contracts. The mock's failure and finish semantics are only host simulation.

## Timing
Monotonic callback elapsed timing from prepare start through final completion is used. Last O2 run, microseconds:

| stage | min | mean | p95 | max |
|---|---:|---:|---:|---:|
| prepare | 328 | 434.083 | 640 | 1508 |
| raster | 1109 | 1387.025 | 1708 | 3331 |
| submit | 1 | 6.842 | 11 | 24 |
| drain | 0 | 0.825 | 2 | 16 |
| full frame | 1469 | 1832.225 | 2256 | 3677 |

p95 is nearest-rank 114th of 120. Submit includes bridge finish-before-copy, copy, mock mutation and verification. It is not pure SPI time. Total includes overhead absent from stage sums. This host benchmark is not target FPS, a memory-fit proof, or a 20fps acceptance result. Sanitizer timing is retained only diagnostically; leak detection disabled, no sanitizer errors.

## Memory ledger
One logical integrated instance on this host:

| item | bytes |
|---|---:|
| immutable model + eight controls (RAM until placement verified) | 55330 |
| fh_owner, including two snapshots, workspace and producer halves | 67008 |
| board shared two half-strips, additional to producer halves | 3840 |
| copy_bridge | 48 |
| fh_port | 32 |
| board mock metadata (not an actual driver) | 48 |
| integration metadata incl test assertion/abort controls | 16 |
| known logical partial subtotal | 126322 |

Actual board metadata must replace the mock estimate, not silently be assumed equal. Generic constant/alignment overhead, real driver/task/runtime/core/UI costs, stack and total firmware are unmeasured here. No readonly-flash placement or 16KiB combined-workspace claim.

Test-only storage: two witnesses per fixture total 3840 B; one complete fixture including witnesses is 74832 B. Three additional persistent fault fixtures total 224496 B. A saved ready snapshot is 24320 B, timing samples 4800 B, plus coverage/count/reporting scratch. These are not product RAM and must not be mistaken for the single-instance subtotal. There is no giant panel/color oracle. Compiler stack `.su` files are retained; no painted stack or target high-water measurement was performed. No runtime heap allocation was added by this harness; library/runtime overhead is not characterized.

## Reproduction and provenance
```
python fox-bridge-integration-private-20261107/run.py
```
Compile commands, O2/sanitizer logs, maps, symbols and stack reports are saved. Section GC removes unused reference renderer paths. `provenance.json` contains exact frozen input hashes and verification of 16 bridge artifacts and 44 harness artifacts; parent-provided `baseline-verification.json` additionally records the complete prior handoff tree. All frozen dependencies remain unchanged. This new integration file is a test, not a public API or production board driver.

No hardware, target compiler, upload or public repository operation was performed.
