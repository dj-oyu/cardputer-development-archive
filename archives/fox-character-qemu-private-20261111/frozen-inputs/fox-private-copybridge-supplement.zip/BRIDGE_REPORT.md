# Private conservative board copy bridge

O2 and ASan/UBSan pass seven adapter-semantics cases. A 240×135 frame uses 34 strips, the last three rows, and copies 64,800 bytes. Caller source remains unchanged when the mock board mutates its own copy for overlays or byte conversion. No full framebuffer is added.

## Ordering and ownership
`bridge_submit` validates the frame sequence and `strip_rows()==4`, successfully finishes prior board work, gets a board-owned half, copies rows×240×2 bytes, then submits through the same owner. `bridge_drain` calls board finish. Only successful drain after y=135 resets the next row to zero. This conservative baseline deliberately serializes prior transfer before every copy; actual board_present_submit may finish again.

Board finish, half acquisition or submission failure permanently quarantines this instance. Failure never proves outstanding memory was released. No board half is reused and no board operation is retried after quarantine. Invalid inputs reject without transfer or quarantine. A producer abort mid-frame leaves a partial next_y even after successful drain; restart/repair/session reset is not implemented.

## Target prerequisites
- Bind callbacks to board_strip_rows, board_present_finish, board_strip_next and board_present_submit(0,y,240,rows,half), translating ESP_OK to true. Actual target bindings are not implemented here.
- Require one serialized UI/board owner. No other caller may acquire shared memory or submit between finish, copy and submission. Keep overlays/configuration fixed during measurement.
- next_half must provide at least 960 writable uint16_t pixels, disjoint from source. The trusted source is fh_owner memory, never the board shared buffer.
- finish=true means all prior accepted transfers completed successfully AND all borrows were released, not merely descriptors freed.
- This is adapter semantics only, not actual DMA validation, geometry/pixel evaluation or a performance result. Frozen target zip remains unchanged.

## RAM and copies
Existing fh_owner: 67,008 B, already including its own 3,840 B halves. Board shared: ANOTHER 3,840 B. Bridge host sizeof: 48 B. Partial subtotal: 70,896 B. Adding immutable model/controls 55,330 B gives 126,226 B before engine constants/alignment, stack, driver, core/UI and platform. No flash placement or target fit is assumed. Copy volume is 64,800 B/frame, not zero-copy. The test-only witness and source/saved arrays are excluded from runtime accounting. Compiler .su values are host function frames, not task HWM.

## Tests and review
Run `python fox-board-adapter-design-private-20261107/run.py`. Cases cover board mutation, unchanged caller input, caller overwrite after copying, prior finish failure retaining a borrow, failed submission retaining the new borrow, missing board half, final completion failure on the last three rows, quarantine blocking, and invalid dimensions/order/null source/non-four-row configuration. Leak detection is disabled for sanitizer runs.

Independent read-only review found no blocker for this bounded trusted-resolution contract. Requested buffer-capacity, partial-restart and invalid-input limitations are documented above. Board source inspected: mesh-q7-depth-cache-20261107/main/hal/board.c. Parent recorded source hashes in board-source-hashes.json. No device, public change or modification to earlier frozen artifacts occurred.
