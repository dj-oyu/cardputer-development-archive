#ifndef PRIVATE_BRIDGE_H
#define PRIVATE_BRIDGE_H
#include <stdbool.h>
#include <stdint.h>
typedef struct {
 void *ctx;
 unsigned (*strip_rows)(void*);
 /* True attests successful completion of all prior work and borrow release. */
 bool (*finish)(void*);
 /* Writable board-owned storage of at least960 uint16_t, disjoint from source. */
 uint16_t *(*next_half)(void*);
 /* May mutate board-owned half and retain it even when returning false. */
 bool (*submit)(void*,unsigned,unsigned,uint16_t*);
} board_callbacks;
typedef struct {board_callbacks board;bool quarantine;unsigned next_y;} copy_bridge;
/* Serialized, non-reentrant single owner. Source must not alias board shared
 * storage; trusted frame_harness halves satisfy that integration prerequisite.
 * A board-operation failure permanently quarantines this instance. Invalid
 * input rejects without quarantine. No partial-frame restart or automatic recovery. */
bool bridge_submit(void*,unsigned,unsigned,const uint16_t*);
bool bridge_drain(void*);
#endif
