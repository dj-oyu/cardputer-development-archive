from pathlib import Path
import argparse, hashlib, json, os, subprocess, tempfile
R = Path(__file__).resolve().parent
p = argparse.ArgumentParser()
p.add_argument('--base', required=True, help='Extracted original fox-private-target-source.zip directory')
p.add_argument('--compile-only', action='store_true')
p.add_argument('--output')
a = p.parse_args()
B = Path(a.base).resolve()
manifest = json.loads((B/'MANIFEST.json').read_text())
for name, record in manifest.items():
    assert hashlib.sha256((B/name).read_bytes()).hexdigest() == record['sha256'], name
d = json.loads((B/'dependencies.json').read_text())
out = Path(a.output).resolve() if a.output else Path(tempfile.mkdtemp(prefix='fox-bridge-check-'))
out.mkdir(parents=True, exist_ok=True)
sources = [R/'test_integration.c', R/'bridge.c'] + [B/s for s in d['sources'][1:]]
cmd = [os.environ.get('CC', 'cc'), '-std=gnu11', '-O2', '-Wall', '-Wextra', '-Werror',
       '-ffp-contract=off', '-fno-fast-math', '-fstack-usage', '-ffunction-sections', '-fdata-sections',
       '-I'+str(R), *['-I'+str(B/i) for i in d['includes']], *map(str, sources), '-lm',
       '-Wl,--gc-sections', '-Wl,-Map='+str(out/'link.map'), '-o', str(out/'run')]
(out/'command.json').write_text(json.dumps(cmd))
subprocess.run(cmd, cwd=out, check=True)
if not a.compile_only:
    subprocess.run([str(out/'run')], check=True)
print('BUILD_OUTPUT', out)
