# Private copy-bridge integration supplement

This supplements, never replaces, frozen `fox-private-target-source.zip`:
SHA256 `e7cf178c697e8c802a10c44e55e92ea3f6ac7da9640201908b20afc87958bcfc`, 83,320 bytes.
Keep the source package and this supplement private. No new model or visual claims.

After independently verifying the original archive and extracting it, run:
`python build.py --base /absolute/path/to/extracted/base --output /private/build/directory`
This verifies all base manifest entries and reproduces the existing host integration
test with portable relative dependencies. It is a packaging/reproduction check,
not another model validation campaign. `CC` and `--compile-only` support build
inspection, but do not supply ESP-IDF runtime headers or a real board adapter.
Do not execute a cross-built binary on the host.

Only `bridge.c/.h` belong in the candidate runtime, alongside the base runtime
sources. `test_integration.c` is host-only: it has multiple full owner instances,
witness arrays and statistics. NEVER put it into device firmware as a benchmark.

## Target integration boundary
- One serialized UI/display owner, four-row strips, full damage, frozen UI/overlay
  configuration. Use actual target `esp_timer_get_time` for elapsed timings.
- Bind finish to successful `board_present_finish`, half acquisition to
  `board_strip_next`, and submit to `board_present_submit(0,y,240,rows,pixels)`.
  Verify these actual APIs and compile configuration at the selected target HEAD.
- Bridge copies input to the board-owned half. Do not cast const input and submit
  it directly: the board may apply overlays/byte swaps, and its own half-loan
  contract decides whether transfer remains asynchronous.
- Include separate board shared storage (host count 3,840 B), 64,800 copied bytes
  per frame, driver descriptors, real callbacks, and all task stacks in the map.
  Host partial ledger 126,322 B includes mock metadata and is NOT target RAM fit.
- Failures are terminal for this instance. Preserve pinned storage; neither
  resetting counters nor freeing the instance establishes safe drain. No automatic
  repair/restart protocol is implemented. Display is non-atomic.
- Real target build/map/stack, DMA, pixel output and 20fps remain unverified.
  The model is an approved-source-derived 2k-v2 diagnostic derivative with
  opaque ID colors and neutral facial controls, not original BSDF/morph parity.
