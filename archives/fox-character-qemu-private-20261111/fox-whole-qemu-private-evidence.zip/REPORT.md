# Private whole-fox QEMU diagnostic

## Result
The recovered, frozen 1,982-triangle / 74-object / 1,322-vertex 2k-v2 diagnostic scene now runs on ESP32-S3 QEMU. Six captured 240x135 RGB565 frames match the same host wrapper exactly: zero differing pixels. Twelve total frame visits cover two lifecycles, with the second replaying the six pose/view combinations in reverse; all hashes match. The delayed mock transport passed 612 retained-buffer witness checks, checked snapshot identity during submit/drain, and promoted the new snapshot only after successful final completion.

Captures use pose 0 (neutral), pose 1 (head turn -1, tilt -.5), pose 4 (head turn +1, tilt +.5), each front and oblique. This is the restricted source-derived head/body rig, not a full facial animation system. It is a diagnostic derivative of fox-bubble-bold, not the approved original source itself.

## Actual path and limitations
Frozen scene_prepare performs body rigid DQ and smooth-normal reconstruction, updates rigid head attachments, projects all vertices, and builds band triangle bins. Frozen scene_band streams compact packets into the private prepared accumulator. Frozen fh_frame owns two snapshots, one shared rig/raster workspace and two 4-row producer halves. A new test adapter captures rows and models delayed release. No full panel or full-image oracle lives on the target.

This is **opaque material-ID diagnostic color**. Recomputed normals are not used by this diagnostic coloring. Source BSDF, procedural eyes, transparency/depth, face morphs and brow deformation are not reproduced. Projected zero/tiny triangles are recorded and skipped without deleting cold topology; all selected samples record 36 zero-area and zero tiny-area triangles. Images visibly show plain diagnostic eye areas, not the original eyes. This archive does not traverse QuickJS, AYNM, or the actual Kasane UI/compositor. It does not validate LCD/SPI/DMA, concurrent VM execution, production full-firmware fit, physical FPS or the 20fps gate. The copy bridge supplement was not linked; its separate prior host evidence is not a result of this target run.

The host comparison uses the exact same frozen renderer and wrapper, so it proves host/target agreement for these frames, not independent raster correctness or Blender/material fidelity. Native borrowing checks are synchronous delayed-completion mocks, not real asynchronous hardware.

## Target memory
ESP-IDF 6.0.1, GCC 15.2.0, official Espressif QEMU 9.2.2, ESP32-S3, no PSRAM. ELF/map confirms the private source symbols and eight controls at flash-mapped 0x3c... addresses, rather than assuming readonly implies flash.

- fh_owner: 67,008 B, including snapshots 48,640 B and shared workspace 14,512 B.
- Test-only borrow witnesses: 3,840 B, plus pointer/metadata controls.
- Immutable source: 55,266 B; controls: 64 B, both flash mapped.
- Guest sections: .dram0.bss 73,168 B, .dram0.data 11,373 B; IDF DIRAM usage 109,756 B. Flash .rodata 82,336 B. These include this minimal guest and test scaffold, not production firmware.
- Internal 8-bit heap: startup/free after every frame/after both lifecycle resets 315,404 B; largest 253,952 B; recorded minimum 315,388 B.
- Main task configured stack 24,576 B. Reported stack high-water free drops from 24,120 to 23,352 B (IDF byte units), observed used high water 1,224 B. This applies only to this guest and sample set.
- Owner is static BSS. Lifecycle “released” resets it only after no pending borrow/pin; it does not free BSS, and equal heap values do not independently establish general leak freedom.

There are no target timing/FPS conclusions. The frozen scene's internal clock() diagnostic encounters IDF's unimplemented times() link warning and is discarded by fh_frame; no result uses those values. The port timer is esp_timer_get_time, but emulator elapsed time is not physical throughput. The bounded run completed in about 19.5 host seconds; this is execution bookkeeping only.

## Verification and provenance
Host O2 and ASan/UBSan wrappers completed with identical frame data; LeakSanitizer disabled for this environment. Target 12 frames, six exact-byte captures, reverse replay and retained-buffer checks passed. The first target compile failed solely on uint32_t printf formatting in the new wrapper; it was fixed with PRIx32, and the failed log is retained. No frozen source was edited, no production repository change, no publication or hardware operation occurred.

Inputs: fox-private-target-source.zip SHA256 e7cf178c697e8c802a10c44e55e92ea3f6ac7da9640201908b20afc87958bcfc. Its dependencies.json/source manifest was verified unchanged after execution. The bundle does not establish an exact commit mapping to old local 52b119ca.

Files: host-command.json and host-san-command.json; host.log/host-san.log; build.log and initial failure log; target/run-metadata.json (commands, binary/config/UART hashes); target/uart.log; size.txt, sections.txt, symbols.txt; captures/results.json and six PNG/raw files; source-manifest.json. Contact sheet is nearest-neighbor enlargement of the actual target pixels, with labels only.
