#include "frame_harness.h"
#include <assert.h>
#include <inttypes.h>
#include <stdio.h>
#include <string.h>
#ifdef ESP_PLATFORM
#include "esp_timer.h"
#include "esp_heap_caps.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#else
#include <time.h>
#endif
static fh_owner owner;
static const uint16_t *borrow[2];
static uint16_t witness[2][960];
static unsigned borrowed,life,pose,view,next_y,checks;
static uint32_t frame_hash;
static unsigned ready_before;static bool had_ready;
static uint64_t now(void*ctx){(void)ctx;
#ifdef ESP_PLATFORM
return esp_timer_get_time();
#else
struct timespec t;assert(!clock_gettime(CLOCK_MONOTONIC,&t));return (uint64_t)t.tv_sec*1000000+t.tv_nsec/1000;
#endif
}
static void stable(void){assert(owner.ready==ready_before&&owner.has_ready==had_ready);for(unsigned i=0;i<borrowed;i++){assert(!memcmp(borrow[i],witness[i],sizeof witness[i]));checks++;}}
static bool submit(void*ctx,unsigned y,unsigned rows,const uint16_t*p){(void)ctx;stable();assert(y==next_y&&rows==(y==132?3:4)&&borrowed<2);for(unsigned i=0;i<borrowed;i++)assert(borrow[i]!=p);borrow[borrowed]=p;memcpy(witness[borrowed],p,sizeof witness[borrowed]);borrowed++;next_y+=rows;
 for(unsigned r=0;r<rows;r++){
  if(life==0)printf("FOX_WHOLE_ROW pose=%u view=%u y=%u ",pose,view,y+r);
  for(unsigned x=0;x<240;x++){uint16_t c=p[r*240+x];frame_hash=(frame_hash^c)*16777619u;if(life==0)printf("%02x%02x",c&255,c>>8);}
  if(life==0)putchar('\n');
 }
 return true;
}
static bool drain(void*ctx){(void)ctx;stable();borrowed=0;return true;}
static void heap(const char*phase){
#ifdef ESP_PLATFORM
printf("FOX_WHOLE_HEAP life=%u phase=%s free=%u largest=%u minimum=%u stack_hwm=%u\n",life,phase,(unsigned)heap_caps_get_free_size(MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT),(unsigned)heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT),(unsigned)heap_caps_get_minimum_free_size(MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT),(unsigned)uxTaskGetStackHighWaterMark(NULL));
#else
(void)phase;
#endif
}
static void run(void){
 const unsigned poses[3]={0,1,4};uint32_t hashes[6];fh_port port={NULL,now,submit,drain};
 printf("FOX_WHOLE_PROFILE triangles=1982 neutral_face opaque_material_ID no_QuickJS no_AYNM no_Kasane_UI no_LCD no_FPS_claim\n");
 printf("FOX_WHOLE_MEMORY owner=%zu workspace=%zu snapshots=%zu source_const=%zu controls_const=%zu witnesses=%zu\n",sizeof owner,sizeof owner.workspace,sizeof owner.frames,scene_constant_bytes(),scene_pose_fixture_bytes(),sizeof witness);heap("startup");
 for(life=0;life<2;life++){
  memset(&owner,0,sizeof owner);assert(!borrowed);heap("initialized");
  for(unsigned visit=0;visit<6;visit++){
   unsigned id=life?5-visit:visit;pose=poses[id/2];view=id%2;next_y=0;frame_hash=2166136261u;had_ready=owner.has_ready;ready_before=owner.ready;fh_times times;
   assert(fh_frame(&owner,&port,pose,view,-1,&times)==FH_OK);assert(!borrowed&&!owner.pending&&!owner.pinned&&!owner.quarantine&&owner.display_known&&next_y==135);assert(owner.ready==(had_ready?(ready_before^1):0));
   if(!life)hashes[id]=frame_hash;else assert(hashes[id]==frame_hash);
   printf("FOX_WHOLE_FRAME life=%u pose=%u view=%u hash=%08" PRIx32 " zero=%u tiny=%u active=%u\n",life,pose,view,frame_hash,owner.frames[owner.ready].zero_area,owner.frames[owner.ready].tiny_area,owner.frames[owner.ready].active);
   heap("frame_done");
  }
  assert(!borrowed&&!owner.pending&&!owner.pinned);memset(&owner,0,sizeof owner);heap("released");
 }
 printf("FOX_WHOLE_QEMU_DONE frames=12 captures=6 lifecycles=2 reverse_hashes_pass borrow_checks=%u\n",checks);
}
#ifdef ESP_PLATFORM
void app_main(void){run();for(;;)vTaskDelay(pdMS_TO_TICKS(1000));}
#else
int main(void){run();return 0;}
#endif
