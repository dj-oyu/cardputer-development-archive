from pathlib import Path
import re,json,hashlib
from PIL import Image,ImageDraw
D=Path(__file__).resolve().parent
pat=re.compile(r'FOX_WHOLE_ROW pose=(\d+) view=(\d+) y=(\d+) ([0-9a-f]+)')
fpat=re.compile(r'FOX_WHOLE_FRAME life=(\d+) pose=(\d+) view=(\d+) hash=([0-9a-f]+)')
def read(p):
 text=p.read_text();frames={};hashes={}
 for m in pat.finditer(text):
  pose,v,y=map(int,m.group(1,2,3));b=bytes.fromhex(m[4]);assert len(b)==480;rows=frames.setdefault((pose,v),{});assert y not in rows;rows[y]=b
 for m in fpat.finditer(text):
  k=tuple(map(int,m.group(1,2,3)));assert k not in hashes;hashes[k]=m[4]
 return {k:b''.join(v[y] for y in range(135)) for k,v in frames.items()},hashes
host,hh=read(D/'host.log');target,th=read(D/'target/uart.log');assert len(host)==len(target)==6;assert len(hh)==len(th)==12
out=D/'captures';out.mkdir(exist_ok=True);results=[]
for k,b in target.items():
 p,v=k;h=host[k];diff=sum(b[i:i+2]!=h[i:i+2] for i in range(0,len(b),2));pix=[]
 for i in range(0,len(b),2):
  n=int.from_bytes(b[i:i+2],'little');pix.append((((n>>11)&31)*255//31,((n>>5)&63)*255//63,(n&31)*255//31))
 im=Image.new('RGB',(240,135));im.putdata(pix);im.save(out/f'whole-p{p}-v{v}.png');(out/f'whole-p{p}-v{v}.rgb565').write_bytes(b)
 results.append({'pose':p,'view':v,'differing_pixels_vs_host':diff,'sha256':hashlib.sha256(b).hexdigest()})
summary={'capture_comparison':results,'hashes_equal':hh==th,'target_frames':len(th),'host_frames':len(hh),'total_differing_pixels':sum(r['differing_pixels_vs_host'] for r in results)}
(out/'results.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
canvas=Image.new('RGB',(1440,880),'#20242c');d=ImageDraw.Draw(canvas);d.text((16,8),'QEMU / ESP32-S3: 2k-v2 whole fox, 1982 triangles. Opaque material-ID diagnostics; neutral face.',fill='white');d.text((16,28),'Not original materials, eye transparency, face morphs, QuickJS or physical LCD.',fill='white')
for col,p in enumerate([0,1,4]):
 for row,v in enumerate([0,1]):
  im=Image.open(out/f'whole-p{p}-v{v}.png').resize((480,270),Image.Resampling.NEAREST);x=col*480;y=90+row*380;canvas.paste(im,(x,y));d.text((x+12,y-25),f'pose {p}: '+['neutral','turn -1 / tilt -.5','turn +1 / tilt +.5'][col]+' / '+('front' if v==0 else 'oblique'),fill='white')
canvas.save(out/'whole-fox-qemu-contact.png')
