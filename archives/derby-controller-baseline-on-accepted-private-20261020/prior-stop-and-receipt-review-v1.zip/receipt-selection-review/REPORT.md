# Receipt選択の読取照合

結論：今回選んだ正常baselineのhistorical receiptは、次のflashで要求される「現在のfirmwareと一致する比較元」と用途が違った。旧batchのflash成功receiptはcurrent比較元候補であるが、その後のplay compile OOMによりアプリ正常版とは扱わない。今回の実測hashは保存記録に公開されていない。新しいplan作成・再試行・backup・restore・reset・USB操作はしていない。

## 実績とreceiptの役割

- 旧batch flash `derby-v2-batch-flash-ea64b0ec-20261020`：01:43:10 UTC succeeded。full segment SHA256 readback、IDF6.0.1/ELF prefix `6cd208f17`、passive boot/closeを満たした。生成receiptは `5e1fa311d4a565672d27b5bff976fb04e30c92ff993bcf51f05fe07693a70b22`。flash成功は保存bytesのidentityを示し、DERBYの起動・完走を証明しない。
- 直後の `derby-v2-batch-fixed-ea64b0ec-20261020`：01:43:49→01:43:53 UTC needs_review / serial_fault_marker。play compile OOM、windows0、END/ownerEXIT/STOP/HOMEなし、valid=false。元の失敗を保持する。receiptの名称LKGをアプリ正常判定に読み替えない。
- 今回baseline flashへ渡した `e9a33d3e3d0a9c1809a4238efc42c85cf440837ec62466c5c52326ddd69c761a` は以前に正常受入したbaseline37af4225のrollback候補である。現在比較元の代わりとして用いた選択が誤りだった。
- baseline旧版・native旧版の正常受入証拠と保持済みbundleはそのまま残す。batchのsnapshotを正常と再分類したり、正常rollback候補を上書きしたりしない。

## hashを混同しない

| 対象 | SHA256または観測値 | 意味 |
| --- | --- | --- |
| 選択した旧baselineのbootloader 22,528B | `63b3fe76480d6cb6ca0e9b71cab2e09c72a515bd08f4b8030bd73c2b62941f70` | selected receiptが要求する比較bytesのartifact hash |
| 旧baseline app BIN / ELF | `63f35801715ce8f211a7ded14c138f1e9a6a40415bc39170660f92c779743e7d` / `e2e49a8637d0ef0ee3c7f839c7323f76d5d230e66e474216419a7ba21f7c3a3b` | 正常rollback候補の保存hash |
| 旧batch bootloader 22,528B | `0acc109229fdcb9014f0b4b2ecb9c3ee5959150e3d998bd2f2c1cadbeb05f0a8` | 01:43:10 readback成功に結び付くartifact hash。今回の再測定hashではない |
| 旧batch app BIN / ELF | `c696bcda9def6cfc25fb9a99d309dc8412edcee19c766629cd2bb4697c59f5de` / `6cd208f176e0e1e74642b11bf3f5314fc2d8297013beb600308c9de995683e1f` | 旧batch成功flash時の保存期待hash。boot観測はprefixのみ |
| 今回のROM readの観測hash | **未取得・応答にない** | 22,528B read成功と不一致停止のみ。診断null。全current identityや不一致regionを断定しない |
| plan.expected_device_sha256 | `3591e6eb85ec490243dbedbd27bb49404f65bf33b6e8961d281809626e884801` | device/security probeの一致用。firmware BINのhashではない |
| 新baseline書込予定BIN / ELF | `ae7ec8ec1fddd0238003c903fafe7c6de47ffe3c1e7df7c3b7b08a94f861578b` / `f149d372f186a0e6642d2d929db1cbf1ae6cd2f8163458832b2024f0074c7962` | 書込後の目標artifact。書込前に現物がこの値であることは要求しない |

22,528Bは両版bootloaderのサイズと一致し、その保存hash同士は異なる。下記コードではprior.segments順でbytes比較し、最初の不一致で例外となるため、最初のbootloader差で停止したという説明と整合する。ただし今回の応答にはoffset・実測hashがなく、これを実測region特定とは扱わない。

## 読んだ正規契約

公開source `dj-oyu/esp-device-broker-mcp@daaaf345d762a6bc23f93883dfb3ac3d86ad2e2f` を読取専用GitHub経路で確認し、3ファイルを保存した。このcommitは以前の00:38 deployment reportに対応する。現在epoch51bfd752bc2a460db00a835c45250282の実行バイナリがこのcommitと同一かは独立確認していない。現在のツール説明および今回のエラー/段階は以下の契約と整合しているが、現在バイナリのsource identity証明とはしない。

- [FIRMWARE-FLASH.md:73–107](https://github.com/dj-oyu/esp-device-broker-mcp/blob/daaaf345d762a6bc23f93883dfb3ac3d86ad2e2f/FIRMWARE-FLASH.md#L73)：正常flashはbytes/manifest/security/ELFを保持し、最終成功transactionでcurrent receiptを選ぶ。次のflashはcurrent LKG比較。以前のreceiptを指定したrestoreは別の明示操作。
- [firmware_flash.py:254–273](https://github.com/dj-oyu/esp-device-broker-mcp/blob/daaaf345d762a6bc23f93883dfb3ac3d86ad2e2f/src/cardputer_mcp/firmware_flash.py#L254)：receipt指定時はhistorical knownを取得し、省略時はcurrentを取得。device/principal/selector等のbindingと保存objectを検証する。
- [flash_lifecycle.py:251–267](https://github.com/dj-oyu/esp-device-broker-mcp/blob/daaaf345d762a6bc23f93883dfb3ac3d86ad2e2f/src/cardputer_mcp/flash_lifecycle.py#L251)：artifact比較は選択したprior bytesと現ROM readの完全一致。実測hashを診断へ出さず、差があればlkg_current_firmware_changed_needs_review。full backup利用時は書込・erase対象sectorをbackupと比較する。
- 同ファイル272–287：historical artifactへのrestoreはcurrent partition tableを照合してから別書込。restore対象と現在firmwareの全bytes一致を要求するflashとは契約が異なる。
- 保存READMEのInterrupted work：historical needs_review単独は安全な新jobの必須解除条件ではない。review acknowledgementはオフライン・broker停止・現状検討後の別操作で、bytes不一致の修正も再実行も行わない。手動DB改変は禁止。今回それは実行していない。

## 正規の次工程と必要権限（提案のみ）

1. 次の実機操作を許可する前に、親が今回の失敗とcurrent比較元・正常rollback候補の別用途をレビューする。現在のreceipt availability/integrity/device/principalと実稼働契約を正規経路で再確認する。旧batch `5e1fa311…70b22` が保存上のcurrent比較元候補であり、正常アプリ候補ではない。
2. 親が修正したexact flashを新たに指示する場合のみ、current候補receiptを正確にbindした新job/planを作る。選択receipt・build・epoch・device・hashが凍結され、実行時にROMの対象bytes完全一致が再検証される。省略によるdynamic latestへの無検討切替はしない。保存履歴だけで現在一致済みとは宣言しない。再不一致なら停止する。
3. 保存current比較元を安全に確立できない場合、必要に応じて**独立したfirmware_backup**を親が明示指示する。これは8MiBの物理ROM読取で、ROM resetを伴い得るため今回の読取限定範囲では未実施。成功したowned/device-bound full backupを後続planのbackup_job_idとして使えるが、backup自体はアプリ正常性を認定しない。正常rollbackデータとOOM失敗証拠は別に保持する。
4. 正常旧baselineへ先に戻す選択なら、それもhistorical receipt指定の**独立したfirmware_restore**の明示指示が必要。partition/security/layout checks、readback/boot/closeを通し、その完了後に次のflashを改めて検討する。自動rollback/restoreはない。

物理backup/flash/restoreには、現行認証control scope、live owned session、登録deviceの各allow_backup/allow_flash/allow_restore capability、exact prepare→explicit executeが必要。flashは成功owned build、restoreはverified recoveryが必要。read scopeやprepare受理だけでは物理実行権限にならない。既存認証/config/SDK/上限の変更は提案しない。offline reviewは必要がある場合に既存ownerの停止・確認・正規CLIで行う別のローカル操作で、今回のAPIや権限範囲で行わない。

今回完了：保存済み12証拠と3sourceファイルの照合、receipt/hash/権限の整理。未完：今回の実測hash、current snapshot再検証、実行バイナリのexact source identity確認、baselineの書込・boot・ON trial。すべて保留のままで、物理操作を追加していない。
