#!/usr/bin/env python3
"""Verify saved source/build receipts and linked proof. No network or device access."""
from pathlib import Path
import datetime,hashlib,json,re
root=Path(__file__).resolve().parent
inputs={}
def read(name):
 data=(root/name).read_bytes()
 inputs[name]=hashlib.sha256(data).hexdigest()
 return json.loads(data)
checks={}
def check(name,value):
 checks[name]=bool(value)
 if not value:raise AssertionError(name)
canonical=lambda x:hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()
sp=read('source-plan.json'); se=read('source-execute.json'); sj=read('source-result.json')
bp=read('build-plan.json'); be=read('build-execute.json'); bj=read('build-result.json')
final=read('build-final-logs.json')
head='b561aea1c0798feb28055a00d36681fae81ac58a'
epoch='25fdbe66ee704b40ab4040bc390ee793'
src=sj['diagnostic']['source']
check('source_success',sj['ok'] and sj['state']=='succeeded' and sj['result']=='source_snapshot_fetched_no_build_no_flash')
check('source_exact_head_tree_hash',src['commit']==head and src['tree_sha1']=='a46db1efcf7121ac9e82c647e00fe4faf251f5ad' and src['source_sha256']=='1eab55b86ee1cefdac3cf3e42ee80d02ae663844a019284b1f4bee2167f77772')
check('source_receipt',src['source_receipt']=='f943d8a86e72e70015040a73e1d389f09b3fda1839ae44ea361b1b8423ecb822')
check('source_job_plan_execute',sp['plan_hash']==se['plan_hash']==sj['plan_hash'] and sp['plan']['job_id']==se['id']==sj['id'])
check('new_epoch',sp['plan']['broker_epoch']==bp['plan']['broker_epoch']==epoch)
check('same_principal_registered_project',sp['plan']['principal_id']==bp['plan']['principal_id']=='ephemeral:remote_mcp' and sp['plan']['project_id']==bp['plan']['project_id']=='cardputer-main')
check('build_success',bj['ok'] and bj['state']=='succeeded' and bj['result']=='firmware_build_succeeded_no_flash')
check('build_job_plan_execute',bp['plan_hash']==be['plan_hash']==bj['plan_hash'] and bp['plan']['job_id']==be['id']==bj['id'])
check('explicit_ON_build',bp['plan']['derby_detail_mode']=='ON' and 'POCKET_DERBY_DETAIL_MEASURE=ON' in bp['plan']['argv_template'])
check('same_owned_source',bp['plan']['source_receipt']==src['source_receipt'])
check('source_provenance_fields',all(bp['plan']['source_provenance'][k]==src[k] for k in ('source_receipt','repository','commit','tree_sha1','source_sha256','submodules')))
created=datetime.datetime.strptime(bj['created'],'%Y-%m-%d %H:%M:%S').replace(tzinfo=datetime.timezone.utc).timestamp()
check('build_before_plan_expiry',created<bp['plan']['source_plan_expires_at'])
check('requested_environment',bp['plan']['expected_idf']=='6.0.1' and bp['plan']['target']=='esp32s3')
pages=[read(p.name) for p in sorted(root.glob('build-log-all-page-*.json'))]
check('all_log_pages_good',all(p['ok'] and not p['expired'] and not p['gap'] for p in pages))
check('final_log_no_more',not pages[-1]['has_more'] and not final['has_more'])
entries={}
for page in pages:
 for e in page['entries']:
  if e['sequence'] in entries:check('duplicate_log_entries_identical_'+str(e['sequence']),entries[e['sequence']]==e)
  entries[e['sequence']]=e
check('complete_sequence1_2120',sorted(entries)==list(range(1,2121)))
check('durable_verified_artifacts',final['artifact_status']=='verified')
m=final['manifest'];mp=m['diagnostic_modeproof'];proof=mp['proof']
check('manifest_job_plan_fingerprint',m['build_job_id']==bj['id'] and m['build_plan_hash']==bj['plan_hash'] and m['fingerprint']==bp['plan']['fingerprint'])
check('manifest_source_binding',m['source_provenance']==bp['plan']['source_provenance'])
check('manifest_mode_ON',m['derby_detail_mode']==mp['requested_mode']=='ON')
check('proof_canonical_sha256',canonical(proof)==mp['proof_sha256'])
check('proof_all_four_modes_ON',proof['build_mode']['telemetry_mode']==proof['build_measure']['measure_mode']==proof['fixed_workload']['mode']==proof['detail_measurement']['mode']=='ON')
check('common_owner_completion',proof['fixed_workload']['owner_completion']=={'contract':'fixed-owner-v1','detail_mode':'ON','record':'DERBY_DETAIL_EXIT'} and {'df_fixed_exit_record','df_detail_enabled'}<=set(proof['fixed_workload']['native_symbols']))
check('detail_native_symbols',{'dd_enter','dd_leave','dd_start','dd_finish'}<=set(proof['detail_measurement']['native_symbols']))
fixture=proof['fixed_workload']['fixture']
expected={'camera':8,'contexts':120,'end':510,'finish':'5DC86E18','id':'oval-pan8-390-510-v1','independent':False,'oval':1,'race':1000001,'repetitions':3,'seed':'9112A7AB','start':390,'tier':1}
check('fixture_exact',fixture==expected)
seed=proof['comparison_seed']
check('generated_JS_and_hw_seed_linked',seed['hardware_seed']=='2545F491' and seed['elf_seed_symbol_verified'] and seed['elf_embedded_view_verified'] and proof['build_mode']['elf_embedded_play_verified'])
check('not_a_hardware_result',proof['hardware_tested'] is False and m['flash_authorized'] is False)
check('manifest_environment',m['idf_version']=='6.0.1' and m['target']=='esp32s3' and m['environment_fingerprint']=='557872838c96cc685605a315a1a9933083adfaa86fb8111f3bdb60455451c076')
artifacts={a['name']:a for a in m['artifacts']}
check('proof_BIN_ELF_match_manifest',all(all(artifacts[name][k]==a[k] for k in ('bytes','sha256')) for name,a in proof['artifacts'].items()))
check('expected_BIN_ELF_hashes',proof['artifacts']['cardputer_pocketjs.bin']['sha256']=='3f3eda8021804466be2ab5d1a6ed0953f96494e05ff1e42aa46a0dae919a0de9' and proof['artifacts']['cardputer_pocketjs.elf']['sha256']=='25249d3df9c9d5ea0eda71b51cd051767b355cdc14274261ea9066593c98e8f5')
logproof=[json.loads(e['text'].split('DERBY_DIAGNOSTIC_BUILD_PROOF ',1)[1]) for e in entries.values() if e['text'].startswith('DERBY_DIAGNOSTIC_BUILD_PROOF ')]
check('mandatory_logged_proof_matches_manifest',len(logproof)==1 and logproof[0]==proof)
source_logs=read('source-final-logs.json')
check('complete_source_stages',not source_logs['expired'] and not source_logs['gap'] and not source_logs['has_more'] and [x['text'] for x in source_logs['entries']]==['-- source_download','-- source_validate','-- source_publish'])
before=read('resources-before.json');after=read('resources-after-build.json')
old={x['source_receipt']:x for x in before['owned_snapshots']};cur={x['source_receipt']:x for x in after['owned_snapshots']}
check('complete_cache_inventories',before['reference_inventory_complete'] and after['reference_inventory_complete'] and before['scan_complete'] and after['scan_complete'])
check('all19_old_receipts_and_payload_states_preserved',len(old)==19 and set(old)<=set(cur) and all(all(cur[k][f]==v[f] for f in ('source_job_id','state','bytes','entries','payload_present')) for k,v in old.items()))
protected=[x for x in old.values() if x['payload_present'] and not x['payload_reclamation_candidate']]
check('all14_protected_payloads_preserved',len(protected)==14 and all(cur[x['source_receipt']]['payload_present'] and cur[x['source_receipt']]['bytes']==x['bytes'] for x in protected))
check('only_J1_source_added',len(cur)==20 and set(cur)-set(old)=={src['source_receipt']} and cur[src['source_receipt']]['payload_present'])
check('no_reclamation_or_pending_payload',after['source_cache']['evicted_snapshots']==before['source_cache']['evicted_snapshots']==4 and after['source_cache']['pending_snapshots']==0 and after['source_cache']['snapshots']==16)
status=read('status-final.json')
check('idle_unowned_after_build',status['active_job'] is None and status['profile_active_job'] is None and status['owner'] is None and all(status[k]==0 for k in ('queue_depth','profile_queue_depth','wait_queue_depth','work_session_count','lease_remaining_seconds')))
check('no_current_uncertainty',all(status[k] is False for k in ('execution_uncertain','ownership_uncertain','profile_uncertain')) and status['safety']['current_resource_uncertain'] is False)
check('only_source_and_build_success_history_delta',status['history']=={'cancelled':3,'failed':8,'needs_review':9,'succeeded':111})
output=''.join(entries[k]['text']+'\n' for k in sorted(entries))
(root/'build-output-redacted.log').write_text(output)
result={'verified':True,'hardware_accepted':False,'firmware_bytes_materialized_locally':False,'scope':'Saved provider revalidated artifact manifest and mandatory linked mode proof; no direct BIN/ELF body reread in Linux, no physical test.', 'head':head,'source':src,'build_job':bj,'manifest':m,'proof':proof,'proof_sha256':mp['proof_sha256'],'manifest_canonical_sha256':canonical(m),'complete_log_sequences':len(entries),'log_sha256':hashlib.sha256(output.encode()).hexdigest(),'checks':checks,'input_sha256':inputs,'protected_payload_count':14,'prior_receipts_preserved':19}
(root/'SOURCE-BUILD-PROOF.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'verified':True,'checks':len(checks),'complete_logs':len(entries),'build_job':bj['id'],'mode':'ON','artifacts':proof['artifacts'],'proof_sha256':mp['proof_sha256'],'hardware_accepted':False}))

