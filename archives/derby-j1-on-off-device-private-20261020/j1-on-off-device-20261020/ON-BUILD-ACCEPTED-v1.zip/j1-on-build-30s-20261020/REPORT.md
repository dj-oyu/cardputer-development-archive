# J1 detail ON build succeeded — no device operation

The requested source/build attempt completed successfully. Exact J1 detail ON built once, with a verified durable artifact manifest and linked diagnostic proof. No flash, USB, OFF build, collector or physical measurement was attempted.

- Source head: b561aea1c0798feb28055a00d36681fae81ac58a
- Source job: derby-j1-source-b561aea1-s30-20261020
- Source actual start/finish: 10:27:59→10:28:21 UTC, 22seconds
- Source receipt: f943d8a86e72e70015040a73e1d389f09b3fda1839ae44ea361b1b8423ecb822
- Source tree: a46db1efcf7121ac9e82c647e00fe4faf251f5ad
- Source SHA256: 1eab55b86ee1cefdac3cf3e42ee80d02ae663844a019284b1f4bee2167f77772
- ON build job: derby-j1-on-build-b561aea1-s30-20261020
- Build actual start/finish: 10:29:16→10:32:25 UTC, 189seconds
- Build terminal: succeeded / firmware_build_succeeded_no_flash
- Build plan: 7b272f7b95a99d2ff5fee82aa2e67e16cfe8d66d3b08c10c9852640b66f1c6d1
- Observed broker epoch: 25fdbe66ee704b40ab4040bc390ee793
- Runtime3b2c606cd3f73a7b49a808d9557482916ea7f87c / 30second scan ceiling deployment is parent-attested. Epoch is directly observed; broker status does not expose runtime commit.

Artifacts:
| Artifact | Bytes | SHA256 |
|---|---:|---|
| cardputer_pocketjs.bin | 2296976 | 3f3eda8021804466be2ab5d1a6ed0953f96494e05ff1e42aa46a0dae919a0de9 |
| cardputer_pocketjs.elf | 20046488 | 25249d3df9c9d5ea0eda71b51cd051767b355cdc14274261ea9066593c98e8f5 |

The artifacts remain in the broker's retained build storage. This evidence archive contains their verified manifest, hashes and proof; it does not contain BIN/ELF bodies copied to Linux.

Mode proof:
- Requested mode, plan, fingerprint-isolated build, durable manifest and actual detail proof are ON.
- Mandatory exact-J1 proof validates linked df_detail_enabled, common fixed owner completion record, generated JS bytes embedded in ELF, fixed hardware seed2545F491, and IDF6.0.1 BIN/ELF pairing.
- Owner contract fixed-owner-v1, record DERBY_DETAIL_EXIT, detail_mode ON; df_fixed_exit_record and df_detail_enabled linked symbols present.
- Telemetry/measure/fixed/detail all ON; fixture oval-pan8-390-510-v1, seed9112A7AB, camera8, race1000001, 390→510 /120contexts /3dependent reps.
- Canonical diagnostic proof SHA256: a504d85a5a3378469e68f278e4710d5bdee78e03147c68f6aa28f31d3c4953eb
- hardware_tested=false and flash_authorized=false.

Validation:
python3 verify_source_build.py passed40receipt/proof/log/cache checks. SOURCE-BUILD-PROOF.json records every check and input hash. All2120provider log sequence entries are retained continuously with no gaps/expiry and the unique logged proof equals the durable proof. Initial filtered-log snapshot is preserved separately; acceptance uses only all-level pages. Static proof script reference is exact J1 Git blob9aec3ff46843b1f607e054eb9622faee96e6c25f.

The requested ON build ran once; source ran once. No test was substituted with accepted/queued status. Earlier J1 r1 failure remains preserved and was read as a known failed terminal before this new-epoch attempt. No old-epoch plan was reused.

Preservation:
All19prior receipt records and all14protected payloads were retained; only new J1 receipt/payload added. Cache now20receipt records/16live payloads/4previous evictions, with no new reclamation. Existing capacity/evidence/hash/recovery policies unchanged. One inventory read during build returned source_fetch_busy and was saved; complete before/after inventories were compared after the build ended.

Final broker state is idle/unowned, queues/leases/work sessions zero, uncertainty flags false. Historical review count9 and failed count8 remain; succeeded increased109→111 for source/build. No current physical image reread or write occurred. J0 last-verified history is retained; this build provides no J1 timing or device-quality result and does not reuse J0 timing.

Independent preflight, source/build-plan and final reviews are preserved alongside the source/build evidence. No blocker remains for this requested ON build. OFF, physical strict-v2 termination and ON/OFF equivalence remain unexecuted, outside this task.

Reproduce the evidence-only check with:
python3 /workspace/derby-evidence/j1-on-build-30s-20261020/verify_source_build.py
This reads saved files only and does not build, flash or access hardware.

