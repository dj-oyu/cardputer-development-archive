# Standing right-step motion and separate reaction variation

- right-step-waist.blend: right foot plants before shoulders shift; left arm hangs outside the thigh, right hand on waist.
- right-step-neck-forward.blend: separate authored reaction. It shares the first beat, then moves the neck/head forward without changing face pitch or expression. It is not required for the basic weight shift.

Each Blender file contains the complete editable character rig and motion. Technical checks are Blender-native only. No generated previews are included.
